/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/kitchenQueue.ts" enhancement="_blank"/>
export {};
