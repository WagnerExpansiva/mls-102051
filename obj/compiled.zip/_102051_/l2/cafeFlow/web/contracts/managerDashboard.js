/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/managerDashboard.ts" enhancement="_blank"/>
export {};
