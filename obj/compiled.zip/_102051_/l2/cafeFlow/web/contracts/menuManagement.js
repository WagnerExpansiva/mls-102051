/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/menuManagement.ts" enhancement="_blank"/>
export {};
