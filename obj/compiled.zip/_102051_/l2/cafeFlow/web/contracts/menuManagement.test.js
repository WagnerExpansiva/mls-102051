/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/menuManagement.test.ts" enhancement="_blank"/>
export {};
