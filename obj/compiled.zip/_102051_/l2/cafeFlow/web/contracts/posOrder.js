/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/posOrder.ts" enhancement="_blank"/>
export {};
