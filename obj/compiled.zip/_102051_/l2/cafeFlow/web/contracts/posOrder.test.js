/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/posOrder.test.ts" enhancement="_blank"/>
export {};
