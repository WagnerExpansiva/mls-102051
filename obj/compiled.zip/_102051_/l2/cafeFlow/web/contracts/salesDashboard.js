/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/salesDashboard.ts" enhancement="_blank"/>
export {};
