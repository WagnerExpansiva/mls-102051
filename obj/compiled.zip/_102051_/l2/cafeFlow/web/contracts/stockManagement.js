/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/stockManagement.ts" enhancement="_blank"/>
export {};
