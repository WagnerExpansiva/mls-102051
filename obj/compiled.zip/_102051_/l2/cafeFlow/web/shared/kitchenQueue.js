/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/kitchenQueue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "kitchenQueue.section.title": "Fila da cozinha — Preparo de pedidos",
    "kitchenQueue.viewKitchenBoard.title": "Fila da cozinha",
    "kitchenQueue.viewKitchenBoard.list.title": "Pedidos na fila da cozinha",
    "kitchenQueue.updateOrderStatus.title": "Atualizar status do pedido",
    "kitchenQueue.updateOrderStatus.form.title": "Atualizar status",
    "kitchenQueue.summary.title": "Resumo do pedido",
    "kitchenQueue.field.orderId": "Pedido",
    "kitchenQueue.field.status": "Status",
    "kitchenQueue.field.orderType": "Tipo",
    "kitchenQueue.field.tableNumber": "Mesa",
    "kitchenQueue.field.priority": "Prioridade",
    "kitchenQueue.field.priorityReason": "Motivo da prioridade",
    "kitchenQueue.field.receivedAt": "Recebido em",
    "kitchenQueue.field.inPreparationAt": "Em preparo em",
    "kitchenQueue.field.createdAt": "Criado em",
    "kitchenQueue.action.refreshBoard": "Atualizar fila",
    "kitchenQueue.action.updateStatus": "Atualizar status"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowKitchenQueueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewKitchenBoardState = "idle";
        this.viewKitchenBoardData = { items: [], total: 0 };
        this.updateOrderStatusState = "idle";
        this.updateOrderStatusStatus = "";
        this.LayoutSumOrderId = '';
        this.LayoutSumOrderType = '';
        this.LayoutSumTableNumber = '';
        this.LayoutSumPriority = '';
        this.LayoutSumPriorityReason = '';
        this.LayoutSumReceivedAt = '';
        this.LayoutSumInPreparationAt = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    // ── State setter: set.updateOrderStatusStatus ──
    setUpdateOrderStatusStatus(value) {
        this.updateOrderStatusStatus = value;
        setState("ui.kitchenQueue.input.updateOrderStatus.status", value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusStatusChange(e) {
        const target = e.target;
        const value = target.value;
        this.setUpdateOrderStatusStatus(value);
    }
    // ── Query action: viewKitchenBoard ──
    async loadViewKitchenBoard() {
        this.viewKitchenBoardState = "loading";
        setState("ui.kitchenQueue.action.viewKitchenBoard.status", "loading");
        this.requestUpdate();
        const options = { mode: 'silent' };
        const response = await execBff("cafeFlow.orderLifecycle.viewKitchenBoard", {}, options);
        if (response.ok) {
            const data = response.data ?? { items: [], total: 0 };
            this.viewKitchenBoardData = data;
            setState("ui.kitchenQueue.data.viewKitchenBoard", data);
            this.viewKitchenBoardState = "success";
            setState("ui.kitchenQueue.action.viewKitchenBoard.status", "success");
        }
        else {
            this.viewKitchenBoardState = "error";
            setState("ui.kitchenQueue.action.viewKitchenBoard.status", "error");
            if (response.error) {
                console.error("[kitchenQueue] loadViewKitchenBoard error:", response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleViewKitchenBoardClick(_e) {
        this.loadViewKitchenBoard();
    }
    // ── Command action: updateOrderStatus ──
    async updateOrderStatus() {
        this.updateOrderStatusState = "loading";
        setState("ui.kitchenQueue.action.updateOrderStatus.status", "loading");
        this.requestUpdate();
        const params = {
            status: this.updateOrderStatusStatus,
        };
        const response = await execBff("cafeFlow.orderLifecycle.updateOrderStatus", params, { mode: 'blocking' });
        if (response.ok) {
            // Refresh query actions
            let refreshFailed = false;
            try {
                await this.loadViewKitchenBoard();
            }
            catch (err) {
                refreshFailed = true;
                console.error("[kitchenQueue] refresh after updateOrderStatus failed:", err);
            }
            if (refreshFailed) {
                this.updateOrderStatusState = "error";
                setState("ui.kitchenQueue.action.updateOrderStatus.status", "error");
            }
            else {
                this.updateOrderStatusState = "success";
                setState("ui.kitchenQueue.action.updateOrderStatus.status", "success");
            }
        }
        else {
            this.updateOrderStatusState = "error";
            setState("ui.kitchenQueue.action.updateOrderStatus.status", "error");
            if (response.error) {
                console.error("[kitchenQueue] updateOrderStatus error:", response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleUpdateOrderStatusClick(e) {
        e.preventDefault();
        runBlockingUiAction(async (_signal) => {
            await this.updateOrderStatus();
        }, { mode: 'blocking' });
    }
    // ── Lifecycle ──
    connectedCallback() {
        super.connectedCallback();
        // Initialize state from global store, falling back to defaults
        const savedStatus = getState("ui.kitchenQueue.status");
        this.status = savedStatus ?? '';
        const savedViewBoardState = getState("ui.kitchenQueue.action.viewKitchenBoard.status");
        this.viewKitchenBoardState = savedViewBoardState ?? "idle";
        const savedViewBoardData = getState("ui.kitchenQueue.data.viewKitchenBoard");
        this.viewKitchenBoardData = savedViewBoardData ?? { items: [], total: 0 };
        const savedUpdateState = getState("ui.kitchenQueue.action.updateOrderStatus.status");
        this.updateOrderStatusState = savedUpdateState ?? "idle";
        const savedUpdateStatusInput = getState("ui.kitchenQueue.input.updateOrderStatus.status");
        this.updateOrderStatusStatus = savedUpdateStatusInput ?? "";
        // Subscribe to shared states
        subscribe([
            "ui.kitchenQueue.status",
            "ui.kitchenQueue.action.viewKitchenBoard.status",
            "ui.kitchenQueue.data.viewKitchenBoard",
            "ui.kitchenQueue.action.updateOrderStatus.status",
            "ui.kitchenQueue.input.updateOrderStatus.status",
        ], this);
        // Run initial loads
        this.loadViewKitchenBoard();
    }
    disconnectedCallback() {
        unsubscribe([
            "ui.kitchenQueue.status",
            "ui.kitchenQueue.action.viewKitchenBoard.status",
            "ui.kitchenQueue.data.viewKitchenBoard",
            "ui.kitchenQueue.action.updateOrderStatus.status",
            "ui.kitchenQueue.input.updateOrderStatus.status",
        ], this);
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "viewKitchenBoardState", void 0);
__decorate([
    property({ type: Object })
], CafeFlowKitchenQueueBase.prototype, "viewKitchenBoardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "updateOrderStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "updateOrderStatusStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "LayoutSumOrderId", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "LayoutSumOrderType", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "LayoutSumTableNumber", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "LayoutSumPriority", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "LayoutSumPriorityReason", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "LayoutSumReceivedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "LayoutSumInPreparationAt", void 0);
