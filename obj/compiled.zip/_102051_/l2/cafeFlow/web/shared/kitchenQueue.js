/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/kitchenQueue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "kitchenQueue.section.board.title": "Fila da cozinha",
    "kitchenQueue.organism.board.title": "Painel da cozinha",
    "kitchenQueue.intent.board.list.title": "Pedidos por status",
    "kitchenQueue.section.transition.title": "Transição de status",
    "kitchenQueue.organism.update.title": "Atualizar status do pedido",
    "kitchenQueue.intent.update.title": "Avançar status do pedido",
    "kitchenQueue.section.summary.title": "Resumo do pedido",
    "kitchenQueue.organism.summary.title": "Resumo do pedido selecionado",
    "kitchenQueue.intent.summary.title": "Detalhes do pedido",
    "kitchenQueue.field.orderId": "Pedido",
    "kitchenQueue.field.status": "Status",
    "kitchenQueue.field.orderType": "Tipo",
    "kitchenQueue.field.tableNumber": "Mesa",
    "kitchenQueue.field.priority": "Prioridade",
    "kitchenQueue.field.priorityReason": "Motivo da prioridade",
    "kitchenQueue.field.receivedAt": "Recebido em",
    "kitchenQueue.field.inPreparationAt": "Em preparo desde",
    "kitchenQueue.action.markInPreparation": "Iniciar preparo",
    "kitchenQueue.action.markReady": "Marcar como pronto",
    "kitchenQueue.section.cards.title": "Fila em cartões",
    "kitchenQueue.organism.cards.title": "Pedidos da cozinha",
    "kitchenQueue.intent.cards.list.title": "Pedidos do turno",
    "kitchenQueue.section.actions.title": "Ações do pedido",
    "kitchenQueue.organism.actions.title": "Atualizar status",
    "kitchenQueue.intent.card.update.title": "Avançar status",
    "kitchenQueue.section.queue.title": "Fila de trabalho",
    "kitchenQueue.organism.queue.title": "Pedidos em fila",
    "kitchenQueue.intent.queue.list.title": "Fila atual"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowKitchenQueueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewKitchenBoardState = 'idle';
        this.viewKitchenBoardData = { items: [], total: 0 };
        this.updateOrderStatusState = 'idle';
        this.updateOrderStatusStatus = '';
        this.OutputUpdateOrderStatus = null;
        this.subscribedKeys = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const existingStatus = getState('ui.kitchenQueue.status');
        if (existingStatus !== undefined) {
            this.status = existingStatus;
        }
        const existingViewStatus = getState('ui.kitchenQueue.action.viewKitchenBoard.status');
        if (existingViewStatus !== undefined) {
            this.viewKitchenBoardState = existingViewStatus;
        }
        const existingViewData = getState('ui.kitchenQueue.data.viewKitchenBoard');
        if (existingViewData !== undefined) {
            this.viewKitchenBoardData = existingViewData;
        }
        const existingUpdateStatus = getState('ui.kitchenQueue.action.updateOrderStatus.status');
        if (existingUpdateStatus !== undefined) {
            this.updateOrderStatusState = existingUpdateStatus;
        }
        const existingUpdateInputStatus = getState('ui.kitchenQueue.input.updateOrderStatus.status');
        if (existingUpdateInputStatus !== undefined) {
            this.updateOrderStatusStatus = existingUpdateInputStatus;
        }
        const existingOutput = getState('ui.kitchenQueue.output.updateOrderStatus');
        if (existingOutput !== undefined) {
            this.OutputUpdateOrderStatus = existingOutput;
        }
        const keys = [
            'ui.kitchenQueue.status',
            'ui.kitchenQueue.action.viewKitchenBoard.status',
            'ui.kitchenQueue.data.viewKitchenBoard',
            'ui.kitchenQueue.action.updateOrderStatus.status',
            'ui.kitchenQueue.input.updateOrderStatus.status',
            'ui.kitchenQueue.output.updateOrderStatus',
        ];
        this.subscribedKeys = keys;
        subscribe(keys, this);
        this.loadViewKitchenBoard();
    }
    disconnectedCallback() {
        if (this.subscribedKeys.length > 0) {
            unsubscribe(this.subscribedKeys, this);
            this.subscribedKeys = [];
        }
        super.disconnectedCallback();
    }
    // --- Action: viewKitchenBoard (query) ---
    async loadViewKitchenBoard() {
        this.viewKitchenBoardState = 'loading';
        setState('ui.kitchenQueue.action.viewKitchenBoard.status', 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.orderLifecycle.viewKitchenBoard', {}, options);
        if (response.ok) {
            const data = response.data ?? { items: [], total: 0 };
            this.viewKitchenBoardData = data;
            setState('ui.kitchenQueue.data.viewKitchenBoard', data);
            this.viewKitchenBoardState = 'success';
            setState('ui.kitchenQueue.action.viewKitchenBoard.status', 'success');
        }
        else {
            this.viewKitchenBoardState = 'error';
            setState('ui.kitchenQueue.action.viewKitchenBoard.status', 'error');
            if (response.error) {
                console.error('[kitchenQueue] loadViewKitchenBoard error:', response.error.message);
            }
        }
    }
    handleViewKitchenBoardClick(_e) {
        this.loadViewKitchenBoard();
    }
    // --- Action: updateOrderStatus (command) ---
    async updateOrderStatus() {
        this.updateOrderStatusState = 'loading';
        setState('ui.kitchenQueue.action.updateOrderStatus.status', 'loading');
        const params = {
            status: this.updateOrderStatusStatus,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.orderLifecycle.updateOrderStatus', params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.OutputUpdateOrderStatus = data;
            setState('ui.kitchenQueue.output.updateOrderStatus', data);
            // Refresh: call viewKitchenBoard query
            let refreshFailed = false;
            try {
                await this.loadViewKitchenBoard();
                if (this.viewKitchenBoardState === 'error') {
                    refreshFailed = true;
                }
            }
            catch {
                refreshFailed = true;
            }
            if (refreshFailed) {
                this.updateOrderStatusState = 'error';
                setState('ui.kitchenQueue.action.updateOrderStatus.status', 'error');
            }
            else {
                this.updateOrderStatusState = 'success';
                setState('ui.kitchenQueue.action.updateOrderStatus.status', 'success');
            }
        }
        else {
            this.updateOrderStatusState = 'error';
            setState('ui.kitchenQueue.action.updateOrderStatus.status', 'error');
            if (response.error) {
                console.error('[kitchenQueue] updateOrderStatus error:', response.error.message);
            }
        }
    }
    handleUpdateOrderStatusClick(_e) {
        runBlockingUiAction(async (_signal) => {
            await this.updateOrderStatus();
        }, { mode: 'blocking' });
    }
    // --- Action: set.updateOrderStatusStatus (stateSetter) ---
    setUpdateOrderStatusStatus(value) {
        this.updateOrderStatusStatus = value;
        setState('ui.kitchenQueue.input.updateOrderStatus.status', value);
        this.requestUpdate();
    }
    handleUpdateOrderStatusStatusChange(e) {
        const target = e.target;
        const value = target.value;
        this.setUpdateOrderStatusStatus(value);
    }
}
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "viewKitchenBoardState", void 0);
__decorate([
    property({ type: Object })
], CafeFlowKitchenQueueBase.prototype, "viewKitchenBoardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "updateOrderStatusState", void 0);
__decorate([
    property({ type: String })
], CafeFlowKitchenQueueBase.prototype, "updateOrderStatusStatus", void 0);
__decorate([
    property({ type: Object })
], CafeFlowKitchenQueueBase.prototype, "OutputUpdateOrderStatus", void 0);
