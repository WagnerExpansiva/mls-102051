/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/managerDashboard.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "managerDashboard.section.overview.title": "Visão do dia",
    "managerDashboard.organism.viewDashboard.title": "Dashboard do turno",
    "managerDashboard.intent.dashboardStatus.title": "Status dos pedidos do turno",
    "managerDashboard.intent.dashboardStatus.empty": "Nenhum pedido no turno atual",
    "managerDashboard.field.status": "Status do pedido",
    "managerDashboard.field.orderType": "Tipo de pedido",
    "managerDashboard.field.createdAt": "Criado em",
    "managerDashboard.field.deliveredAt": "Entregue em",
    "managerDashboard.field.shiftId": "Turno",
    "managerDashboard.action.refreshDashboard": "Atualizar dashboard",
    "managerDashboard.section.aiAssistant.title": "Assistente IA",
    "managerDashboard.organism.aiSalesSummary.title": "Resumo de vendas por IA",
    "managerDashboard.intent.aiSalesAction.title": "Solicitar resumo de vendas",
    "managerDashboard.intent.aiSalesAction.empty": "Resumo ainda não solicitado",
    "managerDashboard.action.requestAiSalesSummary": "Gerar resumo de vendas",
    "managerDashboard.intent.aiSalesResult.title": "Resumo de vendas gerado",
    "managerDashboard.intent.aiSalesResult.empty": "Nenhum resumo disponível",
    "managerDashboard.field.orderId": "Pedido",
    "managerDashboard.organism.aiPromoSuggestions.title": "Sugestões de promoção por IA",
    "managerDashboard.intent.aiPromoAction.title": "Solicitar sugestões de promoção",
    "managerDashboard.intent.aiPromoAction.empty": "Sugestões ainda não solicitadas",
    "managerDashboard.action.requestAiPromoSuggestions": "Gerar sugestões de promoção",
    "managerDashboard.intent.aiPromoResult.title": "Sugestões de promoção geradas",
    "managerDashboard.intent.aiPromoResult.empty": "Nenhuma sugestão disponível"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
const STATE_KEYS = [
    'ui.managerDashboard.status',
    'ui.managerDashboard.action.viewDashboard.status',
    'ui.managerDashboard.data.viewDashboard',
    'ui.managerDashboard.action.requestAiSalesSummary.status',
    'ui.managerDashboard.data.requestAiSalesSummary',
    'ui.managerDashboard.action.requestAiPromoSuggestions.status',
    'ui.managerDashboard.data.requestAiPromoSuggestions',
];
export class CafeFlowManagerDashboardBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewDashboardState = 'idle';
        this.viewDashboardData = [];
        this.requestAiSalesSummaryState = 'idle';
        this.requestAiSalesSummaryData = [];
        this.requestAiPromoSuggestionsState = 'idle';
        this.requestAiPromoSuggestionsData = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.managerDashboard.status') ?? '';
        this.viewDashboardState = getState('ui.managerDashboard.action.viewDashboard.status') ?? 'idle';
        this.viewDashboardData = getState('ui.managerDashboard.data.viewDashboard') ?? [];
        this.requestAiSalesSummaryState = getState('ui.managerDashboard.action.requestAiSalesSummary.status') ?? 'idle';
        this.requestAiSalesSummaryData = getState('ui.managerDashboard.data.requestAiSalesSummary') ?? [];
        this.requestAiPromoSuggestionsState = getState('ui.managerDashboard.action.requestAiPromoSuggestions.status') ?? 'idle';
        this.requestAiPromoSuggestionsData = getState('ui.managerDashboard.data.requestAiPromoSuggestions') ?? [];
        subscribe(STATE_KEYS, this);
        void this.loadViewDashboard();
        void this.loadRequestAiSalesSummary();
        void this.loadRequestAiPromoSuggestions();
    }
    disconnectedCallback() {
        unsubscribe(STATE_KEYS, this);
        super.disconnectedCallback();
    }
    async loadViewDashboard() {
        this.viewDashboardState = 'loading';
        setState('ui.managerDashboard.action.viewDashboard.status', 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.viewDashboard.viewDashboard', {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.viewDashboardData = data;
            setState('ui.managerDashboard.data.viewDashboard', data);
            this.viewDashboardState = 'success';
            setState('ui.managerDashboard.action.viewDashboard.status', 'success');
        }
        else {
            this.viewDashboardState = 'error';
            setState('ui.managerDashboard.action.viewDashboard.status', 'error');
            if (response.error) {
                console.error('[managerDashboard] loadViewDashboard error:', response.error.message);
            }
        }
    }
    handleViewDashboardClick() {
        void this.loadViewDashboard();
    }
    async loadRequestAiSalesSummary() {
        this.requestAiSalesSummaryState = 'loading';
        setState('ui.managerDashboard.action.requestAiSalesSummary.status', 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.requestAiSalesSummary.requestAiSalesSummary', {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.requestAiSalesSummaryData = data;
            setState('ui.managerDashboard.data.requestAiSalesSummary', data);
            this.requestAiSalesSummaryState = 'success';
            setState('ui.managerDashboard.action.requestAiSalesSummary.status', 'success');
        }
        else {
            this.requestAiSalesSummaryState = 'error';
            setState('ui.managerDashboard.action.requestAiSalesSummary.status', 'error');
            if (response.error) {
                console.error('[managerDashboard] loadRequestAiSalesSummary error:', response.error.message);
            }
        }
    }
    handleRequestAiSalesSummaryClick() {
        void this.loadRequestAiSalesSummary();
    }
    async loadRequestAiPromoSuggestions() {
        this.requestAiPromoSuggestionsState = 'loading';
        setState('ui.managerDashboard.action.requestAiPromoSuggestions.status', 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.requestAiPromoSuggestions.requestAiPromoSuggestions', {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.requestAiPromoSuggestionsData = data;
            setState('ui.managerDashboard.data.requestAiPromoSuggestions', data);
            this.requestAiPromoSuggestionsState = 'success';
            setState('ui.managerDashboard.action.requestAiPromoSuggestions.status', 'success');
        }
        else {
            this.requestAiPromoSuggestionsState = 'error';
            setState('ui.managerDashboard.action.requestAiPromoSuggestions.status', 'error');
            if (response.error) {
                console.error('[managerDashboard] loadRequestAiPromoSuggestions error:', response.error.message);
            }
        }
    }
    handleRequestAiPromoSuggestionsClick() {
        void this.loadRequestAiPromoSuggestions();
    }
}
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "viewDashboardState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowManagerDashboardBase.prototype, "viewDashboardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "requestAiSalesSummaryState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowManagerDashboardBase.prototype, "requestAiSalesSummaryData", void 0);
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "requestAiPromoSuggestionsState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowManagerDashboardBase.prototype, "requestAiPromoSuggestionsData", void 0);
