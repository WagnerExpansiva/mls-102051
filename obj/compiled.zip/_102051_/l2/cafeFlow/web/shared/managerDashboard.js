/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/managerDashboard.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "managerDashboard.section.dashboard.title": "Dashboard e assistente IA",
    "managerDashboard.organism.viewDashboard.title": "Dashboard do dia",
    "managerDashboard.organism.requestAiSalesSummary.title": "Resumo de vendas por IA",
    "managerDashboard.organism.requestAiPromoSuggestions.title": "Sugestões de promoção por IA",
    "managerDashboard.intention.viewDashboard.list.title": "Pedidos do turno atual",
    "managerDashboard.intention.requestAiSalesSummary.list.title": "Resumo de vendas do dia",
    "managerDashboard.intention.requestAiPromoSuggestions.list.title": "Sugestões de promoção",
    "managerDashboard.field.status": "Status",
    "managerDashboard.field.orderType": "Tipo do pedido",
    "managerDashboard.field.createdAt": "Criado em",
    "managerDashboard.field.shiftId": "Turno",
    "managerDashboard.field.deliveredAt": "Entregue em",
    "managerDashboard.field.orderId": "Pedido",
    "managerDashboard.action.viewDashboard": "Atualizar dashboard",
    "managerDashboard.action.requestAiSalesSummary": "Gerar resumo de vendas",
    "managerDashboard.action.requestAiPromoSuggestions": "Gerar sugestões de promoção"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowManagerDashboardBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewDashboardState = 'idle';
        this.viewDashboardData = [];
        this.requestAiSalesSummaryState = 'idle';
        this.requestAiSalesSummaryData = [];
        this.requestAiPromoSuggestionsState = 'idle';
        this.requestAiPromoSuggestionsData = [];
        this.subscribedKeys = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const statusFromState = getState('ui.managerDashboard.status');
        if (statusFromState !== undefined && statusFromState !== null) {
            this.status = statusFromState;
        }
        else {
            this.status = '';
            setState('ui.managerDashboard.status', '');
        }
        const viewDashboardDataFromState = getState('ui.managerDashboard.data.viewDashboard');
        if (viewDashboardDataFromState !== undefined && viewDashboardDataFromState !== null) {
            this.viewDashboardData = viewDashboardDataFromState;
        }
        const requestAiSalesSummaryDataFromState = getState('ui.managerDashboard.data.requestAiSalesSummary');
        if (requestAiSalesSummaryDataFromState !== undefined && requestAiSalesSummaryDataFromState !== null) {
            this.requestAiSalesSummaryData = requestAiSalesSummaryDataFromState;
        }
        const requestAiPromoSuggestionsDataFromState = getState('ui.managerDashboard.data.requestAiPromoSuggestions');
        if (requestAiPromoSuggestionsDataFromState !== undefined && requestAiPromoSuggestionsDataFromState !== null) {
            this.requestAiPromoSuggestionsData = requestAiPromoSuggestionsDataFromState;
        }
        const sharedKeys = [
            'ui.managerDashboard.status',
            'ui.managerDashboard.data.viewDashboard',
            'ui.managerDashboard.data.requestAiSalesSummary',
            'ui.managerDashboard.data.requestAiPromoSuggestions',
        ];
        subscribe(sharedKeys, this);
        this.subscribedKeys = sharedKeys;
        this.loadViewDashboard();
        this.loadRequestAiSalesSummary();
        this.loadRequestAiPromoSuggestions();
    }
    disconnectedCallback() {
        if (this.subscribedKeys.length > 0) {
            unsubscribe(this.subscribedKeys, this);
            this.subscribedKeys = [];
        }
        super.disconnectedCallback();
    }
    async loadViewDashboard() {
        this.viewDashboardState = 'loading';
        setState('ui.managerDashboard.action.viewDashboard.status', 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.viewDashboard.viewDashboard', {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.viewDashboardData = data;
            setState('ui.managerDashboard.data.viewDashboard', data);
            this.viewDashboardState = 'success';
            setState('ui.managerDashboard.action.viewDashboard.status', 'success');
        }
        else {
            this.viewDashboardState = 'error';
            setState('ui.managerDashboard.action.viewDashboard.status', 'error');
            if (response.error) {
                console.error('[managerDashboard] loadViewDashboard error:', response.error.message);
            }
        }
    }
    handleViewDashboardClick(_e) {
        this.loadViewDashboard();
    }
    async loadRequestAiSalesSummary() {
        this.requestAiSalesSummaryState = 'loading';
        setState('ui.managerDashboard.action.requestAiSalesSummary.status', 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.requestAiSalesSummary.requestAiSalesSummary', {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.requestAiSalesSummaryData = data;
            setState('ui.managerDashboard.data.requestAiSalesSummary', data);
            this.requestAiSalesSummaryState = 'success';
            setState('ui.managerDashboard.action.requestAiSalesSummary.status', 'success');
        }
        else {
            this.requestAiSalesSummaryState = 'error';
            setState('ui.managerDashboard.action.requestAiSalesSummary.status', 'error');
            if (response.error) {
                console.error('[managerDashboard] loadRequestAiSalesSummary error:', response.error.message);
            }
        }
    }
    handleRequestAiSalesSummaryClick(_e) {
        this.loadRequestAiSalesSummary();
    }
    async loadRequestAiPromoSuggestions() {
        this.requestAiPromoSuggestionsState = 'loading';
        setState('ui.managerDashboard.action.requestAiPromoSuggestions.status', 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.requestAiPromoSuggestions.requestAiPromoSuggestions', {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.requestAiPromoSuggestionsData = data;
            setState('ui.managerDashboard.data.requestAiPromoSuggestions', data);
            this.requestAiPromoSuggestionsState = 'success';
            setState('ui.managerDashboard.action.requestAiPromoSuggestions.status', 'success');
        }
        else {
            this.requestAiPromoSuggestionsState = 'error';
            setState('ui.managerDashboard.action.requestAiPromoSuggestions.status', 'error');
            if (response.error) {
                console.error('[managerDashboard] loadRequestAiPromoSuggestions error:', response.error.message);
            }
        }
    }
    handleRequestAiPromoSuggestionsClick(_e) {
        this.loadRequestAiPromoSuggestions();
    }
}
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "viewDashboardState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowManagerDashboardBase.prototype, "viewDashboardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "requestAiSalesSummaryState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowManagerDashboardBase.prototype, "requestAiSalesSummaryData", void 0);
__decorate([
    property({ type: String })
], CafeFlowManagerDashboardBase.prototype, "requestAiPromoSuggestionsState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowManagerDashboardBase.prototype, "requestAiPromoSuggestionsData", void 0);
