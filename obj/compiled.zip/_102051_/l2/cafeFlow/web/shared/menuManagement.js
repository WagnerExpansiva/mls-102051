/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/menuManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "menuManagement.queue.title": "Fila de itens do cardápio",
    "menuManagement.queue.list.title": "Itens do cardápio",
    "menuManagement.queue.query.title": "Lista de itens",
    "menuManagement.queue.summary.title": "Resumo do item selecionado",
    "menuManagement.detail.title": "Detalhes do item",
    "menuManagement.detail.form.title": "Atualizar item do cardápio",
    "menuManagement.detail.status.title": "Status atual",
    "menuManagement.detail.edit.title": "Editar item",
    "menuManagement.detail.review.title": "Revisão das alterações",
    "menuManagement.context.title": "Empresa ativa",
    "menuManagement.menuItem.name": "Nome",
    "menuManagement.menuItem.description": "Descrição",
    "menuManagement.menuItem.menuCategoryId": "Categoria",
    "menuManagement.menuItem.price": "Preço",
    "menuManagement.menuItem.itemType": "Tipo",
    "menuManagement.menuItem.status": "Status",
    "menuManagement.menuItem.activatedAt": "Ativado em",
    "menuManagement.menuItem.inactivatedAt": "Inativado em",
    "menuManagement.menuItem.updatedAt": "Atualizado em",
    "menuManagement.filter.status": "Status",
    "menuManagement.filter.menuCategory": "Categoria",
    "menuManagement.action.refresh": "Atualizar lista",
    "menuManagement.action.manage": "Gerenciar item",
    "menuManagement.action.save": "Salvar alterações",
    "menuManagement.board.title": "Pipeline de status",
    "menuManagement.board.lanes.title": "Itens por status",
    "menuManagement.board.query.title": "Cartões do cardápio",
    "menuManagement.board.summary.title": "Resumo do cartão",
    "menuManagement.cards.title": "Cartões de itens do cardápio",
    "menuManagement.cards.list.title": "Itens do cardápio",
    "menuManagement.cards.query.title": "Cartões do cardápio",
    "menuManagement.cards.summary.title": "Resumo do cartão"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowMenuManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.browseMenuItemsState = "idle";
        this.browseMenuItemsStatusFilter = "";
        this.browseMenuItemsMenuCategoryIdFilter = "";
        this.browseMenuItemsData = { items: [], total: 0 };
        this.manageMenuItemState = "idle";
        this.manageMenuItemName = "";
        this.manageMenuItemDescription = "";
        this.manageMenuItemMenuCategoryId = "";
        this.manageMenuItemPrice = "";
        this.manageMenuItemItemType = "";
        this.manageMenuItemStatus = "";
        this.activeCompanyId = "";
        this.OutputManageMenuItem = null;
        this.LayoutWs20ActivatedAt = "";
        this.LayoutWs30InactivatedAt = "";
        this.LayoutR50UpdatedAt = "";
        this.subscribedKeys = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    // ── State setters ──────────────────────────────────────────────
    setBrowseMenuItemsStatusFilter(value) {
        this.browseMenuItemsStatusFilter = value;
        setState("ui.menuManagement.input.browseMenuItems.statusFilter", value);
        this.requestUpdate();
    }
    handleBrowseMenuItemsStatusFilterChange(e) {
        const target = e.target;
        this.setBrowseMenuItemsStatusFilter(target.value ?? "");
    }
    setBrowseMenuItemsMenuCategoryIdFilter(value) {
        this.browseMenuItemsMenuCategoryIdFilter = value;
        setState("ui.menuManagement.input.browseMenuItems.menuCategoryIdFilter", value);
        this.requestUpdate();
    }
    handleBrowseMenuItemsMenuCategoryIdFilterChange(e) {
        const target = e.target;
        this.setBrowseMenuItemsMenuCategoryIdFilter(target.value ?? "");
    }
    setManageMenuItemName(value) {
        this.manageMenuItemName = value;
        setState("ui.menuManagement.input.manageMenuItem.name", value);
        this.requestUpdate();
    }
    handleManageMenuItemNameChange(e) {
        const target = e.target;
        this.setManageMenuItemName(target.value ?? "");
    }
    setManageMenuItemDescription(value) {
        this.manageMenuItemDescription = value;
        setState("ui.menuManagement.input.manageMenuItem.description", value);
        this.requestUpdate();
    }
    handleManageMenuItemDescriptionChange(e) {
        const target = e.target;
        this.setManageMenuItemDescription(target.value ?? "");
    }
    setManageMenuItemMenuCategoryId(value) {
        this.manageMenuItemMenuCategoryId = value;
        setState("ui.menuManagement.input.manageMenuItem.menuCategoryId", value);
        this.requestUpdate();
    }
    handleManageMenuItemMenuCategoryIdChange(e) {
        const target = e.target;
        this.setManageMenuItemMenuCategoryId(target.value ?? "");
    }
    setManageMenuItemPrice(value) {
        this.manageMenuItemPrice = value;
        setState("ui.menuManagement.input.manageMenuItem.price", value);
        this.requestUpdate();
    }
    handleManageMenuItemPriceChange(e) {
        const target = e.target;
        this.setManageMenuItemPrice(target.value ?? "");
    }
    setManageMenuItemItemType(value) {
        this.manageMenuItemItemType = value;
        setState("ui.menuManagement.input.manageMenuItem.itemType", value);
        this.requestUpdate();
    }
    handleManageMenuItemItemTypeChange(e) {
        const target = e.target;
        this.setManageMenuItemItemType(target.value ?? "");
    }
    setManageMenuItemStatus(value) {
        this.manageMenuItemStatus = value;
        setState("ui.menuManagement.input.manageMenuItem.status", value);
        this.requestUpdate();
    }
    handleManageMenuItemStatusChange(e) {
        const target = e.target;
        this.setManageMenuItemStatus(target.value ?? "");
    }
    // ── Query: browseMenuItems ─────────────────────────────────────
    async loadBrowseMenuItems() {
        this.browseMenuItemsState = "loading";
        setState("ui.menuManagement.action.browseMenuItems.status", "loading");
        const params = {
            statusFilter: this.browseMenuItemsStatusFilter
                ? this.browseMenuItemsStatusFilter
                : undefined,
            menuCategoryIdFilter: this.browseMenuItemsMenuCategoryIdFilter || undefined,
        };
        const options = { mode: "silent" };
        const response = await execBff("cafeFlow.menuItemLifecycle.browseMenuItems", params, options);
        if (response.ok) {
            const data = response.data ?? { items: [], total: 0 };
            this.browseMenuItemsData = data;
            setState("ui.menuManagement.data.browseMenuItems", data);
            this.browseMenuItemsState = "success";
            setState("ui.menuManagement.action.browseMenuItems.status", "success");
        }
        else {
            this.browseMenuItemsState = "error";
            setState("ui.menuManagement.action.browseMenuItems.status", "error");
            console.error("[menuManagement] browseMenuItems failed:", response.error);
        }
    }
    handleBrowseMenuItemsClick() {
        this.loadBrowseMenuItems();
    }
    // ── Command: manageMenuItem ────────────────────────────────────
    async manageMenuItem() {
        this.manageMenuItemState = "loading";
        setState("ui.menuManagement.action.manageMenuItem.status", "loading");
        const params = {
            name: this.manageMenuItemName,
            description: this.manageMenuItemDescription || undefined,
            menuCategoryId: this.manageMenuItemMenuCategoryId,
            price: Number(this.manageMenuItemPrice) || 0,
            itemType: this.manageMenuItemItemType,
            status: this.manageMenuItemStatus,
        };
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.menuItemLifecycle.manageMenuItem", params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.OutputManageMenuItem = data;
            setState("ui.menuManagement.output.manageMenuItem", data);
            // Refresh browseMenuItems after successful command
            try {
                await this.loadBrowseMenuItems();
                this.manageMenuItemState = "success";
                setState("ui.menuManagement.action.manageMenuItem.status", "success");
            }
            catch {
                this.manageMenuItemState = "error";
                setState("ui.menuManagement.action.manageMenuItem.status", "error");
                console.error("[menuManagement] refresh after manageMenuItem failed");
            }
        }
        else {
            this.manageMenuItemState = "error";
            setState("ui.menuManagement.action.manageMenuItem.status", "error");
            console.error("[menuManagement] manageMenuItem failed:", response.error);
        }
    }
    handleManageMenuItemClick() {
        runBlockingUiAction(async (_signal) => {
            await this.manageMenuItem();
        }, { mode: "blocking" });
    }
    // ── Lifecycle ──────────────────────────────────────────────────
    connectedCallback() {
        super.connectedCallback();
        // Initialize from shared state where useful
        const sharedActiveCompanyId = getState("ui.menuManagement.businessContext.activeCompanyId");
        if (sharedActiveCompanyId) {
            this.activeCompanyId = sharedActiveCompanyId;
        }
        else {
            setState("ui.menuManagement.businessContext.activeCompanyId", this.activeCompanyId);
        }
        // Subscribe to business context
        const ctxKey = "ui.menuManagement.businessContext.activeCompanyId";
        subscribe(ctxKey, this);
        this.subscribedKeys.push(ctxKey);
        // Run initial loads
        this.loadBrowseMenuItems();
    }
    disconnectedCallback() {
        for (const key of this.subscribedKeys) {
            unsubscribe(key, this);
        }
        this.subscribedKeys = [];
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "browseMenuItemsState", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "browseMenuItemsStatusFilter", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "browseMenuItemsMenuCategoryIdFilter", void 0);
__decorate([
    property({ type: Object })
], CafeFlowMenuManagementBase.prototype, "browseMenuItemsData", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemDescription", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemMenuCategoryId", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemPrice", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemItemType", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "activeCompanyId", void 0);
__decorate([
    property({ type: Object })
], CafeFlowMenuManagementBase.prototype, "OutputManageMenuItem", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "LayoutWs20ActivatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "LayoutWs30InactivatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "LayoutR50UpdatedAt", void 0);
