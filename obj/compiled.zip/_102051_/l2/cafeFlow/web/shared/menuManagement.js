/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/menuManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "menuManagement.section.main.title": "Gestão de cardápio",
    "menuManagement.organism.browseMenuItems.title": "Itens do cardápio",
    "menuManagement.organism.manageMenuItem.title": "Detalhes do item do cardápio",
    "menuManagement.intention.context.title": "Empresa ativa",
    "menuManagement.intention.browseMenuItems.list.title": "Lista de itens do cardápio",
    "menuManagement.intention.manageMenuItem.form.title": "Editar item do cardápio",
    "menuManagement.intention.manageMenuItem.status.title": "Status do item do cardápio",
    "menuManagement.field.name.label": "Nome",
    "menuManagement.field.description.label": "Descrição",
    "menuManagement.field.menuCategoryId.label": "Categoria",
    "menuManagement.field.price.label": "Preço",
    "menuManagement.field.itemType.label": "Tipo",
    "menuManagement.field.status.label": "Status",
    "menuManagement.field.updatedAt.label": "Atualizado em",
    "menuManagement.field.activatedAt.label": "Ativado em",
    "menuManagement.field.inactivatedAt.label": "Inativado em",
    "menuManagement.filter.statusFilter.label": "Status",
    "menuManagement.filter.menuCategoryIdFilter.label": "Categoria",
    "menuManagement.action.browseMenuItems.label": "Buscar itens",
    "menuManagement.action.manageMenuItem.label": "Salvar item"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowMenuManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.browseMenuItemsState = "idle";
        this.browseMenuItemsStatusFilter = '';
        this.browseMenuItemsMenuCategoryIdFilter = '';
        this.browseMenuItemsData = { items: [], total: 0 };
        this.manageMenuItemState = "idle";
        this.manageMenuItemName = '';
        this.manageMenuItemDescription = '';
        this.manageMenuItemMenuCategoryId = '';
        this.manageMenuItemPrice = '';
        this.manageMenuItemItemType = '';
        this.manageMenuItemStatus = '';
        this.activeCompanyId = '';
        this.LayoutFieldManageMenuItemActivatedAt = '';
        this.LayoutFieldManageMenuItemInactivatedAt = '';
        this.LayoutFieldManageMenuItemUpdatedAt = '';
        this.subscribedKeys = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.activeCompanyId = getState('ui.menuManagement.businessContext.activeCompanyId') || '';
        this.subscribedKeys = ['ui.menuManagement.businessContext.activeCompanyId'];
        subscribe(this.subscribedKeys, this);
        this.loadBrowseMenuItems();
    }
    disconnectedCallback() {
        if (this.subscribedKeys.length > 0) {
            unsubscribe(this.subscribedKeys, this);
        }
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (key === 'ui.menuManagement.businessContext.activeCompanyId') {
            this.activeCompanyId = value || '';
            this.requestUpdate();
        }
    }
    // ---- Query: browseMenuItems ----
    async loadBrowseMenuItems() {
        this.browseMenuItemsState = 'loading';
        setState('ui.menuManagement.action.browseMenuItems.status', 'loading');
        const params = {};
        if (this.browseMenuItemsStatusFilter) {
            params.statusFilter = this.browseMenuItemsStatusFilter;
        }
        if (this.browseMenuItemsMenuCategoryIdFilter) {
            params.menuCategoryIdFilter = this.browseMenuItemsMenuCategoryIdFilter;
        }
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.menuItemLifecycle.browseMenuItems', params, options);
        if (response.ok) {
            const data = response.data ?? { items: [], total: 0 };
            this.browseMenuItemsData = data;
            setState('ui.menuManagement.data.browseMenuItems', data);
            this.browseMenuItemsState = 'success';
            setState('ui.menuManagement.action.browseMenuItems.status', 'success');
        }
        else {
            this.browseMenuItemsState = 'error';
            setState('ui.menuManagement.action.browseMenuItems.status', 'error');
            console.error('[menuManagement] browseMenuItems failed:', response.error);
        }
    }
    handleBrowseMenuItemsClick(_e) {
        this.loadBrowseMenuItems();
    }
    // ---- Command: manageMenuItem ----
    async manageMenuItem() {
        this.manageMenuItemState = 'loading';
        setState('ui.menuManagement.action.manageMenuItem.status', 'loading');
        const params = {
            name: this.manageMenuItemName,
            menuCategoryId: this.manageMenuItemMenuCategoryId,
            price: Number(this.manageMenuItemPrice) || 0,
            itemType: this.manageMenuItemItemType,
            status: this.manageMenuItemStatus,
        };
        if (this.manageMenuItemDescription) {
            params.description = this.manageMenuItemDescription;
        }
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.menuItemLifecycle.manageMenuItem', params, options);
        if (response.ok) {
            // Refresh browseMenuItems after successful command
            try {
                await this.loadBrowseMenuItems();
                this.manageMenuItemState = 'success';
                setState('ui.menuManagement.action.manageMenuItem.status', 'success');
            }
            catch {
                this.manageMenuItemState = 'error';
                setState('ui.menuManagement.action.manageMenuItem.status', 'error');
                console.error('[menuManagement] refresh after manageMenuItem failed');
            }
        }
        else {
            this.manageMenuItemState = 'error';
            setState('ui.menuManagement.action.manageMenuItem.status', 'error');
            console.error('[menuManagement] manageMenuItem failed:', response.error);
        }
    }
    handleManageMenuItemClick(_e) {
        runBlockingUiAction(async (_signal) => {
            await this.manageMenuItem();
        }, { mode: 'blocking' });
    }
    // ---- State setters: browseMenuItems filters ----
    setBrowseMenuItemsStatusFilter(value) {
        this.browseMenuItemsStatusFilter = value;
        setState('ui.menuManagement.input.browseMenuItems.statusFilter', value);
        this.requestUpdate();
    }
    handleBrowseMenuItemsStatusFilterChange(e) {
        const target = e.target;
        this.setBrowseMenuItemsStatusFilter(target.value);
    }
    setBrowseMenuItemsMenuCategoryIdFilter(value) {
        this.browseMenuItemsMenuCategoryIdFilter = value;
        setState('ui.menuManagement.input.browseMenuItems.menuCategoryIdFilter', value);
        this.requestUpdate();
    }
    handleBrowseMenuItemsMenuCategoryIdFilterChange(e) {
        const target = e.target;
        this.setBrowseMenuItemsMenuCategoryIdFilter(target.value);
    }
    // ---- State setters: manageMenuItem form fields ----
    setManageMenuItemName(value) {
        this.manageMenuItemName = value;
        setState('ui.menuManagement.input.manageMenuItem.name', value);
        this.requestUpdate();
    }
    handleManageMenuItemNameChange(e) {
        const target = e.target;
        this.setManageMenuItemName(target.value);
    }
    setManageMenuItemDescription(value) {
        this.manageMenuItemDescription = value;
        setState('ui.menuManagement.input.manageMenuItem.description', value);
        this.requestUpdate();
    }
    handleManageMenuItemDescriptionChange(e) {
        const target = e.target;
        this.setManageMenuItemDescription(target.value);
    }
    setManageMenuItemMenuCategoryId(value) {
        this.manageMenuItemMenuCategoryId = value;
        setState('ui.menuManagement.input.manageMenuItem.menuCategoryId', value);
        this.requestUpdate();
    }
    handleManageMenuItemMenuCategoryIdChange(e) {
        const target = e.target;
        this.setManageMenuItemMenuCategoryId(target.value);
    }
    setManageMenuItemPrice(value) {
        this.manageMenuItemPrice = value;
        setState('ui.menuManagement.input.manageMenuItem.price', value);
        this.requestUpdate();
    }
    handleManageMenuItemPriceChange(e) {
        const target = e.target;
        this.setManageMenuItemPrice(target.value);
    }
    setManageMenuItemItemType(value) {
        this.manageMenuItemItemType = value;
        setState('ui.menuManagement.input.manageMenuItem.itemType', value);
        this.requestUpdate();
    }
    handleManageMenuItemItemTypeChange(e) {
        const target = e.target;
        this.setManageMenuItemItemType(target.value);
    }
    setManageMenuItemStatus(value) {
        this.manageMenuItemStatus = value;
        setState('ui.menuManagement.input.manageMenuItem.status', value);
        this.requestUpdate();
    }
    handleManageMenuItemStatusChange(e) {
        const target = e.target;
        this.setManageMenuItemStatus(target.value);
    }
}
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "browseMenuItemsState", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "browseMenuItemsStatusFilter", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "browseMenuItemsMenuCategoryIdFilter", void 0);
__decorate([
    property({ type: Object })
], CafeFlowMenuManagementBase.prototype, "browseMenuItemsData", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemDescription", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemMenuCategoryId", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemPrice", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemItemType", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "manageMenuItemStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "activeCompanyId", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "LayoutFieldManageMenuItemActivatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "LayoutFieldManageMenuItemInactivatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowMenuManagementBase.prototype, "LayoutFieldManageMenuItemUpdatedAt", void 0);
