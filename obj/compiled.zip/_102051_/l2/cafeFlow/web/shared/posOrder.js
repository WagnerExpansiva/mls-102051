/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/posOrder.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "posOrder.section.main.title": "POS — Lançamento e entrega de pedidos",
    "posOrder.organism.createOrder.title": "Lançar pedido",
    "posOrder.intent.createOrder.form.title": "Novo pedido",
    "posOrder.intent.createOrder.summary.title": "Resumo do pedido criado",
    "posOrder.organism.viewOrderBoard.title": "Painel de pedidos",
    "posOrder.intent.viewOrderBoard.list.title": "Pedidos do turno atual",
    "posOrder.organism.deliverOrder.title": "Entregar pedido",
    "posOrder.intent.deliverOrder.confirm.title": "Confirmar entrega",
    "posOrder.intent.deliverOrder.summary.title": "Resumo da entrega",
    "posOrder.field.orderType.label": "Tipo do pedido",
    "posOrder.field.tableNumber.label": "Número da mesa",
    "posOrder.field.priority.label": "Prioridade",
    "posOrder.field.priorityReason.label": "Motivo da prioridade",
    "posOrder.field.orderId.label": "Número do pedido",
    "posOrder.field.status.label": "Status",
    "posOrder.field.createdAt.label": "Criado em",
    "posOrder.field.receivedAt.label": "Recebido em",
    "posOrder.field.inPreparationAt.label": "Em preparo desde",
    "posOrder.field.readyAt.label": "Pronto em",
    "posOrder.field.deliveredAt.label": "Entregue em",
    "posOrder.filter.statusFilter.label": "Filtrar por status",
    "posOrder.action.viewOrderBoard.label": "Atualizar painel"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowPosOrderBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.createOrderState = "idle";
        this.createOrderOrderType = "";
        this.createOrderTableNumber = "";
        this.createOrderPriority = "";
        this.createOrderPriorityReason = "";
        this.viewOrderBoardState = "idle";
        this.viewOrderBoardStatusFilter = "";
        this.viewOrderBoardData = { items: [], total: 0 };
        this.deliverOrderState = "idle";
        this.activeCompanyId = "";
        this.LayoutFieldCreateOrderOrderId = "";
        this.LayoutFieldCreateOrderStatus = "";
        this.LayoutFieldCreateOrderCreatedAt = "";
        this.LayoutFieldDeliverOrderOrderId = "";
        this.LayoutFieldDeliverOrderStatus = "";
        this.LayoutFieldDeliverOrderDeliveredAt = "";
        this.LayoutFieldDeliverOrderOrderType = "";
        this.LayoutFieldDeliverOrderTableNumber = "";
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const savedCompanyId = getState("ui.posOrder.businessContext.activeCompanyId");
        if (savedCompanyId) {
            this.activeCompanyId = savedCompanyId;
        }
        subscribe("ui.posOrder.businessContext.activeCompanyId", this);
        this.loadViewOrderBoard();
    }
    disconnectedCallback() {
        unsubscribe("ui.posOrder.businessContext.activeCompanyId", this);
        super.disconnectedCallback();
    }
    // --- State setters ---
    setCreateOrderOrderType(value) {
        this.createOrderOrderType = value;
        setState("ui.posOrder.input.createOrder.orderType", value);
        this.requestUpdate();
    }
    handleCreateOrderOrderTypeChange(e) {
        const target = e.target;
        this.setCreateOrderOrderType(target.value);
    }
    setCreateOrderTableNumber(value) {
        this.createOrderTableNumber = value;
        setState("ui.posOrder.input.createOrder.tableNumber", value);
        this.requestUpdate();
    }
    handleCreateOrderTableNumberChange(e) {
        const target = e.target;
        this.setCreateOrderTableNumber(target.value);
    }
    setCreateOrderPriority(value) {
        this.createOrderPriority = value;
        setState("ui.posOrder.input.createOrder.priority", value);
        this.requestUpdate();
    }
    handleCreateOrderPriorityChange(e) {
        const target = e.target;
        const value = target.type === "checkbox"
            ? (target.checked ? "true" : "false")
            : target.value;
        this.setCreateOrderPriority(value);
    }
    setCreateOrderPriorityReason(value) {
        this.createOrderPriorityReason = value;
        setState("ui.posOrder.input.createOrder.priorityReason", value);
        this.requestUpdate();
    }
    handleCreateOrderPriorityReasonChange(e) {
        const target = e.target;
        this.setCreateOrderPriorityReason(target.value);
    }
    setViewOrderBoardStatusFilter(value) {
        this.viewOrderBoardStatusFilter = value;
        setState("ui.posOrder.input.viewOrderBoard.statusFilter", value);
        this.requestUpdate();
    }
    handleViewOrderBoardStatusFilterChange(e) {
        const target = e.target;
        this.setViewOrderBoardStatusFilter(target.value);
    }
    // --- Query action: viewOrderBoard ---
    async loadViewOrderBoard() {
        this.viewOrderBoardState = "loading";
        setState("ui.posOrder.action.viewOrderBoard.status", "loading");
        this.requestUpdate();
        const params = {
            statusFilter: (this.viewOrderBoardStatusFilter || undefined),
        };
        const response = await execBff("cafeFlow.orderLifecycle.viewOrderBoard", params, { mode: "silent" });
        if (!response.ok) {
            this.viewOrderBoardState = "error";
            setState("ui.posOrder.action.viewOrderBoard.status", "error");
            this.requestUpdate();
            return false;
        }
        const data = response.data ?? { items: [], total: 0 };
        this.viewOrderBoardData = data;
        setState("ui.posOrder.data.viewOrderBoard", data);
        this.viewOrderBoardState = "success";
        setState("ui.posOrder.action.viewOrderBoard.status", "success");
        this.requestUpdate();
        return true;
    }
    handleViewOrderBoardClick() {
        this.loadViewOrderBoard();
    }
    // --- Command action: createOrder ---
    async createOrder(signal) {
        this.createOrderState = "loading";
        setState("ui.posOrder.action.createOrder.status", "loading");
        this.requestUpdate();
        const params = {
            orderType: this.createOrderOrderType,
            tableNumber: this.createOrderTableNumber || undefined,
            priority: this.createOrderPriority === "true" ? true : undefined,
            priorityReason: this.createOrderPriorityReason || undefined,
        };
        const options = { mode: "blocking" };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff("cafeFlow.orderLifecycle.createOrder", params, options);
        if (!response.ok) {
            this.createOrderState = "error";
            setState("ui.posOrder.action.createOrder.status", "error");
            this.requestUpdate();
            return;
        }
        // Refresh: viewOrderBoard
        const refreshOk = await this.loadViewOrderBoard();
        if (refreshOk) {
            this.createOrderState = "success";
            setState("ui.posOrder.action.createOrder.status", "success");
        }
        else {
            this.createOrderState = "error";
            setState("ui.posOrder.action.createOrder.status", "error");
        }
        this.requestUpdate();
    }
    handleCreateOrderClick() {
        runBlockingUiAction(async (signal) => {
            await this.createOrder(signal);
        }, { mode: "blocking" });
    }
    // --- Command action: deliverOrder ---
    async deliverOrder(orderId, signal) {
        this.deliverOrderState = "loading";
        setState("ui.posOrder.action.deliverOrder.status", "loading");
        this.requestUpdate();
        const params = orderId ? { orderId } : {};
        const options = { mode: "blocking" };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff("cafeFlow.orderLifecycle.deliverOrder", params, options);
        if (!response.ok) {
            this.deliverOrderState = "error";
            setState("ui.posOrder.action.deliverOrder.status", "error");
            this.requestUpdate();
            return;
        }
        // Refresh: viewOrderBoard
        const refreshOk = await this.loadViewOrderBoard();
        if (refreshOk) {
            this.deliverOrderState = "success";
            setState("ui.posOrder.action.deliverOrder.status", "success");
        }
        else {
            this.deliverOrderState = "error";
            setState("ui.posOrder.action.deliverOrder.status", "error");
        }
        this.requestUpdate();
    }
    handleDeliverOrderClick(orderId) {
        runBlockingUiAction(async (signal) => {
            await this.deliverOrder(orderId, signal);
        }, { mode: "blocking" });
    }
}
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "createOrderState", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "createOrderOrderType", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "createOrderTableNumber", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "createOrderPriority", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "createOrderPriorityReason", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "viewOrderBoardState", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "viewOrderBoardStatusFilter", void 0);
__decorate([
    property({ type: Object })
], CafeFlowPosOrderBase.prototype, "viewOrderBoardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "deliverOrderState", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "activeCompanyId", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "LayoutFieldCreateOrderOrderId", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "LayoutFieldCreateOrderStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "LayoutFieldCreateOrderCreatedAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "LayoutFieldDeliverOrderOrderId", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "LayoutFieldDeliverOrderStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "LayoutFieldDeliverOrderDeliveredAt", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "LayoutFieldDeliverOrderOrderType", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosOrderBase.prototype, "LayoutFieldDeliverOrderTableNumber", void 0);
