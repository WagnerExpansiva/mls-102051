/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/posWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "posWorkspace.section.orderBoard.title": "Painel de pedidos",
    "posWorkspace.organism.orderBoard.title": "Pedidos do turno",
    "posWorkspace.intent.orderBoardCards.title": "Fila de pedidos",
    "posWorkspace.action.refreshBoard": "Atualizar painel",
    "posWorkspace.section.createOrder.title": "Lançar pedido",
    "posWorkspace.organism.createOrder.title": "Novo pedido",
    "posWorkspace.intent.createOrder.details": "Detalhes do pedido",
    "posWorkspace.action.createOrder": "Confirmar pedido",
    "posWorkspace.section.review.title": "Revisão do pedido",
    "posWorkspace.organism.review.title": "Resumo e alertas",
    "posWorkspace.intent.reviewSummary.title": "Resumo do lançamento",
    "posWorkspace.section.deliver.title": "Entrega do pedido",
    "posWorkspace.organism.deliver.title": "Confirmar entrega",
    "posWorkspace.intent.deliverOrder.title": "Entregar pedido",
    "posWorkspace.action.deliverOrder": "Marcar como entregue",
    "posWorkspace.field.orderId": "Pedido",
    "posWorkspace.field.status": "Status",
    "posWorkspace.field.orderType": "Tipo do pedido",
    "posWorkspace.field.tableNumber": "Mesa",
    "posWorkspace.field.priority": "Prioridade",
    "posWorkspace.field.priorityReason": "Justificativa da prioridade",
    "posWorkspace.field.readyAt": "Pronto em",
    "posWorkspace.field.createdAt": "Criado em",
    "posWorkspace.field.orderItems": "Itens do pedido",
    "posWorkspace.section.pipeline.title": "Pipeline de pedidos",
    "posWorkspace.organism.kanban.title": "Pedidos por status",
    "posWorkspace.intent.kanban.title": "Pedidos em fluxo",
    "posWorkspace.section.queue.title": "Fila de pedidos",
    "posWorkspace.organism.queue.title": "Pedidos em andamento",
    "posWorkspace.intent.queue.title": "Fila do turno"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowPosWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.createOrderState = "idle";
        this.createOrderOrderType = '';
        this.createOrderTableNumber = '';
        this.createOrderOrderItems = '';
        this.createOrderPriority = '';
        this.createOrderPriorityReason = '';
        this.viewOrderBoardState = "idle";
        this.viewOrderBoardData = { items: [], total: 0 };
        this.deliverOrderState = "idle";
        this.OutputCreateOrder = null;
        this.OutputDeliverOrder = null;
        this.LayoutFld130 = '';
        this.LayoutFld140 = '';
        this.LayoutFld150 = '';
        this.LayoutFld60 = '';
        this.LayoutFld70 = '';
        this.LayoutFld80 = '';
        this.subscribedKeys = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    // ── State setters ──────────────────────────────────────────────
    setCreateOrderOrderType(value) {
        this.createOrderOrderType = value;
        setState('ui.posWorkspace.input.createOrder.orderType', value);
        this.requestUpdate();
    }
    handleCreateOrderOrderTypeChange(e) {
        const target = e.target;
        this.setCreateOrderOrderType(target.value);
    }
    setCreateOrderTableNumber(value) {
        this.createOrderTableNumber = value;
        setState('ui.posWorkspace.input.createOrder.tableNumber', value);
        this.requestUpdate();
    }
    handleCreateOrderTableNumberChange(e) {
        const target = e.target;
        this.setCreateOrderTableNumber(target.value);
    }
    setCreateOrderOrderItems(value) {
        this.createOrderOrderItems = value;
        setState('ui.posWorkspace.input.createOrder.orderItems', value);
        this.requestUpdate();
    }
    handleCreateOrderOrderItemsChange(e) {
        const target = e.target;
        this.setCreateOrderOrderItems(target.value);
    }
    setCreateOrderPriority(value) {
        this.createOrderPriority = value;
        setState('ui.posWorkspace.input.createOrder.priority', value);
        this.requestUpdate();
    }
    handleCreateOrderPriorityChange(e) {
        const target = e.target;
        if (target.type === 'checkbox') {
            this.setCreateOrderPriority(target.checked ? 'true' : 'false');
        }
        else {
            this.setCreateOrderPriority(target.value);
        }
    }
    setCreateOrderPriorityReason(value) {
        this.createOrderPriorityReason = value;
        setState('ui.posWorkspace.input.createOrder.priorityReason', value);
        this.requestUpdate();
    }
    handleCreateOrderPriorityReasonChange(e) {
        const target = e.target;
        this.setCreateOrderPriorityReason(target.value);
    }
    // ── Query: viewOrderBoard ──────────────────────────────────────
    async loadViewOrderBoard() {
        this.viewOrderBoardState = 'loading';
        setState('ui.posWorkspace.action.viewOrderBoard.status', 'loading');
        this.requestUpdate();
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.orderLifecycle.viewOrderBoard', {}, options);
        if (response.ok) {
            const data = response.data;
            if (data) {
                this.viewOrderBoardData = { items: data.items, total: data.total };
            }
            else {
                this.viewOrderBoardData = { items: [], total: 0 };
            }
            setState('ui.posWorkspace.data.viewOrderBoard', this.viewOrderBoardData);
            this.viewOrderBoardState = 'success';
            setState('ui.posWorkspace.action.viewOrderBoard.status', 'success');
        }
        else {
            this.viewOrderBoardState = 'error';
            setState('ui.posWorkspace.action.viewOrderBoard.status', 'error');
            if (response.error) {
                console.error('[posWorkspace] viewOrderBoard error:', response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleViewOrderBoardClick(e) {
        e.preventDefault();
        this.loadViewOrderBoard();
    }
    // ── Command: createOrder ───────────────────────────────────────
    async createOrder() {
        this.createOrderState = 'loading';
        setState('ui.posWorkspace.action.createOrder.status', 'loading');
        this.requestUpdate();
        const params = {
            orderType: this.createOrderOrderType,
            orderItems: this.createOrderOrderItems,
        };
        if (this.createOrderTableNumber) {
            params.tableNumber = this.createOrderTableNumber;
        }
        const priorityValue = this.createOrderPriority;
        if (priorityValue === 'true' || priorityValue === 'false') {
            params.priority = priorityValue === 'true';
        }
        if (this.createOrderPriorityReason) {
            params.priorityReason = this.createOrderPriorityReason;
        }
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.orderLifecycle.createOrder', params, options);
        if (response.ok) {
            this.OutputCreateOrder = response.data ?? null;
            setState('ui.posWorkspace.output.createOrder', this.OutputCreateOrder);
            // Refresh viewOrderBoard after successful command
            await this.loadViewOrderBoard();
            if (this.viewOrderBoardState === 'error') {
                this.createOrderState = 'error';
                setState('ui.posWorkspace.action.createOrder.status', 'error');
            }
            else {
                this.createOrderState = 'success';
                setState('ui.posWorkspace.action.createOrder.status', 'success');
            }
        }
        else {
            this.createOrderState = 'error';
            setState('ui.posWorkspace.action.createOrder.status', 'error');
            if (response.error) {
                console.error('[posWorkspace] createOrder error:', response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleCreateOrderClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.createOrder();
        }, { mode: 'blocking', busyLabel: this.msg['posWorkspace.action.createOrder'] });
    }
    // ── Command: deliverOrder ──────────────────────────────────────
    async deliverOrder() {
        this.deliverOrderState = 'loading';
        setState('ui.posWorkspace.action.deliverOrder.status', 'loading');
        this.requestUpdate();
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.orderLifecycle.deliverOrder', {}, options);
        if (response.ok) {
            this.OutputDeliverOrder = response.data ?? null;
            setState('ui.posWorkspace.output.deliverOrder', this.OutputDeliverOrder);
            // Refresh viewOrderBoard after successful command
            await this.loadViewOrderBoard();
            if (this.viewOrderBoardState === 'error') {
                this.deliverOrderState = 'error';
                setState('ui.posWorkspace.action.deliverOrder.status', 'error');
            }
            else {
                this.deliverOrderState = 'success';
                setState('ui.posWorkspace.action.deliverOrder.status', 'success');
            }
        }
        else {
            this.deliverOrderState = 'error';
            setState('ui.posWorkspace.action.deliverOrder.status', 'error');
            if (response.error) {
                console.error('[posWorkspace] deliverOrder error:', response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleDeliverOrderClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.deliverOrder();
        }, { mode: 'blocking', busyLabel: this.msg['posWorkspace.action.deliverOrder'] });
    }
    // ── Lifecycle ──────────────────────────────────────────────────
    connectedCallback() {
        super.connectedCallback();
        // Initialize state from global store, falling back to defaults
        const savedStatus = getState('ui.posWorkspace.status');
        this.status = savedStatus !== undefined ? savedStatus : '';
        const savedCreateOrderState = getState('ui.posWorkspace.action.createOrder.status');
        this.createOrderState = savedCreateOrderState !== undefined ? savedCreateOrderState : 'idle';
        const savedViewOrderBoardState = getState('ui.posWorkspace.action.viewOrderBoard.status');
        this.viewOrderBoardState = savedViewOrderBoardState !== undefined ? savedViewOrderBoardState : 'idle';
        const savedViewOrderBoardData = getState('ui.posWorkspace.data.viewOrderBoard');
        this.viewOrderBoardData = savedViewOrderBoardData !== undefined
            ? savedViewOrderBoardData
            : { items: [], total: 0 };
        const savedDeliverOrderState = getState('ui.posWorkspace.action.deliverOrder.status');
        this.deliverOrderState = savedDeliverOrderState !== undefined ? savedDeliverOrderState : 'idle';
        // Subscribe to shared states
        const keys = [
            'ui.posWorkspace.status',
            'ui.posWorkspace.action.createOrder.status',
            'ui.posWorkspace.action.viewOrderBoard.status',
            'ui.posWorkspace.data.viewOrderBoard',
            'ui.posWorkspace.action.deliverOrder.status',
        ];
        this.subscribedKeys = keys;
        subscribe(keys, this);
        // Run initial loads
        this.loadViewOrderBoard();
    }
    disconnectedCallback() {
        if (this.subscribedKeys.length > 0) {
            unsubscribe(this.subscribedKeys, this);
            this.subscribedKeys = [];
        }
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderState", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderOrderType", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderTableNumber", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderOrderItems", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderPriority", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderPriorityReason", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "viewOrderBoardState", void 0);
__decorate([
    property({ type: Object })
], CafeFlowPosWorkspaceBase.prototype, "viewOrderBoardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "deliverOrderState", void 0);
__decorate([
    property({ type: Object })
], CafeFlowPosWorkspaceBase.prototype, "OutputCreateOrder", void 0);
__decorate([
    property({ type: Object })
], CafeFlowPosWorkspaceBase.prototype, "OutputDeliverOrder", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "LayoutFld130", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "LayoutFld140", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "LayoutFld150", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "LayoutFld60", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "LayoutFld70", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "LayoutFld80", void 0);
