/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/posWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "posWorkspace.section.main.title": "POS — Lançamento e acompanhamento de pedidos",
    "posWorkspace.organism.createOrder.title": "Lançar pedido no POS",
    "posWorkspace.createOrder.form.title": "Command Form",
    "posWorkspace.createOrder.orderType.label": "Order Type",
    "posWorkspace.createOrder.tableNumber.label": "Table Number",
    "posWorkspace.createOrder.orderItems.label": "Order Items",
    "posWorkspace.createOrder.priority.label": "Priority",
    "posWorkspace.createOrder.priorityReason.label": "Priority Reason",
    "posWorkspace.createOrder.review.title": "Summary",
    "posWorkspace.createOrder.submit.label": "Create Order",
    "posWorkspace.organism.viewOrderBoard.title": "Visualizar painel de pedidos",
    "posWorkspace.viewOrderBoard.list.title": "Query List",
    "posWorkspace.viewOrderBoard.orderId.label": "Order Id",
    "posWorkspace.viewOrderBoard.status.label": "Status",
    "posWorkspace.viewOrderBoard.orderType.label": "Order Type",
    "posWorkspace.viewOrderBoard.tableNumber.label": "Table Number",
    "posWorkspace.viewOrderBoard.priority.label": "Priority",
    "posWorkspace.viewOrderBoard.priorityReason.label": "Priority Reason",
    "posWorkspace.viewOrderBoard.receivedAt.label": "Received At",
    "posWorkspace.viewOrderBoard.inPreparationAt.label": "In Preparation At",
    "posWorkspace.viewOrderBoard.readyAt.label": "Ready At",
    "posWorkspace.viewOrderBoard.createdAt.label": "Created At",
    "posWorkspace.viewOrderBoard.refresh.label": "View Order Board",
    "posWorkspace.viewOrderBoard.deliver.label": "Deliver Order",
    "posWorkspace.organism.deliverOrder.title": "Entregar pedido ao cliente",
    "posWorkspace.deliverOrder.confirm.title": "Command Form",
    "posWorkspace.deliverOrder.submit.label": "Deliver Order"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowPosWorkspaceBase extends CollabLitElement {
    constructor() {
        // ── State properties ──────────────────────────────────────────────
        super(...arguments);
        this.status = "";
        this.createOrderState = "idle";
        this.createOrderOrderType = "";
        this.createOrderTableNumber = "";
        this.createOrderOrderItems = "";
        this.createOrderPriority = "";
        this.createOrderPriorityReason = "";
        this.viewOrderBoardState = "idle";
        this.viewOrderBoardData = { items: [], total: 0 };
        this.deliverOrderState = "idle";
    }
    // ── i18n getter ───────────────────────────────────────────────────
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    // ── State setters ─────────────────────────────────────────────────
    setCreateOrderOrderType(value) {
        this.createOrderOrderType = value;
        setState("ui.posWorkspace.input.createOrder.orderType", value);
        this.requestUpdate();
    }
    handleCreateOrderOrderTypeChange(e) {
        const target = e.target;
        this.setCreateOrderOrderType(target.value);
    }
    setCreateOrderTableNumber(value) {
        this.createOrderTableNumber = value;
        setState("ui.posWorkspace.input.createOrder.tableNumber", value);
        this.requestUpdate();
    }
    handleCreateOrderTableNumberChange(e) {
        const target = e.target;
        this.setCreateOrderTableNumber(target.value);
    }
    setCreateOrderOrderItems(value) {
        this.createOrderOrderItems = value;
        setState("ui.posWorkspace.input.createOrder.orderItems", value);
        this.requestUpdate();
    }
    handleCreateOrderOrderItemsChange(e) {
        const target = e.target;
        this.setCreateOrderOrderItems(target.value);
    }
    setCreateOrderPriority(value) {
        this.createOrderPriority = value;
        setState("ui.posWorkspace.input.createOrder.priority", value);
        this.requestUpdate();
    }
    handleCreateOrderPriorityChange(e) {
        const target = e.target;
        this.setCreateOrderPriority(target.value);
    }
    setCreateOrderPriorityReason(value) {
        this.createOrderPriorityReason = value;
        setState("ui.posWorkspace.input.createOrder.priorityReason", value);
        this.requestUpdate();
    }
    handleCreateOrderPriorityReasonChange(e) {
        const target = e.target;
        this.setCreateOrderPriorityReason(target.value);
    }
    // ── Query: viewOrderBoard ─────────────────────────────────────────
    async loadViewOrderBoard() {
        this.viewOrderBoardState = "loading";
        setState("ui.posWorkspace.action.viewOrderBoard.status", "loading");
        const options = { mode: "silent" };
        const response = await execBff("cafeFlow.orderLifecycle.viewOrderBoard", {}, options);
        if (!response.ok) {
            this.viewOrderBoardState = "error";
            setState("ui.posWorkspace.action.viewOrderBoard.status", "error");
            return;
        }
        const data = response.data ?? { items: [], total: 0 };
        this.viewOrderBoardData = data;
        setState("ui.posWorkspace.data.viewOrderBoard", data);
        this.viewOrderBoardState = "success";
        setState("ui.posWorkspace.action.viewOrderBoard.status", "success");
    }
    handleViewOrderBoardClick(e) {
        e.preventDefault();
        this.loadViewOrderBoard();
    }
    // ── Command: createOrder ──────────────────────────────────────────
    async createOrder() {
        this.createOrderState = "loading";
        setState("ui.posWorkspace.action.createOrder.status", "loading");
        const params = {
            orderType: this.createOrderOrderType,
            orderItems: this.createOrderOrderItems,
            tableNumber: this.createOrderTableNumber || undefined,
            priority: this.createOrderPriority === ""
                ? undefined
                : this.createOrderPriority === "true",
            priorityReason: this.createOrderPriorityReason || undefined,
        };
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.orderLifecycle.createOrder", params, options);
        if (!response.ok) {
            this.createOrderState = "error";
            setState("ui.posWorkspace.action.createOrder.status", "error");
            return;
        }
        // Refresh viewOrderBoard after successful command
        await this.loadViewOrderBoard();
        if (this.viewOrderBoardState === "error") {
            this.createOrderState = "error";
            setState("ui.posWorkspace.action.createOrder.status", "error");
            return;
        }
        this.createOrderState = "success";
        setState("ui.posWorkspace.action.createOrder.status", "success");
    }
    handleCreateOrderClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.createOrder();
        }, { mode: "blocking" });
    }
    // ── Command: deliverOrder ─────────────────────────────────────────
    async deliverOrder() {
        this.deliverOrderState = "loading";
        setState("ui.posWorkspace.action.deliverOrder.status", "loading");
        // TODO: deliverOrder requires an orderId input that is not declared in Definition.states[]
        const options = { mode: "blocking" };
        const response = await execBff("cafeFlow.orderLifecycle.deliverOrder", {}, options);
        if (!response.ok) {
            this.deliverOrderState = "error";
            setState("ui.posWorkspace.action.deliverOrder.status", "error");
            return;
        }
        // Refresh viewOrderBoard after successful command
        await this.loadViewOrderBoard();
        if (this.viewOrderBoardState === "error") {
            this.deliverOrderState = "error";
            setState("ui.posWorkspace.action.deliverOrder.status", "error");
            return;
        }
        this.deliverOrderState = "success";
        setState("ui.posWorkspace.action.deliverOrder.status", "success");
    }
    handleDeliverOrderClick(e) {
        e.preventDefault();
        runBlockingUiAction(async () => {
            await this.deliverOrder();
        }, { mode: "blocking" });
    }
    // ── Lifecycle ─────────────────────────────────────────────────────
    connectedCallback() {
        super.connectedCallback();
        // Initialize state from global store where useful
        const savedStatus = getState("ui.posWorkspace.status");
        if (savedStatus !== undefined) {
            this.status = savedStatus;
        }
        // Run initial loads
        this.loadViewOrderBoard();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderState", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderOrderType", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderTableNumber", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderOrderItems", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderPriority", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "createOrderPriorityReason", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "viewOrderBoardState", void 0);
__decorate([
    property({ type: Object })
], CafeFlowPosWorkspaceBase.prototype, "viewOrderBoardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowPosWorkspaceBase.prototype, "deliverOrderState", void 0);
