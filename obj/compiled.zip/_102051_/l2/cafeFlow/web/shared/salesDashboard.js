/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/salesDashboard.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "salesDashboard.section.dashboardAi.title": "Dashboard e assistente IA",
    "salesDashboard.organism.viewDashboard.title": "Dashboard do dia",
    "salesDashboard.organism.requestAiSalesSummary.title": "Resumo de vendas por IA",
    "salesDashboard.organism.requestAiPromoSuggestions.title": "Sugestões de promoção por IA",
    "salesDashboard.intent.dashboard.context.title": "Turno atual",
    "salesDashboard.intent.dashboard.data.title": "Dados do dashboard do dia",
    "salesDashboard.intent.dashboard.lowStock.title": "Alertas de estoque baixo",
    "salesDashboard.intent.aiSales.request.title": "Solicitar resumo de vendas",
    "salesDashboard.intent.aiSales.output.title": "Resumo de vendas (IA)",
    "salesDashboard.intent.aiPromo.request.title": "Solicitar sugestões de promoção",
    "salesDashboard.intent.aiPromo.output.title": "Sugestões de promoção (IA)",
    "salesDashboard.field.shiftId.label": "Turno",
    "salesDashboard.field.orderId.label": "Pedido",
    "salesDashboard.field.status.label": "Status",
    "salesDashboard.field.orderType.label": "Tipo de pedido",
    "salesDashboard.field.createdAt.label": "Criado em",
    "salesDashboard.field.menuItemId.label": "Item do cardápio",
    "salesDashboard.field.quantity.label": "Quantidade",
    "salesDashboard.field.stockItemId.label": "Item de estoque",
    "salesDashboard.field.currentQuantity.label": "Quantidade atual",
    "salesDashboard.field.minimumQuantity.label": "Quantidade mínima",
    "salesDashboard.field.summaryRequest.label": "Solicitação do resumo",
    "salesDashboard.field.deliveredAt.label": "Entregue em",
    "salesDashboard.field.menuItemName.label": "Nome do item",
    "salesDashboard.action.viewDashboard.label": "Atualizar dashboard",
    "salesDashboard.action.requestAiSalesSummary.label": "Gerar resumo IA",
    "salesDashboard.action.requestAiPromoSuggestions.label": "Gerar sugestões IA"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowSalesDashboardBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.viewDashboardState = "idle";
        this.viewDashboardData = [];
        this.requestAiSalesSummaryState = "idle";
        this.requestAiSalesSummarySummaryRequest = "";
        this.requestAiSalesSummaryData = [];
        this.requestAiPromoSuggestionsState = "idle";
        this.requestAiPromoSuggestionsData = [];
        this.activeCompanyId = "";
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        const savedActiveCompanyId = getState("ui.salesDashboard.businessContext.activeCompanyId");
        if (savedActiveCompanyId !== undefined && savedActiveCompanyId !== null) {
            this.activeCompanyId = savedActiveCompanyId;
        }
        subscribe("ui.salesDashboard.businessContext.activeCompanyId", this);
        this.loadViewDashboard();
        this.loadRequestAiSalesSummary();
        this.loadRequestAiPromoSuggestions();
    }
    disconnectedCallback() {
        unsubscribe("ui.salesDashboard.businessContext.activeCompanyId", this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (key === "ui.salesDashboard.businessContext.activeCompanyId") {
            this.activeCompanyId = value ?? "";
        }
    }
    // --- Action: viewDashboard (query) ---
    async loadViewDashboard() {
        this.viewDashboardState = "loading";
        setState("ui.salesDashboard.action.viewDashboard.status", "loading");
        this.requestUpdate();
        const options = { mode: "silent" };
        const response = await execBff("cafeFlow.viewDashboard.viewDashboard", {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.viewDashboardData = data;
            setState("ui.salesDashboard.data.viewDashboard", data);
            this.viewDashboardState = "success";
            setState("ui.salesDashboard.action.viewDashboard.status", "success");
        }
        else {
            this.viewDashboardState = "error";
            setState("ui.salesDashboard.action.viewDashboard.status", "error");
            if (response.error) {
                console.error("[salesDashboard] viewDashboard error:", response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleViewDashboardClick(_e) {
        this.loadViewDashboard();
    }
    // --- Action: requestAiSalesSummary (query) ---
    async loadRequestAiSalesSummary() {
        this.requestAiSalesSummaryState = "loading";
        setState("ui.salesDashboard.action.requestAiSalesSummary.status", "loading");
        this.requestUpdate();
        const params = {
            summaryRequest: this.requestAiSalesSummarySummaryRequest,
        };
        const options = { mode: "silent" };
        const response = await execBff("cafeFlow.requestAiSalesSummary.requestAiSalesSummary", params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.requestAiSalesSummaryData = data;
            setState("ui.salesDashboard.data.requestAiSalesSummary", data);
            this.requestAiSalesSummaryState = "success";
            setState("ui.salesDashboard.action.requestAiSalesSummary.status", "success");
        }
        else {
            this.requestAiSalesSummaryState = "error";
            setState("ui.salesDashboard.action.requestAiSalesSummary.status", "error");
            if (response.error) {
                console.error("[salesDashboard] requestAiSalesSummary error:", response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleRequestAiSalesSummaryClick(_e) {
        this.loadRequestAiSalesSummary();
    }
    // --- Action: requestAiPromoSuggestions (query) ---
    async loadRequestAiPromoSuggestions() {
        this.requestAiPromoSuggestionsState = "loading";
        setState("ui.salesDashboard.action.requestAiPromoSuggestions.status", "loading");
        this.requestUpdate();
        const options = { mode: "silent" };
        const response = await execBff("cafeFlow.requestAiPromoSuggestions.requestAiPromoSuggestions", {}, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.requestAiPromoSuggestionsData = data;
            setState("ui.salesDashboard.data.requestAiPromoSuggestions", data);
            this.requestAiPromoSuggestionsState = "success";
            setState("ui.salesDashboard.action.requestAiPromoSuggestions.status", "success");
        }
        else {
            this.requestAiPromoSuggestionsState = "error";
            setState("ui.salesDashboard.action.requestAiPromoSuggestions.status", "error");
            if (response.error) {
                console.error("[salesDashboard] requestAiPromoSuggestions error:", response.error.message);
            }
        }
        this.requestUpdate();
    }
    handleRequestAiPromoSuggestionsClick(_e) {
        this.loadRequestAiPromoSuggestions();
    }
    // --- Action: set.requestAiSalesSummarySummaryRequest (stateSetter) ---
    setRequestAiSalesSummarySummaryRequest(value) {
        this.requestAiSalesSummarySummaryRequest = value;
        setState("ui.salesDashboard.input.requestAiSalesSummary.summaryRequest", value);
        this.requestUpdate();
    }
    handleRequestAiSalesSummarySummaryRequestChange(e) {
        const target = e.target;
        if (!target)
            return;
        const value = target.value ?? "";
        this.setRequestAiSalesSummarySummaryRequest(value);
    }
}
__decorate([
    property({ type: String })
], CafeFlowSalesDashboardBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowSalesDashboardBase.prototype, "viewDashboardState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowSalesDashboardBase.prototype, "viewDashboardData", void 0);
__decorate([
    property({ type: String })
], CafeFlowSalesDashboardBase.prototype, "requestAiSalesSummaryState", void 0);
__decorate([
    property({ type: String })
], CafeFlowSalesDashboardBase.prototype, "requestAiSalesSummarySummaryRequest", void 0);
__decorate([
    property({ type: Array })
], CafeFlowSalesDashboardBase.prototype, "requestAiSalesSummaryData", void 0);
__decorate([
    property({ type: String })
], CafeFlowSalesDashboardBase.prototype, "requestAiPromoSuggestionsState", void 0);
__decorate([
    property({ type: Array })
], CafeFlowSalesDashboardBase.prototype, "requestAiPromoSuggestionsData", void 0);
__decorate([
    property({ type: String })
], CafeFlowSalesDashboardBase.prototype, "activeCompanyId", void 0);
