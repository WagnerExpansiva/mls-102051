/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/shiftManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "shiftManagement.section.openShift.title": "Abertura do turno",
    "shiftManagement.section.closeShift.title": "Fechamento do turno",
    "shiftManagement.section.reports.title": "Relatórios de fechamento",
    "shiftManagement.section.summary.title": "Resumo do fechamento",
    "shiftManagement.organism.openShift.title": "Abrir turno diário",
    "shiftManagement.organism.closeShift.title": "Fechar turno diário",
    "shiftManagement.organism.reports.title": "Relatórios de fechamento",
    "shiftManagement.organism.summary.title": "Resumo do relatório",
    "shiftManagement.intention.openShift.title": "Abrir turno",
    "shiftManagement.intention.closeShift.title": "Fechar turno",
    "shiftManagement.intention.reports.title": "Relatórios de fechamento",
    "shiftManagement.intention.summary.title": "Resumo do fechamento",
    "shiftManagement.field.notes.label": "Observações",
    "shiftManagement.field.totalApurado.label": "Total apurado",
    "shiftManagement.field.shiftId.label": "Turno",
    "shiftManagement.field.paidOrderCount.label": "Pedidos pagos",
    "shiftManagement.field.createdAt.label": "Criado em",
    "shiftManagement.field.updatedAt.label": "Atualizado em",
    "shiftManagement.field.shiftClosingReportId.label": "Relatório",
    "shiftManagement.action.openShift.label": "Abrir turno",
    "shiftManagement.action.closeShift.label": "Fechar turno",
    "shiftManagement.action.viewShiftClosingReport.label": "Ver relatório",
    "shiftManagement.section.board.title": "Turnos por status",
    "shiftManagement.section.actions.title": "Ações rápidas",
    "shiftManagement.organism.board.title": "Quadro de turnos",
    "shiftManagement.intention.board.title": "Turnos por status",
    "shiftManagement.field.status.label": "Status",
    "shiftManagement.field.openedAt.label": "Abertura",
    "shiftManagement.field.closedAt.label": "Fechamento",
    "shiftManagement.section.queue.title": "Fila de turnos",
    "shiftManagement.organism.queue.title": "Fila de turnos",
    "shiftManagement.intention.queue.title": "Turnos na fila"
};
const messages = { pt: message_pt };
export class CafeFlowShiftManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = "";
        this.openShiftState = "idle";
        this.openShiftNotes = "";
        this.closeShiftState = "idle";
        this.closeShiftTotalApurado = "";
        this.closeShiftNotes = "";
        this.viewShiftClosingReportState = "idle";
        this.viewShiftClosingReportData = null;
        this.OutputOpenShift = null;
        this.OutputCloseShift = null;
        this.LayoutColBoardStatus = "";
        this.LayoutColBoardOpened = "";
        this.LayoutColBoardClosed = "";
        this.LayoutColQueueStatus = "";
        this.LayoutColQueueOpened = "";
        this.LayoutColQueueClosed = "";
        this.subscribedKeys = [];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState("ui.shiftManagement.status") ?? "";
        this.openShiftState = getState("ui.shiftManagement.action.openShift.status") ?? "idle";
        this.openShiftNotes = getState("ui.shiftManagement.input.openShift.notes") ?? "";
        this.closeShiftState = getState("ui.shiftManagement.action.closeShift.status") ?? "idle";
        this.closeShiftTotalApurado = getState("ui.shiftManagement.input.closeShift.totalApurado") ?? "";
        this.closeShiftNotes = getState("ui.shiftManagement.input.closeShift.notes") ?? "";
        this.viewShiftClosingReportState = getState("ui.shiftManagement.action.viewShiftClosingReport.status") ?? "idle";
        this.viewShiftClosingReportData = getState("ui.shiftManagement.data.viewShiftClosingReport") ?? null;
        this.OutputOpenShift = getState("ui.shiftManagement.output.openShift") ?? null;
        this.OutputCloseShift = getState("ui.shiftManagement.output.closeShift") ?? null;
        this.LayoutColBoardStatus = getState("ui.shiftManagement.layout.col-board-status") ?? "";
        this.LayoutColBoardOpened = getState("ui.shiftManagement.layout.col-board-opened") ?? "";
        this.LayoutColBoardClosed = getState("ui.shiftManagement.layout.col-board-closed") ?? "";
        this.LayoutColQueueStatus = getState("ui.shiftManagement.layout.col-queue-status") ?? "";
        this.LayoutColQueueOpened = getState("ui.shiftManagement.layout.col-queue-opened") ?? "";
        this.LayoutColQueueClosed = getState("ui.shiftManagement.layout.col-queue-closed") ?? "";
        const sharedKeys = [
            "ui.shiftManagement.status",
            "ui.shiftManagement.action.openShift.status",
            "ui.shiftManagement.input.openShift.notes",
            "ui.shiftManagement.action.closeShift.status",
            "ui.shiftManagement.input.closeShift.totalApurado",
            "ui.shiftManagement.input.closeShift.notes",
            "ui.shiftManagement.action.viewShiftClosingReport.status",
            "ui.shiftManagement.data.viewShiftClosingReport",
            "ui.shiftManagement.output.openShift",
            "ui.shiftManagement.output.closeShift",
        ];
        subscribe(sharedKeys, this);
        this.subscribedKeys = sharedKeys;
        this.loadViewShiftClosingReport();
    }
    disconnectedCallback() {
        if (this.subscribedKeys.length > 0) {
            unsubscribe(this.subscribedKeys, this);
            this.subscribedKeys = [];
        }
        super.disconnectedCallback();
    }
    // --- State setters ---
    setOpenShiftNotes(value) {
        this.openShiftNotes = value;
        setState("ui.shiftManagement.input.openShift.notes", value);
        this.requestUpdate();
    }
    handleOpenShiftNotesChange(e) {
        const target = e.target;
        this.setOpenShiftNotes(target.value ?? "");
    }
    setCloseShiftTotalApurado(value) {
        this.closeShiftTotalApurado = value;
        setState("ui.shiftManagement.input.closeShift.totalApurado", value);
        this.requestUpdate();
    }
    handleCloseShiftTotalApuradoChange(e) {
        const target = e.target;
        this.setCloseShiftTotalApurado(target.value ?? "");
    }
    setCloseShiftNotes(value) {
        this.closeShiftNotes = value;
        setState("ui.shiftManagement.input.closeShift.notes", value);
        this.requestUpdate();
    }
    handleCloseShiftNotesChange(e) {
        const target = e.target;
        this.setCloseShiftNotes(target.value ?? "");
    }
    // --- Query action: viewShiftClosingReport ---
    async loadViewShiftClosingReport() {
        this.viewShiftClosingReportState = "loading";
        setState("ui.shiftManagement.action.viewShiftClosingReport.status", "loading");
        const options = { mode: "silent" };
        const response = await execBff("cafeFlow.shiftLifecycle.viewShiftClosingReport", {}, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.viewShiftClosingReportData = data;
            setState("ui.shiftManagement.data.viewShiftClosingReport", data);
            this.viewShiftClosingReportState = "success";
            setState("ui.shiftManagement.action.viewShiftClosingReport.status", "success");
        }
        else {
            this.viewShiftClosingReportData = null;
            setState("ui.shiftManagement.data.viewShiftClosingReport", null);
            this.viewShiftClosingReportState = "error";
            setState("ui.shiftManagement.action.viewShiftClosingReport.status", "error");
            console.error("[shiftManagement] viewShiftClosingReport error:", response.error);
        }
        this.requestUpdate();
    }
    handleViewShiftClosingReportClick() {
        this.loadViewShiftClosingReport();
    }
    // --- Command action: openShift ---
    async openShift() {
        this.openShiftState = "loading";
        setState("ui.shiftManagement.action.openShift.status", "loading");
        const params = {
            notes: this.openShiftNotes || undefined,
        };
        const response = await execBff("cafeFlow.shiftLifecycle.openShift", params, { mode: "blocking" });
        if (response.ok) {
            const data = response.data ?? null;
            this.OutputOpenShift = data;
            setState("ui.shiftManagement.output.openShift", data);
            // Refresh: viewShiftClosingReport
            try {
                await this.loadViewShiftClosingReport();
                if (this.viewShiftClosingReportState === "error") {
                    this.openShiftState = "error";
                    setState("ui.shiftManagement.action.openShift.status", "error");
                }
                else {
                    this.openShiftState = "success";
                    setState("ui.shiftManagement.action.openShift.status", "success");
                }
            }
            catch {
                this.openShiftState = "error";
                setState("ui.shiftManagement.action.openShift.status", "error");
            }
        }
        else {
            this.openShiftState = "error";
            setState("ui.shiftManagement.action.openShift.status", "error");
            console.error("[shiftManagement] openShift error:", response.error);
        }
        this.requestUpdate();
    }
    handleOpenShiftClick() {
        runBlockingUiAction(async (_signal) => {
            await this.openShift();
        }, { mode: "blocking" });
    }
    // --- Command action: closeShift ---
    async closeShift() {
        this.closeShiftState = "loading";
        setState("ui.shiftManagement.action.closeShift.status", "loading");
        const totalApuradoNum = parseFloat(this.closeShiftTotalApurado);
        const params = {
            totalApurado: isNaN(totalApuradoNum) ? 0 : totalApuradoNum,
            notes: this.closeShiftNotes || undefined,
        };
        const response = await execBff("cafeFlow.shiftLifecycle.closeShift", params, { mode: "blocking" });
        if (response.ok) {
            const data = response.data ?? null;
            this.OutputCloseShift = data;
            setState("ui.shiftManagement.output.closeShift", data);
            // Refresh: viewShiftClosingReport
            try {
                await this.loadViewShiftClosingReport();
                if (this.viewShiftClosingReportState === "error") {
                    this.closeShiftState = "error";
                    setState("ui.shiftManagement.action.closeShift.status", "error");
                }
                else {
                    this.closeShiftState = "success";
                    setState("ui.shiftManagement.action.closeShift.status", "success");
                }
            }
            catch {
                this.closeShiftState = "error";
                setState("ui.shiftManagement.action.closeShift.status", "error");
            }
        }
        else {
            this.closeShiftState = "error";
            setState("ui.shiftManagement.action.closeShift.status", "error");
            console.error("[shiftManagement] closeShift error:", response.error);
        }
        this.requestUpdate();
    }
    handleCloseShiftClick() {
        runBlockingUiAction(async (_signal) => {
            await this.closeShift();
        }, { mode: "blocking" });
    }
}
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "openShiftState", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "openShiftNotes", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "closeShiftState", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "closeShiftTotalApurado", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "closeShiftNotes", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "viewShiftClosingReportState", void 0);
__decorate([
    property({ type: Object })
], CafeFlowShiftManagementBase.prototype, "viewShiftClosingReportData", void 0);
__decorate([
    property({ type: Object })
], CafeFlowShiftManagementBase.prototype, "OutputOpenShift", void 0);
__decorate([
    property({ type: Object })
], CafeFlowShiftManagementBase.prototype, "OutputCloseShift", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "LayoutColBoardStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "LayoutColBoardOpened", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "LayoutColBoardClosed", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "LayoutColQueueStatus", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "LayoutColQueueOpened", void 0);
__decorate([
    property({ type: String })
], CafeFlowShiftManagementBase.prototype, "LayoutColQueueClosed", void 0);
