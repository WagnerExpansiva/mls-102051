/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/stockManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "stockManagement.section.workspace.title": "Gestão de estoque e alertas",
    "stockManagement.organism.stockList.title": "Itens de estoque",
    "stockManagement.intent.stockList.title": "Lista de itens e alertas",
    "stockManagement.filter.searchTerm.label": "Buscar por nome",
    "stockManagement.field.name.label": "Ingrediente",
    "stockManagement.field.unit.label": "Unidade",
    "stockManagement.field.minimumLevel.label": "Limite mínimo",
    "stockManagement.field.updatedAt.label": "Atualizado em",
    "stockManagement.action.refreshList": "Atualizar lista",
    "stockManagement.organism.stockItemEditor.title": "Editar item",
    "stockManagement.intent.stockEdit.title": "Atualizar item de estoque",
    "stockManagement.action.save": "Salvar alterações",
    "stockManagement.organism.stockSummary.title": "Resumo do item",
    "stockManagement.intent.stockSummary.title": "Resumo e alerta",
    "stockManagement.section.queue.title": "Fila de itens",
    "stockManagement.organism.stockQueue.title": "Itens com alerta",
    "stockManagement.intent.queueList.title": "Fila de estoque",
    "stockManagement.section.actionPanel.title": "Painel do item",
    "stockManagement.organism.selectedStatus.title": "Detalhes do item",
    "stockManagement.intent.queueSummary.title": "Resumo do item selecionado",
    "stockManagement.organism.stockQueueEditor.title": "Editar item selecionado",
    "stockManagement.intent.queueEdit.title": "Atualizar item",
    "stockManagement.section.visual.title": "Visão visual do estoque",
    "stockManagement.organism.visualBoard.title": "Painel visual de itens",
    "stockManagement.intent.visualBoard.title": "Mapa de alertas",
    "stockManagement.organism.fallbackList.title": "Lista de itens",
    "stockManagement.intent.fallbackList.title": "Lista acessível",
    "stockManagement.section.detailPanel.title": "Detalhes do item",
    "stockManagement.organism.visualSummary.title": "Resumo do item",
    "stockManagement.intent.visualSummary.title": "Detalhes selecionados",
    "stockManagement.organism.visualEditor.title": "Editar item",
    "stockManagement.intent.visualEdit.title": "Atualizar item selecionado"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowStockManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.browseStockItemsState = 'idle';
        this.browseStockItemsSearchTerm = '';
        this.browseStockItemsData = { items: [], total: 0 };
        this.manageStockItemState = 'idle';
        this.manageStockItemName = '';
        this.manageStockItemUnit = '';
        this.manageStockItemMinimumLevel = '';
        this.OutputManageStockItem = null;
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    /* ---- State setters ---- */
    setBrowseStockItemsSearchTerm(value) {
        this.browseStockItemsSearchTerm = value;
        setState('ui.stockManagement.input.browseStockItems.searchTerm', value);
        this.requestUpdate();
    }
    handleBrowseStockItemsSearchTermChange(e) {
        const target = e.target;
        this.setBrowseStockItemsSearchTerm(target.value);
    }
    setManageStockItemName(value) {
        this.manageStockItemName = value;
        setState('ui.stockManagement.input.manageStockItem.name', value);
        this.requestUpdate();
    }
    handleManageStockItemNameChange(e) {
        const target = e.target;
        this.setManageStockItemName(target.value);
    }
    setManageStockItemUnit(value) {
        this.manageStockItemUnit = value;
        setState('ui.stockManagement.input.manageStockItem.unit', value);
        this.requestUpdate();
    }
    handleManageStockItemUnitChange(e) {
        const target = e.target;
        this.setManageStockItemUnit(target.value);
    }
    setManageStockItemMinimumLevel(value) {
        this.manageStockItemMinimumLevel = value;
        setState('ui.stockManagement.input.manageStockItem.minimumLevel', value);
        this.requestUpdate();
    }
    handleManageStockItemMinimumLevelChange(e) {
        const target = e.target;
        this.setManageStockItemMinimumLevel(target.value);
    }
    /* ---- Query actions ---- */
    async loadBrowseStockItems() {
        this.browseStockItemsState = 'loading';
        setState('ui.stockManagement.action.browseStockItems.status', 'loading');
        const params = {
            searchTerm: this.browseStockItemsSearchTerm || undefined,
        };
        const options = { mode: 'silent' };
        const response = await execBff('cafeFlow.browseStockItems.browseStockItems', params, options);
        if (response.ok) {
            const data = response.data ?? { items: [], total: 0 };
            this.browseStockItemsData = data;
            setState('ui.stockManagement.data.browseStockItems', data);
            this.browseStockItemsState = 'success';
            setState('ui.stockManagement.action.browseStockItems.status', 'success');
        }
        else {
            this.browseStockItemsState = 'error';
            setState('ui.stockManagement.action.browseStockItems.status', 'error');
            if (response.error) {
                console.error('[stockManagement] loadBrowseStockItems error:', response.error.message);
            }
        }
    }
    handleBrowseStockItemsClick() {
        void this.loadBrowseStockItems();
    }
    /* ---- Command actions ---- */
    async manageStockItem() {
        this.manageStockItemState = 'loading';
        setState('ui.stockManagement.action.manageStockItem.status', 'loading');
        const parsedMinimumLevel = Number(this.manageStockItemMinimumLevel);
        const params = {
            name: this.manageStockItemName,
            unit: this.manageStockItemUnit,
            minimumLevel: isNaN(parsedMinimumLevel) ? 0 : parsedMinimumLevel,
        };
        const options = { mode: 'blocking' };
        const response = await execBff('cafeFlow.manageStockItem.manageStockItem', params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.OutputManageStockItem = data;
            setState('ui.stockManagement.output.manageStockItem', data);
            // Refresh browseStockItems after successful command
            try {
                await this.loadBrowseStockItems();
                if (this.browseStockItemsState === 'error') {
                    this.manageStockItemState = 'error';
                    setState('ui.stockManagement.action.manageStockItem.status', 'error');
                    return;
                }
            }
            catch {
                this.manageStockItemState = 'error';
                setState('ui.stockManagement.action.manageStockItem.status', 'error');
                return;
            }
            this.manageStockItemState = 'success';
            setState('ui.stockManagement.action.manageStockItem.status', 'success');
        }
        else {
            this.manageStockItemState = 'error';
            setState('ui.stockManagement.action.manageStockItem.status', 'error');
            if (response.error) {
                console.error('[stockManagement] manageStockItem error:', response.error.message);
            }
        }
    }
    handleManageStockItemClick() {
        void runBlockingUiAction(async (_signal) => {
            await this.manageStockItem();
        }, { mode: 'blocking' });
    }
    /* ---- Lifecycle ---- */
    connectedCallback() {
        super.connectedCallback();
        // Initialize from shared state where useful
        const sharedSearchTerm = getState('ui.stockManagement.input.browseStockItems.searchTerm');
        if (sharedSearchTerm !== undefined) {
            this.browseStockItemsSearchTerm = sharedSearchTerm;
        }
        const sharedName = getState('ui.stockManagement.input.manageStockItem.name');
        if (sharedName !== undefined) {
            this.manageStockItemName = sharedName;
        }
        const sharedUnit = getState('ui.stockManagement.input.manageStockItem.unit');
        if (sharedUnit !== undefined) {
            this.manageStockItemUnit = sharedUnit;
        }
        const sharedMinLevel = getState('ui.stockManagement.input.manageStockItem.minimumLevel');
        if (sharedMinLevel !== undefined) {
            this.manageStockItemMinimumLevel = sharedMinLevel;
        }
        // Subscribe to shared states
        subscribe([
            'ui.stockManagement.input.browseStockItems.searchTerm',
            'ui.stockManagement.input.manageStockItem.name',
            'ui.stockManagement.input.manageStockItem.unit',
            'ui.stockManagement.input.manageStockItem.minimumLevel',
        ], this);
        // Run initial loads
        void this.loadBrowseStockItems();
    }
    disconnectedCallback() {
        unsubscribe([
            'ui.stockManagement.input.browseStockItems.searchTerm',
            'ui.stockManagement.input.manageStockItem.name',
            'ui.stockManagement.input.manageStockItem.unit',
            'ui.stockManagement.input.manageStockItem.minimumLevel',
        ], this);
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "browseStockItemsState", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "browseStockItemsSearchTerm", void 0);
__decorate([
    property({ type: Object })
], CafeFlowStockManagementBase.prototype, "browseStockItemsData", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "manageStockItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "manageStockItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "manageStockItemUnit", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "manageStockItemMinimumLevel", void 0);
__decorate([
    property({ type: Object })
], CafeFlowStockManagementBase.prototype, "OutputManageStockItem", void 0);
