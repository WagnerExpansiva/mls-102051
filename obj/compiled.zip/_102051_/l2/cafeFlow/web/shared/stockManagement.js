/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/stockManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_pt = {
    "stockManagement.section.main.title": "Gestão de estoque e alertas",
    "stockManagement.organism.browseStockItems.title": "Consultar itens de estoque e alertas",
    "stockManagement.intentions.browseStockItems.queryList.title": "Itens de estoque",
    "stockManagement.intentions.browseStockItems.queryList.empty": "Nenhum item de estoque encontrado",
    "stockManagement.filters.searchTerm": "Buscar por nome",
    "stockManagement.fields.name": "Nome",
    "stockManagement.fields.unit": "Unidade",
    "stockManagement.fields.minimumLevel": "Limite mínimo",
    "stockManagement.fields.updatedAt": "Atualizado em",
    "stockManagement.fields.createdAt": "Criado em",
    "stockManagement.actions.browseStockItems": "Buscar",
    "stockManagement.organism.manageStockItem.title": "Gerenciar item de estoque",
    "stockManagement.intentions.manageStockItem.form.title": "Editar item de estoque",
    "stockManagement.actions.manageStockItem": "Salvar alterações",
    "stockManagement.intentions.manageStockItem.summary.title": "Resumo da atualização"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowStockManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.browseStockItemsState = 'idle';
        this.browseStockItemsSearchTerm = '';
        this.browseStockItemsData = { items: [], total: 0 };
        this.manageStockItemState = 'idle';
        this.manageStockItemName = '';
        this.manageStockItemUnit = '';
        this.manageStockItemMinimumLevel = '';
        this.LayoutSummaryManageStockItemUpdatedAt = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    // ── Query: browseStockItems ──
    async loadBrowseStockItems() {
        this.browseStockItemsState = 'loading';
        setState('ui.stockManagement.action.browseStockItems.status', 'loading');
        const params = {
            searchTerm: this.browseStockItemsSearchTerm || undefined,
        };
        const response = await execBff('cafeFlow.browseStockItems.browseStockItems', params, { mode: 'silent' });
        if (!response.ok) {
            this.browseStockItemsState = 'error';
            setState('ui.stockManagement.action.browseStockItems.status', 'error');
            return false;
        }
        const data = response.data ?? { items: [], total: 0 };
        this.browseStockItemsData = data;
        setState('ui.stockManagement.data.browseStockItems', data);
        this.browseStockItemsState = 'success';
        setState('ui.stockManagement.action.browseStockItems.status', 'success');
        return true;
    }
    async handleBrowseStockItemsClick() {
        await this.loadBrowseStockItems();
    }
    // ── Command: manageStockItem ──
    async manageStockItem(signal) {
        this.manageStockItemState = 'loading';
        setState('ui.stockManagement.action.manageStockItem.status', 'loading');
        const params = {
            name: this.manageStockItemName,
            unit: this.manageStockItemUnit,
            minimumLevel: Number(this.manageStockItemMinimumLevel),
        };
        const options = { mode: 'blocking' };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff('cafeFlow.manageStockItem.manageStockItem', params, options);
        if (!response.ok) {
            this.manageStockItemState = 'error';
            setState('ui.stockManagement.action.manageStockItem.status', 'error');
            return;
        }
        // Refresh browseStockItems after successful command
        const refreshOk = await this.loadBrowseStockItems();
        if (!refreshOk) {
            this.manageStockItemState = 'error';
            setState('ui.stockManagement.action.manageStockItem.status', 'error');
        }
        else {
            this.manageStockItemState = 'success';
            setState('ui.stockManagement.action.manageStockItem.status', 'success');
        }
    }
    async handleManageStockItemClick() {
        await runBlockingUiAction(async (signal) => {
            await this.manageStockItem(signal);
        }, { mode: 'blocking' });
    }
    // ── State setters ──
    setBrowseStockItemsSearchTerm(value) {
        this.browseStockItemsSearchTerm = value;
        setState('ui.stockManagement.input.browseStockItems.searchTerm', value);
        this.requestUpdate();
    }
    handleBrowseStockItemsSearchTermChange(e) {
        const target = e.target;
        this.setBrowseStockItemsSearchTerm(target.value);
    }
    setManageStockItemName(value) {
        this.manageStockItemName = value;
        setState('ui.stockManagement.input.manageStockItem.name', value);
        this.requestUpdate();
    }
    handleManageStockItemNameChange(e) {
        const target = e.target;
        this.setManageStockItemName(target.value);
    }
    setManageStockItemUnit(value) {
        this.manageStockItemUnit = value;
        setState('ui.stockManagement.input.manageStockItem.unit', value);
        this.requestUpdate();
    }
    handleManageStockItemUnitChange(e) {
        const target = e.target;
        this.setManageStockItemUnit(target.value);
    }
    setManageStockItemMinimumLevel(value) {
        this.manageStockItemMinimumLevel = value;
        setState('ui.stockManagement.input.manageStockItem.minimumLevel', value);
        this.requestUpdate();
    }
    handleManageStockItemMinimumLevelChange(e) {
        const target = e.target;
        this.setManageStockItemMinimumLevel(target.value);
    }
    // ── Lifecycle ──
    connectedCallback() {
        super.connectedCallback();
        // Initialize from shared state where useful
        const sharedSearchTerm = getState('ui.stockManagement.input.browseStockItems.searchTerm');
        if (sharedSearchTerm !== undefined) {
            this.browseStockItemsSearchTerm = sharedSearchTerm;
        }
        const sharedName = getState('ui.stockManagement.input.manageStockItem.name');
        if (sharedName !== undefined) {
            this.manageStockItemName = sharedName;
        }
        const sharedUnit = getState('ui.stockManagement.input.manageStockItem.unit');
        if (sharedUnit !== undefined) {
            this.manageStockItemUnit = sharedUnit;
        }
        const sharedMinimumLevel = getState('ui.stockManagement.input.manageStockItem.minimumLevel');
        if (sharedMinimumLevel !== undefined) {
            this.manageStockItemMinimumLevel = sharedMinimumLevel;
        }
        // Run initial loads
        this.loadBrowseStockItems();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
}
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "browseStockItemsState", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "browseStockItemsSearchTerm", void 0);
__decorate([
    property({ type: Object })
], CafeFlowStockManagementBase.prototype, "browseStockItemsData", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "manageStockItemState", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "manageStockItemName", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "manageStockItemUnit", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "manageStockItemMinimumLevel", void 0);
__decorate([
    property({ type: String })
], CafeFlowStockManagementBase.prototype, "LayoutSummaryManageStockItemUpdatedAt", void 0);
