declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102051_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    /**
     * Design system do projeto — vocabulário de tokens POR PAPEL (role-based).
     * Este vocabulário é o padrão para novos projetos; só os VALORES mudam por marca.
     *
     * Regras de nomenclatura (color):
     *  - O nome diz onde o token é usado; nunca deduza pelo valor.
     *  - Pares bg/text andam juntos: quem usa button-primary-bg escreve o rótulo
     *    com button-primary-text; quem usa status-error-bg usa status-error-text;
     *    nav-bg com nav-text; tooltip-bg com tooltip-text. Vale para todo par
     *    <papel>-bg / <papel>-text.
     *  - Superfícies: page-bg (fundo da página) > surface-bg (cards, painéis,
     *    modais) > surface-alt-bg (linhas zebradas, hover de linha, skeleton,
     *    cabeçalhos de seção). Texto sobre superfícies: text-strong (títulos),
     *    text-default (corpo), text-muted (secundário/placeholder).
     *  - Navegação (sidebar/topbar): nav-bg + nav-text; item ativo usa
     *    nav-active-bg + nav-active-text.
     *  - Overlay de modal: overlay-backdrop-bg atrás, surface-bg no modal.
     *  - Gráficos: séries usam chart-series-1..6 SEMPRE nesta ordem fixa (a ordem
     *    é o mecanismo de segurança para daltonismo — nunca embaralhar nem gerar
     *    cores novas); textos e eixos usam os tokens text-*, nunca a cor da série;
     *    status-* são reservados a estado e nunca viram série de gráfico.
     *  - Todo token base de cor tem as variantes -hover, -focus e -disabled
     *    (em chart-series, -disabled é a série apagada pela legenda).
     *  - Modo noite: cada chave tem par com prefixo _dark- (mesmo nome). O
     *    compilador gera o bloco dark automaticamente; paginas usam so o nome base.
     */
    export const tokens: IDesignSystemTokens[];
}
declare module "_102051_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        publication?: PublicationConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102051_/l5/runtimeConfig" {
    import type { ProjectsConfig } from "_102029_/l2/runtimeConfigTypes";
    export const runtimeConfig: ProjectsConfig;
}
