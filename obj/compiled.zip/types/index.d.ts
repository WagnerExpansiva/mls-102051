declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems.defs" {
    export const browseMenuItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "menuItemLifecycle";
            readonly controllerName: "BrowseMenuItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowBrowseMenuItemsHandler";
                readonly command: "browseMenuItems";
                readonly usecaseRef: "browseMenuItems";
                readonly inputTypeName: "BrowseMenuItemsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "MenuItem.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por status do item (draft, active, inactive) informado pelo gerente";
                }, {
                    readonly inputId: "menuCategoryIdFilter";
                    readonly fieldRef: "MenuItem.menuCategoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por categoria do item informado pelo gerente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "MenuItem.menuCategoryId";
                    readonly source: "businessContext";
                    readonly originRef: "businessContext.activeCompanyId";
                    readonly description: "O backend resolve o escopo da consulta limitando os itens do cardápio à empresa ativa da sessão do gerente";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "MenuItem";
                    readonly keyField: "MenuItem.menuItemId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.description", "MenuItem.menuCategoryId", "MenuItem.price", "MenuItem.itemType", "MenuItem.status", "MenuItem.activatedAt", "MenuItem.createdAt", "MenuItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.menuItemLifecycle.browseMenuItems";
                readonly handlerName: "cafeFlowBrowseMenuItemsHandler";
            }];
        };
    };
    export default browseMenuItemsController;
    export const pipeline: readonly [{
        readonly id: "browseMenuItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseMenuItemsInput {
        statusFilter?: string;
        menuCategoryIdFilter?: string;
    }
    export interface BrowseMenuItemsOutputItem {
        menuItemId: string;
        name: string;
        description?: string;
        menuCategoryId: string;
        price: number;
        itemType: string;
        status: string;
        activatedAt?: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseMenuItemsOutput {
        items: BrowseMenuItemsOutputItem[];
    }
    /**
     * BrowseMenuItems — lists simple menu items scoped to the active company.
     *
     * Menu items and menu categories are MDM master-data records (no local table).
     * The usecase reads them through the MDM facade, filters by company relationship,
     * applies the `simpleItemsOnly` rule, optional status/category filters, and
     * projects each item to the output shape.
     */
    export function browseMenuItems(ctx: RequestContext, input: BrowseMenuItemsInput): Promise<BrowseMenuItemsOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowBrowseMenuItemsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems.defs" {
    export const browseStockItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseStockItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseStockItems";
            readonly controllerName: "BrowseStockItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowBrowseStockItemsHandler";
                readonly command: "browseStockItems";
                readonly usecaseRef: "browseStockItems";
                readonly inputTypeName: "BrowseStockItemsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "searchTerm";
                    readonly fieldRef: "StockItem.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de busca opcional para filtrar itens de estoque pelo nome.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "StockItem.stockItemId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que está consultando o estoque.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "StockItem.stockItemId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend extrai o actorId da sessão autenticada do gerente para autorizar o acesso à lista de itens de estoque.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "StockItem";
                    readonly keyField: "StockItem.stockItemId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["StockItem.stockItemId", "StockItem.name", "StockItem.unit", "StockItem.minimumLevel", "StockItem.createdAt", "StockItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.browseStockItems.browseStockItems";
                readonly handlerName: "cafeFlowBrowseStockItemsHandler";
            }];
        };
    };
    export default browseStockItemsController;
    export const pipeline: readonly [{
        readonly id: "browseStockItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel" {
    export type StockLevelUnit = 'kg' | 'liter' | 'portion' | 'unit';
    export interface StockLevel {
        stockLevelId: string;
        stockItemId: string;
        currentQuantity: number;
        minimumLevel: number;
        unit: StockLevelUnit;
        lastDecrementAt: string | null;
        lastAdjustmentAt: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export function isCurrentQuantityValid(quantity: number): boolean;
    export function isMinimumLevelValid(level: number): boolean;
    export function isLowStockAlert(stockLevel: Pick<StockLevel, 'currentQuantity' | 'minimumLevel'>): boolean;
    export function validateStockLevelInvariants(stockLevel: Pick<StockLevel, 'currentQuantity' | 'minimumLevel'>): boolean;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository" {
    import type { StockLevel, StockLevelUnit } from "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    export type StockLevelId = string;
    export type ProductId = string;
    export interface StockLevelListFilter {
        stockItemId?: string;
        unit?: StockLevelUnit;
    }
    export interface IStockLevelRepository {
        getById(id: StockLevelId): Promise<StockLevel>;
        list(filter?: StockLevelListFilter): Promise<StockLevel[]>;
        save(stockLevel: StockLevel): Promise<void>;
        listLowStock(): Promise<StockLevel[]>;
        listByProductId(productId: ProductId): Promise<StockLevel[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/browseStockItems" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { StockLevelUnit } from "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    export interface BrowseStockItemsInput {
        searchTerm?: string;
        page?: number;
        pageSize?: number;
    }
    export interface StockItemBrowseResult {
        stockItemId: string;
        name: string;
        unit: StockLevelUnit;
        minimumLevel: number;
        currentQuantity: number;
        lowStockAlert: boolean;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseStockItemsOutput {
        items: StockItemBrowseResult[];
        totalCount: number;
        page: number;
        pageSize: number;
    }
    export function browseStockItems(ctx: RequestContext, input: BrowseStockItemsInput): Promise<BrowseStockItemsOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowBrowseStockItemsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.defs" {
    export const closeShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "closeShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "CloseShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCloseShiftHandler";
                readonly command: "closeShift";
                readonly usecaseRef: "closeShift";
                readonly inputTypeName: "CloseShiftInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "totalApurado";
                    readonly fieldRef: "Shift.totalApurado";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Valor total apurado no fechamento do turno, informado pelo gerente para conferência.";
                }, {
                    readonly inputId: "notes";
                    readonly fieldRef: "Shift.notes";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Observações gerais sobre o turno, opcionais.";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Identificador do turno atualmente aberto que será fechado.";
                }, {
                    readonly inputId: "closedBy";
                    readonly fieldRef: "Shift.closedBy";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente que está fechando o turno.";
                }, {
                    readonly inputId: "closedAt";
                    readonly fieldRef: "Shift.closedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora do fechamento do turno, definida automaticamente pelo sistema.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Shift.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend localiza o único Shift com status 'open' (turno ativo) e utiliza seu shiftId como alvo do fechamento.";
                }, {
                    readonly targetRef: "Shift.closedBy";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend obtém o identificador do gerente autenticado a partir da sessão ativa.";
                }, {
                    readonly targetRef: "Shift.closedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define a data e hora de fechamento como o timestamp atual no momento da confirmação.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Shift.status", "Shift.closedAt", "Shift.closedBy", "Shift.totalApurado", "Shift.notes"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.closeShift";
                readonly handlerName: "cafeFlowCloseShiftHandler";
            }];
        };
    };
    export default closeShiftController;
    export const pipeline: readonly [{
        readonly id: "closeShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/closeShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/shift" {
    export type ShiftStatus = 'open' | 'closed';
    export interface Shift {
        shiftId: string;
        status: ShiftStatus;
        openedAt: string;
        closedAt: string | null;
        openedBy: string;
        closedBy: string | null;
        totalApurado: number | null;
        notes: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const SHIFT_STATUS_TRANSITIONS: Record<ShiftStatus, ShiftStatus[]>;
    export function canTransitionShift(from: ShiftStatus, to: ShiftStatus): boolean;
    export function shiftRequiresCloseFields(shift: Pick<Shift, 'status' | 'closedAt' | 'closedBy' | 'totalApurado'>): boolean;
    export function shiftClosedAtAfterOpenedAt(shift: Pick<Shift, 'openedAt' | 'closedAt'>): boolean;
    export function hasOpenShift(shifts: Pick<Shift, 'status'>[]): boolean;
    export function canReopenShift(from: ShiftStatus): boolean;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository" {
    import type { Shift, ShiftStatus } from "_102051_/l1/cafeFlow/layer_3_domain/entities/shift";
    export type ShiftId = string;
    export interface ShiftListFilter {
        status?: ShiftStatus;
        openedBy?: string;
    }
    export interface IShiftRepository {
        getById(id: ShiftId): Promise<Shift>;
        list(filter?: ShiftListFilter): Promise<Shift[]>;
        save(shift: Shift): Promise<void>;
        listOpenShifts(): Promise<Shift[]>;
        listByPeriod(start: Date, end: Date): Promise<Shift[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/order" {
    export type OrderStatus = 'registered' | 'received' | 'inPreparation' | 'ready' | 'delivered';
    export type OrderType = 'table' | 'takeout';
    export interface OrderItem {
        orderItemId: string;
        orderId: string;
        menuItemId: string;
        quantity: number;
        unitPrice: number;
        createdAt: string;
        updatedAt: string;
    }
    export interface Order {
        orderId: string;
        shiftId: string;
        status: OrderStatus;
        orderType: OrderType;
        tableNumber: string | null;
        priority: boolean | null;
        priorityReason: string | null;
        receivedAt: string | null;
        inPreparationAt: string | null;
        readyAt: string | null;
        deliveredAt: string | null;
        createdAt: string;
        updatedAt: string;
        items: OrderItem[];
    }
    export const ORDER_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]>;
    export function canTransitionOrder(from: OrderStatus, to: OrderStatus): boolean;
    export function validateTableNumber(order: Pick<Order, 'orderType' | 'tableNumber'>): boolean;
    export function validatePriorityReason(order: Pick<Order, 'priority' | 'priorityReason'>): boolean;
    export function validateStatusTimestamps(order: Pick<Order, 'status' | 'receivedAt' | 'inPreparationAt' | 'readyAt' | 'deliveredAt'>): boolean;
    export function orderRequiresItem(order: Pick<Order, 'items'>): boolean;
    export function validateOrderItems(items: OrderItem[]): boolean;
    export function validateOrderInvariants(order: Order): string[];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository" {
    import type { Order, OrderStatus } from "_102051_/l1/cafeFlow/layer_3_domain/entities/order";
    export interface OrderListFilter {
        shiftId?: string;
        status?: OrderStatus;
        orderType?: 'table' | 'takeout';
        tableNumber?: string | null;
    }
    export interface IOrderRepository {
        getById(id: string): Promise<Order>;
        list(filter?: OrderListFilter): Promise<Order[]>;
        save(order: Order): Promise<void>;
        listByStatus(status: OrderStatus): Promise<Order[]>;
        listByPeriod(start: Date, end: Date): Promise<Order[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport" {
    export interface ShiftClosingReport {
        shiftClosingReportId: string;
        shiftId: string;
        totalApurado: number;
        paidOrderCount: number;
        createdAt: string;
        updatedAt: string;
    }
    export function shiftClosingReportRequiresNonNegativeTotal(report: Pick<ShiftClosingReport, 'totalApurado'>): boolean;
    export function shiftClosingReportRequiresNonNegativePaidOrderCount(report: Pick<ShiftClosingReport, 'paidOrderCount'>): boolean;
    export function isUniqueShiftClosingReportPerShift(reports: ShiftClosingReport[], shiftId: string): boolean;
    export function validateShiftClosingReport(report: Pick<ShiftClosingReport, 'totalApurado' | 'paidOrderCount'>): string[];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository" {
    import type { ShiftClosingReport } from "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport";
    export type ShiftClosingReportId = string;
    export type ShiftId = string;
    export interface ShiftClosingReportListFilter {
        shiftClosingReportId?: ShiftClosingReportId;
        shiftId?: ShiftId;
        fromCreatedAt?: string;
        toCreatedAt?: string;
    }
    export interface IShiftClosingReportRepository {
        getById(id: ShiftClosingReportId): Promise<ShiftClosingReport>;
        list(filter?: ShiftClosingReportListFilter): Promise<ShiftClosingReport[]>;
        save(report: ShiftClosingReport): Promise<void>;
        listByShiftId(shiftId: ShiftId): Promise<ShiftClosingReport[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/closeShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CloseShiftInput {
        totalApurado: number;
        notes?: string;
        shiftId?: string;
        closedBy?: string;
        closedAt?: string;
    }
    export interface CloseShiftOutput {
        shiftId: string;
        status: string;
        closedAt: string;
        closedBy: string;
        totalApurado: number;
        notes?: string;
        shiftClosingReportId: string;
        paidOrderCount: number;
    }
    export function closeShift(ctx: RequestContext, input: CloseShiftInput): Promise<CloseShiftOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCloseShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs" {
    export const createOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "CreateOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateOrderHandler";
                readonly command: "createOrder";
                readonly usecaseRef: "createOrder";
                readonly inputTypeName: "CreateOrderInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "orderType";
                    readonly fieldRef: "Order.orderType";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Tipo do pedido selecionado pelo atendente: 'table' (consumo na mesa) ou 'takeout' (para viagem)";
                }, {
                    readonly inputId: "tableNumber";
                    readonly fieldRef: "Order.tableNumber";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Número da mesa informado pelo atendente, obrigatório quando orderType = 'table'";
                }, {
                    readonly inputId: "orderItems";
                    readonly fieldRef: "OrderItem.menuItemId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Lista de itens do cardápio selecionados pelo cliente, cada um com menuItemId e quantidade";
                }, {
                    readonly inputId: "priority";
                    readonly fieldRef: "Order.priority";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Indica se o atendente marcou o pedido como prioritário no preparo";
                }, {
                    readonly inputId: "priorityReason";
                    readonly fieldRef: "Order.priorityReason";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Justificativa da priorização, obrigatória quando priority = true";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno aberto no momento do lançamento do pedido";
                }, {
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.orderId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único gerado para o novo pedido";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Order.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento de criação do registro do pedido";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Order.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento da última atualização do registro do pedido";
                }];
                readonly contextResolution: readonly [{
                    readonly inputId: "shiftId";
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolves the single Shift with status open — the active shift at the moment of order creation";
                }, {
                    readonly inputId: "orderId";
                    readonly targetRef: "Order.orderId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "Generates a new UUID to identify the order being created";
                }, {
                    readonly inputId: "createdAt";
                    readonly targetRef: "Order.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Sets the creation timestamp to the current server time at the moment of order launch";
                }, {
                    readonly inputId: "updatedAt";
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Sets the last-update timestamp to the current server time at the moment of order launch";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.createOrder";
                readonly handlerName: "cafeFlowCreateOrderHandler";
            }];
        };
    };
    export default createOrderController;
    export const pipeline: readonly [{
        readonly id: "createOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/createOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption" {
    export type StockConsumptionStatus = 'posted' | 'voided';
    export interface StockConsumption {
        stockConsumptionId: string;
        stockItemId: string;
        orderId: string;
        quantity: number;
        status: StockConsumptionStatus;
        createdAt: string;
        voidedAt: string | null;
        voidReason: string | null;
    }
    export const STOCK_CONSUMPTION_STATUS_TRANSITIONS: Record<StockConsumptionStatus, StockConsumptionStatus[]>;
    export function canTransitionStockConsumption(from: StockConsumptionStatus, to: StockConsumptionStatus): boolean;
    export function isStockConsumptionVoided(consumption: Pick<StockConsumption, 'status'>): boolean;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository" {
    import type { StockConsumption, StockConsumptionStatus } from "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption";
    export interface StockConsumptionListFilter {
        stockItemId?: string;
        orderId?: string;
        status?: StockConsumptionStatus;
    }
    export interface IStockConsumptionRepository {
        append(record: StockConsumption): Promise<void>;
        list(filter: StockConsumptionListFilter): Promise<StockConsumption[]>;
        listByOwnerId(orderId: string): Promise<StockConsumption[]>;
        listByPeriod(start: Date, end: Date): Promise<StockConsumption[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/createOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateOrderItemInput {
        menuItemId: string;
        quantity: number;
    }
    export interface CreateOrderInput {
        orderType: string;
        tableNumber?: string;
        orderItems: CreateOrderItemInput[];
        priority?: boolean;
        priorityReason?: string;
    }
    export interface CreateOrderOutput {
        orderId: string;
        status: string;
        orderType: string;
        tableNumber?: string;
        createdAt: string;
    }
    export function createOrder(ctx: RequestContext, input: CreateOrderInput): Promise<CreateOrderOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder.defs" {
    export const deliverOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "deliverOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "DeliverOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDeliverOrderHandler";
                readonly command: "deliverOrder";
                readonly usecaseRef: "deliverOrder";
                readonly inputTypeName: "DeliverOrderInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.orderId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Pedido selecionado pelo atendente no painel para entrega";
                }, {
                    readonly inputId: "deliveredAt";
                    readonly fieldRef: "Order.deliveredAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento em que o pedido foi entregue ao cliente, gerado automaticamente";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Order.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento da última atualização do registro do pedido, gerado automaticamente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.orderId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Order.orderId";
                    readonly description: "O backend resolve o orderId a partir do pedido atualmente selecionado pelo atendente no painel de pedidos.";
                }, {
                    readonly targetRef: "Order.deliveredAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define deliveredAt com o timestamp atual no momento da confirmação da entrega.";
                }, {
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define updatedAt com o timestamp atual no momento da atualização do registro.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.deliveredAt", "Order.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.deliverOrder";
                readonly handlerName: "cafeFlowDeliverOrderHandler";
            }];
        };
    };
    export default deliverOrderController;
    export const pipeline: readonly [{
        readonly id: "deliverOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/deliverOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface DeliverOrderInput {
        orderId: string;
    }
    export interface DeliverOrderOutput {
        orderId: string;
        status: string;
        deliveredAt: string;
        updatedAt: string;
    }
    export function deliverOrder(ctx: RequestContext, input: DeliverOrderInput): Promise<DeliverOrderOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDeliverOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem.defs" {
    export const manageMenuItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "menuItemLifecycle";
            readonly controllerName: "ManageMenuItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageMenuItemHandler";
                readonly command: "manageMenuItem";
                readonly usecaseRef: "updateMenuItem";
                readonly inputTypeName: "UpdateMenuItemInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "menuItemId";
                    readonly fieldRef: "MenuItem.menuItemId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do item do cardápio selecionado para edição";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "MenuItem.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do item do cardápio exibido no POS";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "MenuItem.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada do item do cardápio";
                }, {
                    readonly inputId: "menuCategoryId";
                    readonly fieldRef: "MenuItem.menuCategoryId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Categoria de classificação à qual o item pertence";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "MenuItem.price";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Preço de venda do item do cardápio";
                }, {
                    readonly inputId: "itemType";
                    readonly fieldRef: "MenuItem.itemType";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Tipo do item: deve ser 'simple' nesta fase";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "MenuItem.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Status do item: rascunho, ativo ou inativo";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "MenuItem.menuItemId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que realiza a alteração";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "MenuItem.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "MenuItem.menuItemId";
                    readonly source: "selectedEntity";
                    readonly originRef: "MenuItem.menuItemId";
                    readonly description: "O backend resolve o menuItemId a partir do item atualmente selecionado na tela de gestão de cardápio";
                }, {
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend obtém o identificador do gerente a partir da sessão autenticada do usuário";
                }, {
                    readonly targetRef: "MenuItem.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend atribui o timestamp atual do sistema ao campo updatedAt no momento da persistência";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "MenuItem";
                    readonly keyField: "MenuItem.menuItemId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.description", "MenuItem.menuCategoryId", "MenuItem.price", "MenuItem.itemType", "MenuItem.status", "MenuItem.activatedAt", "MenuItem.inactivatedAt", "MenuItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.menuItemLifecycle.manageMenuItem";
                readonly handlerName: "cafeFlowManageMenuItemHandler";
            }];
        };
    };
    export default manageMenuItemController;
    export const pipeline: readonly [{
        readonly id: "manageMenuItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateMenuItemInput {
        menuItemId: string;
        name: string;
        description?: string;
        menuCategoryId: string;
        price: number;
        itemType: string;
        status: string;
    }
    export interface UpdateMenuItemOutput {
        menuItemId: string;
        name: string;
        description?: string;
        menuCategoryId: string;
        price: number;
        itemType: string;
        status: string;
        activatedAt?: string;
        inactivatedAt?: string;
        updatedAt: string;
    }
    export function updateMenuItem(ctx: RequestContext, input: UpdateMenuItemInput): Promise<UpdateMenuItemOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowManageMenuItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem.defs" {
    export const manageStockItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageStockItem";
            readonly controllerName: "ManageStockItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageStockItemHandler";
                readonly command: "manageStockItem";
                readonly usecaseRef: "manageStockItem";
                readonly inputTypeName: "ManageStockItemInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "stockItemId";
                    readonly fieldRef: "StockItem.stockItemId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do item de estoque a ser atualizado, obtido da rota de edição.";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "StockItem.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do ingrediente editado pelo gerente.";
                }, {
                    readonly inputId: "unit";
                    readonly fieldRef: "StockItem.unit";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Unidade de medida do ingrediente (kg, liter, portion ou unit).";
                }, {
                    readonly inputId: "minimumLevel";
                    readonly fieldRef: "StockItem.minimumLevel";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "StockItem.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do item de estoque.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "StockItem.stockItemId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.stockItemId";
                    readonly description: "O backend extrai o identificador do item de estoque do parâmetro de rota da tela de edição.";
                }, {
                    readonly targetRef: "StockItem.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend atribui automaticamente o timestamp atual no momento da persistência da atualização.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "StockItem";
                    readonly keyField: "StockItem.stockItemId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["StockItem.stockItemId", "StockItem.name", "StockItem.unit", "StockItem.minimumLevel", "StockItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageStockItem.manageStockItem";
                readonly handlerName: "cafeFlowManageStockItemHandler";
            }];
        };
    };
    export default manageStockItemController;
    export const pipeline: readonly [{
        readonly id: "manageStockItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/manageStockItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ManageStockItemInput {
        stockItemId: string;
        name: string;
        unit: string;
        minimumLevel: number;
    }
    export interface ManageStockItemOutput {
        stockItemId: string;
        name: string;
        unit: string;
        minimumLevel: number;
        updatedAt: string;
    }
    export function manageStockItem(ctx: RequestContext, input: ManageStockItemInput): Promise<ManageStockItemOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowManageStockItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.defs" {
    export const openShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "openShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "OpenShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowOpenShiftHandler";
                readonly command: "openShift";
                readonly usecaseRef: "openShift";
                readonly inputTypeName: "OpenShiftInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "notes";
                    readonly fieldRef: "Shift.notes";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Observações gerais opcionais sobre o turno, informadas pelo gerente ao abrir.";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único do turno, gerado automaticamente pelo sistema.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Shift.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Situação inicial do turno, definida como 'open' no momento da criação.";
                }, {
                    readonly inputId: "openedAt";
                    readonly fieldRef: "Shift.openedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de abertura do turno, definida automaticamente como o momento atual.";
                }, {
                    readonly inputId: "openedBy";
                    readonly fieldRef: "Shift.openedBy";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente que abriu o turno, obtido da sessão ativa.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Shift.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de criação do registro, definida automaticamente como o momento atual.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Shift.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do registro, definida automaticamente como o momento atual.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Shift.shiftId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID para o novo turno no momento da criação.";
                }, {
                    readonly targetRef: "Shift.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define o status como 'open' fixamente na criação do turno.";
                }, {
                    readonly targetRef: "Shift.openedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data e hora de abertura do turno.";
                }, {
                    readonly targetRef: "Shift.openedBy";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend obtém o identificador do gerente autenticado a partir da sessão ativa.";
                }, {
                    readonly targetRef: "Shift.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data de criação do registro.";
                }, {
                    readonly targetRef: "Shift.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data da última atualização do registro.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Shift.shiftId", "Shift.status", "Shift.openedAt", "Shift.openedBy"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.openShift";
                readonly handlerName: "cafeFlowOpenShiftHandler";
            }];
        };
    };
    export default openShiftController;
    export const pipeline: readonly [{
        readonly id: "openShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/openShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/openShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface OpenShiftInput {
        notes?: string;
    }
    export interface OpenShiftOutput {
        shiftId: string;
        status: string;
        openedAt: string;
        openedBy: string;
    }
    export function openShift(ctx: RequestContext, input: OpenShiftInput): Promise<OpenShiftOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowOpenShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions.defs" {
    export const requestAiPromoSuggestionsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "requestAiPromoSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "requestAiPromoSuggestions";
            readonly controllerName: "RequestAiPromoSuggestionsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRequestAiPromoSuggestionsHandler";
                readonly command: "requestAiPromoSuggestions";
                readonly usecaseRef: "requestAiPromoSuggestions";
                readonly inputTypeName: "RequestAiPromoSuggestionsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "actorId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identidade do gerente que solicita as sugestões, para auditoria e contexto de permissão";
                }, {
                    readonly inputId: "windowStart";
                    readonly fieldRef: "Order.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data de início da janela de análise (7 dias antes do momento atual)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend resolve o identificador do gerente a partir da sessão ativa para validar permissão e registrar auditoria da solicitação";
                }, {
                    readonly targetRef: "Order.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend calcula o início da janela de 7 dias subtraindo 7 dias do timestamp atual (systemDefault.now) para filtrar apenas pedidos dentro do período relevante";
                }];
                readonly accessPattern: {
                    readonly kind: "lookup";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.orderType", "Order.status", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.requestAiPromoSuggestions.requestAiPromoSuggestions";
                readonly handlerName: "cafeFlowRequestAiPromoSuggestionsHandler";
            }];
        };
    };
    export default requestAiPromoSuggestionsController;
    export const pipeline: readonly [{
        readonly id: "requestAiPromoSuggestions__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface PromoSuggestion {
        menuItemId: string;
        totalQuantitySold: number;
        averageUnitPrice: number;
        currentStockQuantity: number;
        suggestionScore: number;
        rationale: string;
    }
    export interface RequestAiPromoSuggestionsInput {
    }
    export interface RequestAiPromoSuggestionsOutput {
        suggestions: PromoSuggestion[];
        windowStart: string;
        windowEnd: string;
    }
    export function requestAiPromoSuggestions(ctx: RequestContext, _input: RequestAiPromoSuggestionsInput): Promise<RequestAiPromoSuggestionsOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowRequestAiPromoSuggestionsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary.defs" {
    export const requestAiSalesSummaryController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "requestAiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "requestAiSalesSummary";
            readonly controllerName: "RequestAiSalesSummaryController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRequestAiSalesSummaryHandler";
                readonly command: "requestAiSalesSummary";
                readonly usecaseRef: "requestAiSalesSummary";
                readonly inputTypeName: "RequestAiSalesSummaryInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno atualmente aberto para filtrar apenas os pedidos do dia corrente";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que solicita o resumo";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolvido a partir do único Shift com status open, filtrando apenas pedidos do turno/dia corrente";
                }, {
                    readonly targetRef: "Order.shiftId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "Resolvido a partir da sessão autenticada do gerente para autorizar o acesso ao resumo de vendas";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.createdAt", "Order.deliveredAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.requestAiSalesSummary.requestAiSalesSummary";
                readonly handlerName: "cafeFlowRequestAiSalesSummaryHandler";
            }];
        };
    };
    export default requestAiSalesSummaryController;
    export const pipeline: readonly [{
        readonly id: "requestAiSalesSummary__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface RequestAiSalesSummaryInput {
    }
    export interface RequestAiSalesSummaryOrder {
        orderId: string;
        status: string;
        orderType: string;
        createdAt: string;
        deliveredAt: string | null;
    }
    export interface RequestAiSalesSummaryTopSeller {
        menuItemId: string;
        totalQuantity: number;
        totalRevenue: number;
    }
    export interface RequestAiSalesSummaryStockLevel {
        stockItemId: string;
        currentQuantity: number;
        minimumLevel: number;
        unit: string;
    }
    export interface RequestAiSalesSummaryOutput {
        shiftId: string;
        orders: RequestAiSalesSummaryOrder[];
        topSellers: RequestAiSalesSummaryTopSeller[];
        stockLevels: RequestAiSalesSummaryStockLevel[];
        summaryText: string;
    }
    export function requestAiSalesSummary(ctx: RequestContext, _input: RequestAiSalesSummaryInput): Promise<RequestAiSalesSummaryOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowRequestAiSalesSummaryHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs" {
    export const updateOrderStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "UpdateOrderStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
                readonly command: "updateOrderStatus";
                readonly usecaseRef: "updateOrderStatus";
                readonly inputTypeName: "UpdateOrderStatusInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.orderId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Pedido selecionado pelo cozinheiro na fila da cozinha";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Order.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Novo status que o cozinheiro deseja atribuir ao pedido (inPreparation ou ready)";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno aberto no momento da atualização, para validar que o pedido pertence ao turno atual";
                }, {
                    readonly inputId: "inPreparationAt";
                    readonly fieldRef: "Order.inPreparationAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp definido quando o status passa a inPreparation";
                }, {
                    readonly inputId: "readyAt";
                    readonly fieldRef: "Order.readyAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp definido quando o status passa a ready";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Order.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp da última atualização do registro";
                }];
                readonly contextResolution: readonly [{
                    readonly inputId: "shiftId";
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolve o turno atualmente aberto (single Shift with status open) para validar que o pedido pertence ao turno ativo";
                }, {
                    readonly inputId: "inPreparationAt";
                    readonly targetRef: "Order.inPreparationAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Define o timestamp atual quando o status transita para inPreparation";
                }, {
                    readonly inputId: "readyAt";
                    readonly targetRef: "Order.readyAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Define o timestamp atual quando o status transita para ready";
                }, {
                    readonly inputId: "updatedAt";
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Define o timestamp atual em toda atualização do registro";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "single";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.updateOrderStatus";
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
            }];
        };
    };
    export default updateOrderStatusController;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateOrderStatusInput {
        orderId: string;
        status: string;
        inPreparationAt?: string;
        readyAt?: string;
    }
    export interface UpdateOrderStatusOutput {
        orderId: string;
        status: string;
        updatedAt: string;
    }
    export function updateOrderStatus(ctx: RequestContext, input: UpdateOrderStatusInput): Promise<UpdateOrderStatusOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateOrderStatusHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.defs" {
    export const viewDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewDashboard";
            readonly controllerName: "ViewDashboardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewDashboardHandler";
                readonly command: "viewDashboard";
                readonly usecaseRef: "viewDashboard";
                readonly inputTypeName: "ViewDashboardInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno atualmente aberto, usado para filtrar todos os dados do dashboard";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que solicita o dashboard";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend localiza o único Shift com status aberto no momento e usa seu shiftId para filtrar todos os pedidos e dados agregados do dashboard";
                }, {
                    readonly targetRef: "Order.shiftId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend extrai o actorId da sessão autenticada do gerente para autorizar o acesso ao dashboard";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "Lista agregada de pedidos do turno atual para composição do dashboard com total de vendas, itens mais vendidos e alertas de estoque baixo";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.status", "Order.orderType", "Order.createdAt", "Order.shiftId", "Order.deliveredAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.viewDashboard.viewDashboard";
                readonly handlerName: "cafeFlowViewDashboardHandler";
            }];
        };
    };
    export default viewDashboardController;
    export const pipeline: readonly [{
        readonly id: "viewDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewDashboard" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { Order } from "_102051_/l1/cafeFlow/layer_3_domain/entities/order";
    import type { StockLevel } from "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    export interface ViewDashboardInput {
    }
    export interface DashboardOrderSummary {
        orderId: string;
        status: Order['status'];
        orderType: Order['orderType'];
        createdAt: string;
        deliveredAt: string | null;
        totalAmount: number;
    }
    export interface DashboardTopSeller {
        menuItemId: string;
        totalQuantity: number;
    }
    export interface DashboardLowStockAlert {
        stockLevelId: string;
        stockItemId: string;
        currentQuantity: number;
        minimumLevel: number;
        unit: StockLevel['unit'];
    }
    export interface ViewDashboardOutput {
        shiftId: string;
        totalSales: number;
        orders: DashboardOrderSummary[];
        topSellers: DashboardTopSeller[];
        lowStockAlerts: DashboardLowStockAlert[];
    }
    export function viewDashboard(ctx: RequestContext, _input: ViewDashboardInput): Promise<ViewDashboardOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewDashboardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard.defs" {
    export const viewKitchenBoardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewKitchenBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "ViewKitchenBoardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewKitchenBoardHandler";
                readonly command: "viewKitchenBoard";
                readonly usecaseRef: "viewKitchenBoard";
                readonly inputTypeName: "ViewKitchenBoardInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno aberto no momento, usado para filtrar apenas pedidos do turno atual";
                }, {
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "Order.status";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Filtro padrão de status: exibe pedidos com status 'received' ou 'inPreparation'";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolvido buscando o único Shift com status 'open' no momento da consulta, garantindo que apenas pedidos do turno atual sejam exibidos";
                }, {
                    readonly targetRef: "Order.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O filtro de status é aplicado automaticamente pelo backend, restringindo a lista aos status 'received' e 'inPreparation' sem exigir entrada do usuário";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly filters: readonly ["Order.status", "Order.shiftId"];
                    readonly sort: readonly ["Order.priority", "Order.receivedAt"];
                    readonly pagination: "optional";
                    readonly selection: "single";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.priority", "Order.priorityReason", "Order.receivedAt", "Order.inPreparationAt", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.viewKitchenBoard";
                readonly handlerName: "cafeFlowViewKitchenBoardHandler";
            }];
        };
    };
    export default viewKitchenBoardController;
    export const pipeline: readonly [{
        readonly id: "viewKitchenBoard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { OrderItem } from "_102051_/l1/cafeFlow/layer_3_domain/entities/order";
    export interface ViewKitchenBoardInput {
        statusFilter?: string;
    }
    export interface ViewKitchenBoardEntry {
        orderId: string;
        status: string;
        orderType: string;
        tableNumber: string | null;
        priority: boolean | null;
        priorityReason: string | null;
        receivedAt: string | null;
        inPreparationAt: string | null;
        createdAt: string;
        items: OrderItem[];
    }
    export interface ViewKitchenBoardOutput {
        orders: ViewKitchenBoardEntry[];
    }
    /**
     * ViewKitchenBoard — returns the current kitchen board: all orders in
     * 'received' or 'inPreparation' status (or a user-supplied status override),
     * sorted by FIFO kitchen queue rules (priority first, then oldest receivedAt).
     *
     * Rules applied:
     * - dashboardCurrentShiftOnly: only orders from the current open shift are shown.
     * - fifoKitchenQueue: priority=true orders first, then receivedAt ascending.
     */
    export function viewKitchenBoard(ctx: RequestContext, input: ViewKitchenBoardInput): Promise<ViewKitchenBoardOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewKitchenBoardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard.defs" {
    export const viewOrderBoardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewOrderBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "ViewOrderBoardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewOrderBoardHandler";
                readonly command: "viewOrderBoard";
                readonly usecaseRef: "viewOrderBoard";
                readonly inputTypeName: "ViewOrderBoardInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno atualmente aberto para filtrar apenas pedidos do turno corrente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend resolve o turno atualmente aberto consultando a única Shift com status open e utiliza seu shiftId para filtrar os pedidos exibidos no painel";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.priority", "Order.priorityReason", "Order.receivedAt", "Order.inPreparationAt", "Order.readyAt", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.viewOrderBoard";
                readonly handlerName: "cafeFlowViewOrderBoardHandler";
            }];
        };
    };
    export default viewOrderBoardController;
    export const pipeline: readonly [{
        readonly id: "viewOrderBoard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewOrderBoardInput {
        shiftId?: string;
        limit?: number;
        offset?: number;
    }
    export interface OrderBoardItem {
        orderId: string;
        status: string;
        orderType: string;
        tableNumber?: string;
        priority?: boolean;
        priorityReason?: string;
        receivedAt?: string;
        inPreparationAt?: string;
        readyAt?: string;
        createdAt: string;
    }
    export interface ViewOrderBoardOutput {
        items: OrderBoardItem[];
    }
    export function viewOrderBoard(ctx: RequestContext, input: ViewOrderBoardInput): Promise<ViewOrderBoardOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewOrderBoardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport.defs" {
    export const viewShiftClosingReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "ViewShiftClosingReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewShiftClosingReportHandler";
                readonly command: "viewShiftClosingReport";
                readonly usecaseRef: "viewShiftClosingReport";
                readonly inputTypeName: "ViewShiftClosingReportInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "ShiftClosingReport.shiftId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do turno fechado cujo relatório de fechamento será exibido.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ShiftClosingReport.shiftId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.shiftId";
                    readonly description: "O shiftId é extraído do parâmetro de rota para localizar o único relatório de fechamento correspondente ao turno fechado.";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "";
                    readonly entity: "ShiftClosingReport";
                    readonly keyField: "ShiftClosingReport.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["ShiftClosingReport.shiftClosingReportId", "ShiftClosingReport.shiftId", "ShiftClosingReport.totalApurado", "ShiftClosingReport.paidOrderCount", "ShiftClosingReport.createdAt", "ShiftClosingReport.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.viewShiftClosingReport";
                readonly handlerName: "cafeFlowViewShiftClosingReportHandler";
            }];
        };
    };
    export default viewShiftClosingReportController;
    export const pipeline: readonly [{
        readonly id: "viewShiftClosingReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewShiftClosingReportInput {
        shiftId: string;
    }
    export interface ViewShiftClosingReportOutput {
        shiftClosingReportId: string;
        shiftId: string;
        totalApurado: number;
        paidOrderCount: number;
        createdAt: string;
        updatedAt: string;
        warning?: string | null;
    }
    export function viewShiftClosingReport(ctx: RequestContext, input: ViewShiftClosingReportInput): Promise<ViewShiftClosingReportOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewShiftClosingReportHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.defs" {
    export const menuItemIngredientTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "MenuItemIngredient";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "MenuItemIngredient";
            readonly tableName: "menu_item_ingredient";
            readonly columns: readonly [{
                readonly name: "menu_item_ingredient_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "menu_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "stock_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "unit";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "quantity, updatedAt";
            }];
            readonly primaryKey: readonly ["menu_item_ingredient_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_menu_item_ingredient_menu_item_id";
                readonly columns: readonly ["menu_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_ingredient_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_ingredient_unit";
                readonly columns: readonly ["unit"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_ingredient_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default menuItemIngredientTableDefinition;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredient__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const menuItemIngredientTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter.defs" {
    export const menuItemIngredientRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "MenuItemIngredientRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "MenuItemIngredientRepositoryAdapter";
            readonly entityId: "MenuItemIngredient";
            readonly portRef: "IMenuItemIngredientRepository";
            readonly tableRef: "menu_item_ingredients";
            readonly mdmReads: readonly ["ctx.mdm.collection.getMany/hydrateMany({ type: 'MenuItem', ids: [...menuItemIds] })", "ctx.mdm.collection.getMany/hydrateMany({ type: 'StockItem', ids: [...stockItemIds] })"];
            readonly notes: readonly ["columns: menu_item_ingredient_id, menu_item_id, stock_item_id, unit, created_at", "details JSONB: quantity, updatedAt", "menu_item_id -> MenuItem and stock_item_id -> StockItem resolved via bulk ctx.mdm.collection.getMany/hydrateMany"];
        };
    };
    export default menuItemIngredientRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredientRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient" {
    export type MenuItemIngredientUnit = 'kg' | 'gram' | 'liter' | 'milliliter' | 'portion' | 'unit';
    export interface MenuItemIngredient {
        menuItemIngredientId: string;
        menuItemId: string;
        stockItemId: string;
        quantity: number;
        unit: MenuItemIngredientUnit;
        createdAt: string;
        updatedAt: string;
    }
    /**
     * Unit compatibility groups — ingredients whose stock item uses a unit from the
     * same group are considered compatible.
     */
    export const UNIT_COMPATIBILITY_GROUPS: Record<MenuItemIngredientUnit, MenuItemIngredientUnit[]>;
    /**
     * Invariant: quantity must be greater than zero.
     */
    export function menuItemIngredientQuantityIsValid(ingredient: Pick<MenuItemIngredient, 'quantity'>): boolean;
    /**
     * Invariant: the unit of the link must be compatible with the unit of the
     * referenced stock item.
     */
    export function menuItemIngredientUnitIsCompatible(ingredientUnit: MenuItemIngredientUnit, stockItemUnit: MenuItemIngredientUnit): boolean;
    /**
     * Invariant: cannot have more than one link between the same menuItemId and stockItemId.
     * Returns true when the given list has no duplicate (menuItemId, stockItemId) pairs.
     */
    export function menuItemIngredientNoDuplicateLinks(ingredients: Array<Pick<MenuItemIngredient, 'menuItemId' | 'stockItemId'>>): boolean;
    /**
     * Returns the duplicate key if one exists, or null otherwise.
     */
    export function findDuplicateMenuItemIngredientLink(ingredients: Array<Pick<MenuItemIngredient, 'menuItemId' | 'stockItemId'>>): {
        menuItemId: string;
        stockItemId: string;
    } | null;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository" {
    import type { MenuItemIngredient } from "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient";
    export interface MenuItemIngredientFilter {
        menuItemId?: string;
        stockItemId?: string;
        unit?: MenuItemIngredient['unit'];
    }
    export interface IMenuItemIngredientRepository {
        /** Retrieve a menu item ingredient by its unique identifier. Throws NOT_FOUND when absent. */
        getById(id: string): Promise<MenuItemIngredient>;
        /** List menu item ingredients matching the given filter. */
        list(filter?: MenuItemIngredientFilter): Promise<MenuItemIngredient[]>;
        /** Persist the menu item ingredient aggregate (upsert). */
        save(menuItemIngredient: MenuItemIngredient): Promise<void>;
        /** Find ingredient mappings for a specific menu item. */
        findByMenuItemId(menuItemId: string): Promise<MenuItemIngredient[]>;
        /** Find menu item mappings for a specific ingredient (stock item). */
        findByIngredientId(ingredientId: string): Promise<MenuItemIngredient[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IMenuItemIngredientRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository";
    export function createMenuItemIngredientRepositoryAdapter(ctx: RequestContext): IMenuItemIngredientRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "order_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "shift_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "FK to shift";
            }, {
                readonly name: "status";
                readonly type: "VARCHAR";
                readonly nullable: false;
                readonly description: "Order status";
            }, {
                readonly name: "order_type";
                readonly type: "VARCHAR";
                readonly nullable: false;
                readonly description: "Order type";
            }, {
                readonly name: "created_at";
                readonly type: "TIMESTAMP";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "JSONB";
                readonly nullable: true;
                readonly description: "tableNumber, priority, priorityReason, receivedAt, inPreparationAt, readyAt, deliveredAt, updatedAt + child collection OrderItem";
            }];
            readonly primaryKey: readonly ["order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_shift_id";
                readonly columns: readonly ["shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_type";
                readonly columns: readonly ["order_type"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly ["OrderItem"];
            };
            readonly appendOnly: false;
            readonly purpose: "operational";
            readonly retentionDays: 0;
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/order" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepositoryAdapter";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain Order <-> orders row via ctx.data.moduleData", "Real columns snake_case: order_id, shift_id, status, order_type, created_at", "details JSONB: tableNumber, priority, priorityReason, receivedAt, inPreparationAt, readyAt, deliveredAt, updatedAt", "Embedded OrderItem[] mapped to/from details.orderItems", "No MDM refs"];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository";
    export function createOrderRepositoryAdapter(ctx: RequestContext): IOrderRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/seeds" {
    import type { TableSeedRows } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const menuItemIngredientSeeds: TableSeedRows;
    export const orderSeeds: TableSeedRows;
    export const shiftSeeds: TableSeedRows;
    export const shiftClosingReportSeeds: TableSeedRows;
    export const stockAdjustmentSeeds: TableSeedRows;
    export const stockConsumptionSeeds: TableSeedRows;
    export const stockLevelSeeds: TableSeedRows;
    export const mdmEntityIndexSeeds: TableSeedRows;
    export const mdmDocumentSeeds: TableSeedRows;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.defs" {
    export const shiftTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Shift";
            readonly tableName: "shift";
            readonly columns: readonly [{
                readonly name: "shift_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "status";
                readonly type: "VARCHAR";
                readonly nullable: false;
                readonly description: "Shift status";
            }, {
                readonly name: "created_at";
                readonly type: "TIMESTAMP";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "JSONB";
                readonly nullable: true;
                readonly description: "openedAt, closedAt, openedBy, closedBy, totalApurado, notes, updatedAt";
            }];
            readonly primaryKey: readonly ["shift_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_shift_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_shift_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: false;
            readonly purpose: "operational";
            readonly retentionDays: 0;
        };
    };
    export default shiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shift__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shift" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.defs" {
    export const shiftClosingReportTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "ShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "ShiftClosingReport";
            readonly tableName: "shift_closing_report";
            readonly columns: readonly [{
                readonly name: "shift_closing_report_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "shift_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "FK to shift";
            }, {
                readonly name: "created_at";
                readonly type: "TIMESTAMP";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "JSONB";
                readonly nullable: true;
                readonly description: "totalApurado, paidOrderCount, updatedAt";
            }];
            readonly primaryKey: readonly ["shift_closing_report_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_shift_closing_report_shift_id";
                readonly columns: readonly ["shift_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_shift_closing_report_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: false;
            readonly purpose: "operational";
            readonly retentionDays: 0;
        };
    };
    export default shiftClosingReportTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReport__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftClosingReportTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter.defs" {
    export const shiftClosingReportRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ShiftClosingReportRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ShiftClosingReportRepositoryAdapter";
            readonly entityId: "ShiftClosingReport";
            readonly portRef: "IShiftClosingReportRepository";
            readonly tableRef: "shift_closing_reports";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain ShiftClosingReport <-> shift_closing_reports row via ctx.data.moduleData", "Real columns snake_case: shift_closing_report_id, shift_id, created_at", "details JSONB: totalApurado, paidOrderCount, updatedAt", "No MDM refs"];
        };
    };
    export default shiftClosingReportRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReportRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IShiftClosingReportRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository";
    export function createShiftClosingReportRepositoryAdapter(ctx: RequestContext): IShiftClosingReportRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.defs" {
    export const shiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ShiftRepositoryAdapter";
            readonly entityId: "Shift";
            readonly portRef: "IShiftRepository";
            readonly tableRef: "shifts";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain Shift <-> shifts row via ctx.data.moduleData", "Real columns snake_case: shift_id, status, created_at", "details JSONB: openedAt, closedAt, openedBy, closedBy, totalApurado, notes, updatedAt", "No embedded members or MDM refs"];
        };
    };
    export default shiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "shiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IShiftRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository";
    export function createShiftRepositoryAdapter(ctx: RequestContext): IShiftRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.defs" {
    export const stockAdjustmentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockAdjustment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockAdjustment";
            readonly tableName: "stock_adjustment";
            readonly columns: readonly [{
                readonly name: "stock_adjustment_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "stock_item_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "FK to stock item";
            }, {
                readonly name: "status";
                readonly type: "VARCHAR";
                readonly nullable: false;
                readonly description: "Adjustment status";
            }, {
                readonly name: "created_at";
                readonly type: "TIMESTAMP";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "JSONB";
                readonly nullable: true;
                readonly description: "quantity, reason, voidedAt, voidedReason";
            }];
            readonly primaryKey: readonly ["stock_adjustment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_adjustment_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_stock_adjustment_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_stock_adjustment_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 365;
        };
    };
    export default stockAdjustmentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockAdjustment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockAdjustmentTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter.defs" {
    export const stockAdjustmentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockAdjustmentRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockAdjustmentRepositoryAdapter";
            readonly entityId: "StockAdjustment";
            readonly portRef: "IStockAdjustmentRepository";
            readonly tableRef: "stock_adjustments";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain StockAdjustment <-> stock_adjustments row via ctx.data.moduleData (append-only event adapter)", "Real columns snake_case: stock_adjustment_id, stock_item_id, status, created_at", "details JSONB: quantity, reason, voidedAt, voidedReason", "Append-only: insert row only, no update/delete; exposes finder/read methods", "No MDM refs"];
        };
    };
    export default stockAdjustmentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockAdjustmentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment" {
    export type StockAdjustmentStatus = 'posted' | 'voided';
    export interface StockAdjustment {
        stockAdjustmentId: string;
        stockItemId: string;
        status: StockAdjustmentStatus;
        quantity: number;
        reason: string;
        voidedAt: string | null;
        voidedReason: string | null;
        createdAt: string;
    }
    export const STOCK_ADJUSTMENT_STATUS_TRANSITIONS: Record<StockAdjustmentStatus, StockAdjustmentStatus[]>;
    export function canTransitionStockAdjustment(from: StockAdjustmentStatus, to: StockAdjustmentStatus): boolean;
    export function isStockAdjustmentActive(adjustment: Pick<StockAdjustment, 'status'>): boolean;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository" {
    import type { StockAdjustment, StockAdjustmentStatus } from "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment";
    export interface StockAdjustmentListFilter {
        stockItemId?: string;
        status?: StockAdjustmentStatus;
    }
    export interface IStockAdjustmentRepository {
        append(record: StockAdjustment): Promise<void>;
        list(filter: StockAdjustmentListFilter): Promise<StockAdjustment[]>;
        listByPeriod(start: Date, end: Date): Promise<StockAdjustment[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockAdjustmentRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository";
    export function createStockAdjustmentRepositoryAdapter(ctx: RequestContext): IStockAdjustmentRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.defs" {
    export const stockConsumptionTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockConsumption";
            readonly tableName: "stock_consumption";
            readonly columns: readonly [{
                readonly name: "stock_consumption_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "stock_item_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "FK to stock item";
            }, {
                readonly name: "order_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "FK to order";
            }, {
                readonly name: "status";
                readonly type: "VARCHAR";
                readonly nullable: false;
                readonly description: "Consumption status";
            }, {
                readonly name: "created_at";
                readonly type: "TIMESTAMP";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "JSONB";
                readonly nullable: true;
                readonly description: "quantity, voidedAt, voidReason";
            }];
            readonly primaryKey: readonly ["stock_consumption_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_consumption_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_stock_consumption_order_id";
                readonly columns: readonly ["order_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_stock_consumption_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_stock_consumption_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 365;
        };
    };
    export default stockConsumptionTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockConsumption__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockConsumptionTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter.defs" {
    export const stockConsumptionRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockConsumptionRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockConsumptionRepositoryAdapter";
            readonly entityId: "StockConsumption";
            readonly portRef: "IStockConsumptionRepository";
            readonly tableRef: "stock_consumptions";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain StockConsumption <-> stock_consumptions row via ctx.data.moduleData (append-only event adapter)", "Real columns snake_case: stock_consumption_id, stock_item_id, order_id, status, created_at", "details JSONB: quantity, voidedAt, voidReason", "Append-only: insert row only, no update/delete; exposes finder/read methods", "No MDM refs"];
        };
    };
    export default stockConsumptionRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockConsumptionRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockConsumptionRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository";
    export function createStockConsumptionRepositoryAdapter(ctx: RequestContext): IStockConsumptionRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.defs" {
    export const stockLevelTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockLevel";
            readonly tableName: "stock_level";
            readonly columns: readonly [{
                readonly name: "stock_level_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "Primary key";
            }, {
                readonly name: "stock_item_id";
                readonly type: "UUID";
                readonly nullable: false;
                readonly description: "FK to stock item";
            }, {
                readonly name: "unit";
                readonly type: "VARCHAR";
                readonly nullable: false;
                readonly description: "Unit of measure";
            }, {
                readonly name: "created_at";
                readonly type: "TIMESTAMP";
                readonly nullable: false;
                readonly description: "Creation timestamp for ordering";
            }, {
                readonly name: "details";
                readonly type: "JSONB";
                readonly nullable: true;
                readonly description: "currentQuantity, minimumLevel, lastDecrementAt, lastAdjustmentAt, updatedAt";
            }];
            readonly primaryKey: readonly ["stock_level_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_level_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_stock_level_unit";
                readonly columns: readonly ["unit"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_stock_level_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: false;
            readonly purpose: "operational";
            readonly retentionDays: 0;
        };
    };
    export default stockLevelTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockLevel__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockLevelTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.defs" {
    export const stockLevelRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockLevelRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockLevelRepositoryAdapter";
            readonly entityId: "StockLevel";
            readonly portRef: "IStockLevelRepository";
            readonly tableRef: "stock_levels";
            readonly mdmReads: readonly ["ctx.mdm.collection.getMany('stock_item')", "ctx.mdm.collection.hydrateMany('stock_item')"];
            readonly notes: readonly ["Domain StockLevel <-> stock_levels row via ctx.data.moduleData", "Real columns snake_case: stock_level_id, stock_item_id, unit, created_at", "details JSONB: currentQuantity, minimumLevel, lastDecrementAt, lastAdjustmentAt, updatedAt", "MDM ref StockItem resolved via ctx.mdm.collection.getMany/hydrateMany (bulk load by collected ids, never in loop)", "stock_item_id column stores the MDM reference id"];
        };
    };
    export default stockLevelRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockLevelRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockLevelRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository";
    export function createStockLevelRepositoryAdapter(ctx: RequestContext): IStockLevelRepository;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.defs" {
    export const menuItemIngredientRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "MenuItemIngredientRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItemIngredient";
            readonly interfaceName: "IMenuItemIngredientRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: MenuItemIngredientId"];
                readonly returns: "MenuItemIngredient";
                readonly description: "Retrieve a menu item ingredient by its unique identifier";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: MenuItemIngredientFilter"];
                readonly returns: "MenuItemIngredient[]";
                readonly description: "List menu item ingredients matching the given filter";
            }, {
                readonly name: "save";
                readonly params: readonly ["menuItemIngredient: MenuItemIngredient"];
                readonly returns: "void";
                readonly description: "Persist the menu item ingredient aggregate";
            }, {
                readonly name: "findByMenuItemId";
                readonly params: readonly ["menuItemId: MenuItemId"];
                readonly returns: "MenuItemIngredient[]";
                readonly description: "Find ingredient mappings for a specific menu item";
            }, {
                readonly name: "findByIngredientId";
                readonly params: readonly ["ingredientId: IngredientId"];
                readonly returns: "MenuItemIngredient[]";
                readonly description: "Find menu item mappings for a specific ingredient";
            }];
        };
    };
    export default menuItemIngredientRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredientRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Order";
                readonly params: readonly ["id: OrderId"];
            }, {
                readonly name: "list";
                readonly returns: "Order[]";
                readonly params: readonly ["filter: OrderListFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["order: Order"];
            }, {
                readonly name: "listByStatus";
                readonly returns: "Order[]";
                readonly params: readonly ["status: OrderStatus"];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "Order[]";
                readonly params: readonly ["start: Date", "end: Date"];
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.defs" {
    export const shiftClosingReportRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ShiftClosingReportRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftClosingReport";
            readonly interfaceName: "IShiftClosingReportRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "ShiftClosingReport";
                readonly params: readonly ["id: ShiftClosingReportId"];
            }, {
                readonly name: "list";
                readonly returns: "ShiftClosingReport[]";
                readonly params: readonly ["filter: ShiftClosingReportListFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["report: ShiftClosingReport"];
            }, {
                readonly name: "listByShiftId";
                readonly returns: "ShiftClosingReport[]";
                readonly params: readonly ["shiftId: ShiftId"];
            }];
        };
    };
    export default shiftClosingReportRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReportRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.defs" {
    export const shiftRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ShiftRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Shift";
            readonly interfaceName: "IShiftRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Shift";
                readonly params: readonly ["id: ShiftId"];
            }, {
                readonly name: "list";
                readonly returns: "Shift[]";
                readonly params: readonly ["filter: ShiftListFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["shift: Shift"];
            }, {
                readonly name: "listOpenShifts";
                readonly returns: "Shift[]";
                readonly params: readonly [];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "Shift[]";
                readonly params: readonly ["start: Date", "end: Date"];
            }];
        };
    };
    export default shiftRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "shiftRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.defs" {
    export const stockAdjustmentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockAdjustmentRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockAdjustment";
            readonly interfaceName: "IStockAdjustmentRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly returns: "void";
                readonly params: readonly ["record: StockAdjustment"];
            }, {
                readonly name: "list";
                readonly returns: "StockAdjustment[]";
                readonly params: readonly ["filter: StockAdjustmentListFilter"];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "StockAdjustment[]";
                readonly params: readonly ["start: Date", "end: Date"];
            }];
        };
    };
    export default stockAdjustmentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockAdjustmentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.defs" {
    export const stockConsumptionRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockConsumptionRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockConsumption";
            readonly interfaceName: "IStockConsumptionRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly returns: "void";
                readonly params: readonly ["record: StockConsumption"];
            }, {
                readonly name: "list";
                readonly returns: "StockConsumption[]";
                readonly params: readonly ["filter: StockConsumptionListFilter"];
            }, {
                readonly name: "listByOwnerId";
                readonly returns: "StockConsumption[]";
                readonly params: readonly ["orderId: OrderId"];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "StockConsumption[]";
                readonly params: readonly ["start: Date", "end: Date"];
            }];
        };
    };
    export default stockConsumptionRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockConsumptionRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.defs" {
    export const stockLevelRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockLevelRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockLevel";
            readonly interfaceName: "IStockLevelRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "StockLevel";
                readonly params: readonly ["id: StockLevelId"];
            }, {
                readonly name: "list";
                readonly returns: "StockLevel[]";
                readonly params: readonly ["filter: StockLevelListFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["stockLevel: StockLevel"];
            }, {
                readonly name: "listLowStock";
                readonly returns: "StockLevel[]";
                readonly params: readonly [];
            }, {
                readonly name: "listByProductId";
                readonly returns: "StockLevel[]";
                readonly params: readonly ["productId: ProductId"];
            }];
        };
    };
    export default stockLevelRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockLevelRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.defs" {
    export const browseMenuItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseMenuItems";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "browseMenuItems";
                readonly inputTypeName: "BrowseMenuItemsInput";
                readonly outputTypeName: "BrowseMenuItemsOutput";
                readonly input: readonly [{
                    readonly name: "statusFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filtro opcional por status do item (draft, active, inactive)";
                }, {
                    readonly name: "menuCategoryIdFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filtro opcional por categoria do item (menuCategoryId)";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "itemType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "activatedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["simpleItemsOnly"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve activeCompanyId from ctx.sessionContext.activeCompanyId (businessContext scope).", "2. Retrieve MenuCategory MDM records scoped to the active company via ctx.mdm.collection.listByType({ type: 'MenuCategory' }) and filter by company relationship to build the set of allowed menuCategoryIds.", "3. Retrieve MenuItem MDM records via ctx.mdm.collection.listByType({ type: 'MenuItem' }) and filter to only those whose menuCategoryId is in the allowed set from step 2.", "4. Apply rule simpleItemsOnly: keep only items where itemType === 'simple'; variant items are excluded from the listing because only simple items are supported.", "5. If statusFilter is provided, filter the result set to items whose status matches the given value (draft, active, or inactive).", "6. If menuCategoryIdFilter is provided, further filter the result set to items whose menuCategoryId matches the given value.", "7. Project each remaining MenuItem to the output shape (menuItemId, name, description, menuCategoryId, price, itemType, status, activatedAt, createdAt, updatedAt) and return the collection."];
            }];
            readonly mdmRefs: readonly ["MenuItem", "MenuCategory"];
        };
    };
    export default browseMenuItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseMenuItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.defs" {
    export const browseStockItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseStockItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseStockItems";
            readonly ports: readonly ["StockLevel"];
            readonly functions: readonly [{
                readonly functionName: "browseStockItems";
                readonly inputTypeName: "BrowseStockItemsInput";
                readonly outputTypeName: "BrowseStockItemsOutput";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StockItem";
                    readonly description: "Termo de busca opcional para filtrar itens de estoque pelo nome.";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Número da página para paginação opcional (base 1).";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Quantidade de itens por página para paginação opcional.";
                }];
                readonly output: readonly [{
                    readonly name: "items";
                    readonly type: "StockItemBrowseResult[]";
                    readonly required: true;
                    readonly description: "Lista de itens de estoque com nome, unidade, limite mínimo, quantidade atual e flag de alerta de estoque baixo.";
                }, {
                    readonly name: "totalCount";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total de itens encontrados antes da paginação.";
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Página atual retornada.";
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Tamanho da página aplicado.";
                }];
                readonly ports: readonly ["StockLevel"];
                readonly rulesApplied: readonly ["lowStockAlertCalculation"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver actorId a partir de ctx.sessionContext (sessão autenticada do gerente) para autorização de acesso ao estoque.", "2. Listar StockItems do MDM via ctx.mdm.collection.listByType({ type: 'StockItem' }), aplicando filtro opcional por searchTerm sobre o campo name quando fornecido.", "3. Coletar todos os stockItemIds do resultado da listagem de MDM.", "4. Consultar StockLevels em lote via porta StockLevel (stockLevelPort.listByStockItemIds) para todos os stockItemIds coletados, evitando chamadas individuais em loop.", "5. Join em memória: para cada StockItem, localizar o StockLevel correspondente pelo stockItemId e extrair currentQuantity.", "6. Aplicar regra lowStockAlertCalculation: para cada item, calcular lowStockAlert = (StockLevel.currentQuantity <= StockItem.minimumLevel). Itens sem StockLevel associado recebem lowStockAlert = false e currentQuantity = 0.", "7. Ordenar a lista resultante por name (ascendente) para facilitar a consulta.", "8. Aplicar paginação opcional: se page e pageSize forem fornecidos, fatiar a lista ordenada; caso contrário, retornar todos os itens com page=1 e pageSize=totalCount.", "9. Retornar items (cada item contendo stockItemId, name, unit, minimumLevel, currentQuantity, lowStockAlert, createdAt, updatedAt), totalCount, page e pageSize."];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default browseStockItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseStockItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/closeShift.defs" {
    export const closeShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeShift";
            readonly ports: readonly ["Shift", "Order", "ShiftClosingReport", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "closeShift";
                readonly inputTypeName: "CloseShiftInput";
                readonly outputTypeName: "CloseShiftOutput";
                readonly input: readonly [{
                    readonly name: "totalApurado";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Valor total apurado no fechamento do turno, informado pelo gerente para conferência.";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Observações gerais sobre o turno, opcionais.";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Identificador do turno aberto, resolvido automaticamente localizando o único Shift com status 'open'.";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "closedBy";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Identificador do gerente autenticado, resolvido a partir da sessão ativa (ctx.sessionContext.actorId).";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Data e hora do fechamento, resolvida automaticamente como ctx.clock.now().";
                    readonly ofEntity: "Shift";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "closedBy";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "totalApurado";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "shiftClosingReportId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                }, {
                    readonly name: "paidOrderCount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                }];
                readonly ports: readonly ["Shift", "Order", "ShiftClosingReport"];
                readonly rulesApplied: readonly ["singleOpenShift", "shiftClosingRecordsRevenue", "dashboardCurrentShiftOnly"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve closedBy from ctx.sessionContext.actorId and closedAt from ctx.clock.now().", "2. If shiftId is not provided, query the Shift port for all shifts with status='open' (rule: singleOpenShift).", "3. Validate that exactly one open shift exists — if zero or more than one, throw a validation error referencing rule 'singleOpenShift'.", "4. Load the target Shift aggregate via Shift port getById (using the resolved or provided shiftId).", "5. Validate the loaded Shift has status='open'; if not, throw a conflict error.", "6. Mutate the Shift: set status='closed', closedAt=resolved timestamp, closedBy=resolved actorId, totalApurado=input value, notes=input value (or null), updatedAt=ctx.clock.now().", "7. Query the Order port for all Orders where shiftId=target shiftId and status='delivered' to compute paidOrderCount (rule: shiftClosingRecordsRevenue — the closing report must record the revenue and paid order count).", "8. Create a ShiftClosingReport via ShiftClosingReport port: shiftClosingReportId=ctx.idGenerator.generate(), shiftId=target shiftId, totalApurado=input value, paidOrderCount=count from step 7, createdAt=ctx.clock.now(), updatedAt=ctx.clock.now().", "9. Save the mutated Shift and the new ShiftClosingReport inside a single transaction (ctx.data transaction wrapper).", "10. After save, verify no Shift with status='open' remains (rule: dashboardCurrentShiftOnly — the dashboard must show no current open shift after closing).", "11. Return the closed Shift fields (shiftId, status, closedAt, closedBy, totalApurado, notes) and the ShiftClosingReport fields (shiftClosingReportId, paidOrderCount)."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default closeShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "closeShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/closeShift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/closeShift.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs" {
    export const createOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOrder";
            readonly ports: readonly ["Order", "StockLevel", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "createOrder";
                readonly inputTypeName: "CreateOrderInput";
                readonly outputTypeName: "CreateOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Tipo do pedido: 'table' (consumo na mesa) ou 'takeout' (para viagem)";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Número da mesa, obrigatório quando orderType = 'table'";
                }, {
                    readonly name: "orderItems";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Lista de itens do cardápio com menuItemId e quantidade";
                }, {
                    readonly name: "priority";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Indica se o pedido é prioritário no preparo";
                }, {
                    readonly name: "priorityReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Justificativa da priorização, obrigatória quando priority = true";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identificador único gerado para o novo pedido";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Status inicial do pedido: 'registered'";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Tipo do pedido criado";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Número da mesa quando orderType = 'table', nulo quando 'takeout'";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Momento de criação do pedido";
                }];
                readonly ports: readonly ["Order", "StockLevel", "Shift"];
                readonly rulesApplied: readonly ["stockDecrementOnOrderLaunch", "orderStatusFlow", "fifoKitchenQueue"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve active shift: query Shift port for a Shift with status='open'; if none found, throw validation error 'No open shift available for order creation'", "2. Validate orderType against enum ['table','takeout']; if orderType='table', require tableNumber (non-null, non-empty) — throw error with rule orderStatusFlow if missing; if orderType='takeout', set tableNumber=null", "3. Validate priority: if priority=true, require priorityReason (non-null, non-empty) — throw error if missing", "4. Validate orderItems: must be non-empty array; each item must have menuItemId (string) and quantity (number > 0)", "5. Generate orderId via ctx.idGenerator; set createdAt and updatedAt via ctx.clock", "6. Collect all menuItemIds from orderItems; fetch MenuItem MDM records in bulk via ctx.mdm.collection.getMany({ mdmIds: menuItemIds })", "7. Validate every MenuItem exists and has status='active'; throw error listing any inactive or missing menuItemIds", "8. Build Order aggregate root: set orderId, shiftId (from active shift), status='registered' (rule orderStatusFlow: initial status must be 'registered'), orderType, tableNumber, priority (default false), priorityReason (default null), createdAt, updatedAt; leave receivedAt/inPreparationAt/readyAt/deliveredAt as null", "9. Build OrderItem children: for each input item, generate orderItemId via ctx.idGenerator, set orderId=orderId, menuItemId, quantity, unitPrice=MenuItem.price (from MDM record), createdAt, updatedAt", "10. Resolve ingredient stock items for all MenuItems: use ctx.mdm.collection.relatedOfMany({ mdmIds: menuItemIds, relationType: 'requires-ingredient' }) to get stock item ids and quantities per serving", "11. Aggregate total consumption per stockItemId: for each OrderItem, multiply quantity by ingredient quantity-per-serving; sum across all OrderItems that share the same stockItemId", "12. Fetch all affected StockLevel records via StockLevel port (by stockItemId); for each, validate currentQuantity >= consumption amount — throw error with rule stockDecrementOnOrderLaunch if insufficient stock", "13. Decrement each StockLevel.currentQuantity by the aggregated consumption amount; update lastDecrementAt=createdAt and updatedAt=createdAt (rule stockDecrementOnOrderLaunch)", "14. Build StockConsumption audit records: for each stock item consumed, generate stockConsumptionId via ctx.idGenerator, set stockItemId, orderId, quantity=consumed amount, status='posted', createdAt=createdAt; append these as event records through the Order port inside the same transaction (eventWrites: StockConsumption, purpose=audit, persisted=true)", "15. Save Order aggregate (including OrderItem children and StockConsumption event records) through Order port inside the transaction", "16. Save all updated StockLevel records through StockLevel port inside the same transaction", "17. The order is now in status 'registered' and enters the kitchen queue in FIFO order based on createdAt (rule fifoKitchenQueue: orders are processed in creation-timestamp order)", "18. Return { orderId, status='registered', orderType, tableNumber, createdAt }"];
            }];
            readonly mdmRefs: readonly ["MenuItem"];
        };
    };
    export default createOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/createOrder.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.defs" {
    export const deliverOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deliverOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deliverOrder";
            readonly ports: readonly ["Order", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "deliverOrder";
                readonly inputTypeName: "DeliverOrderInput";
                readonly outputTypeName: "DeliverOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Pedido selecionado pelo atendente no painel para entrega";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "deliveredAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order", "StockConsumption"];
                readonly rulesApplied: readonly ["orderStatusFlow", "readyBeforeDelivered"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the Order aggregate by orderId via OrderPort.getById(orderId).", "2. Apply rule 'readyBeforeDelivered': verify order.status === 'ready'. If not, throw a validation error with rule id 'readyBeforeDelivered' — only orders in 'ready' status can be delivered.", "3. Apply rule 'orderStatusFlow': confirm the transition 'ready' -> 'delivered' is a valid forward transition in the order status enum sequence.", "4. Resolve deliveredAt = ctx.clock.now() and updatedAt = ctx.clock.now() (systemDefault — not user input).", "5. Mutate the Order: set status = 'delivered', deliveredAt = resolved timestamp, updatedAt = resolved timestamp.", "6. Save the Order aggregate via OrderPort.save(order) inside the same transaction.", "7. Append a StockConsumption audit event via StockConsumptionPort inside the same transaction, recording the delivery transition for the order.", "8. Return { orderId, status, deliveredAt, updatedAt }."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default deliverOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "deliverOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.defs" {
    export const manageMenuItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateMenuItem";
                readonly inputTypeName: "UpdateMenuItemInput";
                readonly outputTypeName: "UpdateMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identificador do item do cardápio selecionado para edição";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Nome do item do cardápio exibido no POS";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Descrição detalhada do item do cardápio";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Categoria de classificação à qual o item pertence";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Preço de venda do item do cardápio";
                }, {
                    readonly name: "itemType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Tipo do item: deve ser 'simple' nesta fase";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Status do item: rascunho, ativo ou inativo";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identificador do item do cardápio atualizado";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Nome do item do cardápio";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Descrição detalhada do item do cardápio";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Categoria de classificação à qual o item pertence";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Preço de venda do item do cardápio";
                }, {
                    readonly name: "itemType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Tipo do item";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Status do item";
                }, {
                    readonly name: "activatedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Data e hora de ativação do item";
                }, {
                    readonly name: "inactivatedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Data e hora de inativação do item";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Data e hora da última atualização";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["simpleItemsOnly", "menuItemRequiresIngredient"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve actorId from ctx.sessionContext.actorId and updatedAt from ctx.clock.now()", "2. Load existing MenuItem via ctx.mdm.entity.get({ mdmId: menuItemId })", "3. Validate itemType === 'simple' (rule simpleItemsOnly); reject with error if itemType is 'variant'", "4. If status is changing to 'active' (from 'draft' or 'inactive'), query MenuItemIngredient via ctx.mdm.collection.listByType for ingredients related to this menuItemId; reject if none found (rule menuItemRequiresIngredient)", "5. If status transitions to 'active', set activatedAt = ctx.clock.now(); if transitions to 'inactive', set inactivatedAt = ctx.clock.now()", "6. Build update payload with name, description, menuCategoryId, price, itemType, status, activatedAt/inactivatedAt as applicable, and updatedAt = ctx.clock.now()", "7. Persist via ctx.mdm.entity.update({ mdmId: menuItemId, details: payload })", "8. Return updated MenuItem fields: menuItemId, name, description, menuCategoryId, price, itemType, status, activatedAt, inactivatedAt, updatedAt"];
            }];
            readonly mdmRefs: readonly ["MenuItem", "MenuCategory"];
        };
    };
    export default manageMenuItemUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.defs" {
    export const manageStockItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageStockItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "manageStockItem";
                readonly inputTypeName: "ManageStockItemInput";
                readonly outputTypeName: "ManageStockItemOutput";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identificador do item de estoque a ser atualizado, obtido do parâmetro de rota.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Nome do ingrediente editado pelo gerente.";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unidade de medida do ingrediente (kg, liter, portion ou unit).";
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo.";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlertCalculation"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate that name is a non-empty string.", "2. Validate that unit is one of the allowed enum values: kg, liter, portion, unit.", "3. Apply rule lowStockAlertCalculation: validate that minimumLevel is a non-negative number (>= 0); if negative, reject with rule id in error details.", "4. Load the existing StockItem by stockItemId via ctx.mdm.entity.get({ mdmId: stockItemId }) to confirm it exists; throw NotFound if missing.", "5. Resolve updatedAt from ctx.clock.now() (systemDefault) — do not accept it as user input.", "6. Update the StockItem via ctx.mdm.entity.update({ mdmId: stockItemId, details: { name, unit, minimumLevel, updatedAt } }) inside a single transaction (ctx.data transaction wrapper).", "7. Return the updated StockItem projection: stockItemId, name, unit, minimumLevel, updatedAt."];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default manageStockItemUsecase;
    export const pipeline: readonly [{
        readonly id: "manageStockItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/openShift.defs" {
    export const openShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "openShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "openShift";
            readonly ports: readonly ["Shift"];
            readonly functions: readonly [{
                readonly functionName: "openShift";
                readonly inputTypeName: "OpenShiftInput";
                readonly outputTypeName: "OpenShiftOutput";
                readonly input: readonly [{
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Observações gerais opcionais sobre o turno, informadas pelo gerente ao abrir.";
                    readonly ofEntity: "Shift";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador único do turno criado.";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Situação do turno após abertura ('open').";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Data e hora de abertura do turno.";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "openedBy";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador do gerente que abriu o turno.";
                    readonly ofEntity: "Shift";
                }];
                readonly ports: readonly ["Shift"];
                readonly rulesApplied: readonly ["singleOpenShift"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve system defaults: generate shiftId via ctx.idGenerator, set status='open', openedAt=ctx.clock.now(), createdAt=ctx.clock.now(), updatedAt=ctx.clock.now().", "2. Resolve openedBy from ctx.sessionContext.actorId (the authenticated manager).", "3. Apply rule singleOpenShift: query the Shift port for any existing Shift with status='open'. If one exists, reject the operation with a validation error referencing rule 'singleOpenShift'.", "4. Build the Shift aggregate with shiftId, status='open', openedAt, openedBy, notes (if provided), createdAt, updatedAt; leave closedAt, closedBy and totalApurado null.", "5. Persist the Shift via the Shift port inside a single transaction (ctx.data transaction wrapper).", "6. Return shiftId, status, openedAt, openedBy."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default openShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "openShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/openShift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/openShift.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.defs" {
    export const requestAiPromoSuggestionsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "requestAiPromoSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "requestAiPromoSuggestions";
            readonly ports: readonly ["Order", "StockLevel", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "requestAiPromoSuggestions";
                readonly inputTypeName: "RequestAiPromoSuggestionsInput";
                readonly outputTypeName: "RequestAiPromoSuggestionsOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "suggestions";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Lista de sugestões de itens para promoção derivadas dos padrões de venda dos últimos 7 dias";
                }, {
                    readonly name: "windowStart";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Data de início da janela de análise (7 dias antes do momento atual)";
                }, {
                    readonly name: "windowEnd";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Data de fim da janela de análise (momento atual)";
                }];
                readonly ports: readonly ["Order", "StockLevel"];
                readonly rulesApplied: readonly ["aiPromoBasedOnLast7Days", "aiConsumesDomainData"];
                readonly transactional: false;
                readonly steps: readonly ["Resolve actorId from ctx.sessionContext.actorId for audit and permission context", "Resolve windowStart by computing ctx.clock.now() minus 7 days (rule: aiPromoBasedOnLast7Days)", "Load orders from the Order port filtered by createdAt >= windowStart and createdAt <= now", "Collect all orderIds from the fetched orders", "Load OrderItem children embedded in each Order aggregate through the Order port (no separate OrderItem repository)", "Aggregate OrderItem data: group by menuItemId, sum quantities, compute average unitPrice, count occurrences", "Load all StockLevel records from the StockLevel port to identify items with high stock or near minimum level", "Join aggregated sales data with stock levels by matching stockItemId to menuItemId where possible", "Apply rule aiConsumesDomainData: build promo suggestions exclusively from domain data (Order, OrderItem, StockLevel) — no external sources", "For each menuItemId with sufficient sales volume, compute a suggestion score: higher when sales volume is high AND current stock quantity is high relative to minimum level (surplus stock to move via promo)", "Sort suggestions by score descending and return top suggestions with menuItemId, totalQuantitySold, averageUnitPrice, currentStockQuantity, suggestionScore, and a human-readable rationale", "Append a StockConsumption audit event through the StockConsumption port recording that promo suggestions were requested (actorId, windowStart, windowEnd, suggestionCount) — this is a read-only audit trail, no mutation to Order or StockLevel aggregates"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default requestAiPromoSuggestionsUsecase;
    export const pipeline: readonly [{
        readonly id: "requestAiPromoSuggestions__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.defs" {
    export const requestAiSalesSummaryUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "requestAiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "requestAiSalesSummary";
            readonly ports: readonly ["Order", "Shift", "StockLevel", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "requestAiSalesSummary";
                readonly inputTypeName: "RequestAiSalesSummaryInput";
                readonly outputTypeName: "RequestAiSalesSummaryOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "ID do turno atualmente aberto usado como filtro";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "orders";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Lista de pedidos do turno corrente com orderId, status, orderType, createdAt, deliveredAt";
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "topSellers";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Itens mais vendidos calculados a partir dos pedidos do dia corrente (menuItemId, totalQuantity, totalRevenue)";
                    readonly ofEntity: "OrderItem";
                }, {
                    readonly name: "stockLevels";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Níveis de estoque atuais para o resumo de IA (stockItemId, currentQuantity, minimumLevel, unit)";
                    readonly ofEntity: "StockLevel";
                }, {
                    readonly name: "summaryText";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Resumo textual consolidado para consumo do assistente IA";
                }];
                readonly ports: readonly ["Order", "Shift", "StockLevel"];
                readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "aiConsumesDomainData", "topSellersFromDayOrders"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver actorId a partir de ctx.sessionContext.actorId (source=actorSession). Se ausente, lançar erro de autorização.", "2. Consultar a porta Shift para obter o único Shift com status='open' (rule dashboardCurrentShiftOnly). Se não houver turno aberto, lançar erro 'Nenhum turno aberto encontrado'. Extrair shiftId do turno aberto — este valor NÃO é entrada do usuário, é resolvido internamente (source=activeLifecycleInstance).", "3. Consultar a porta Order filtrando por shiftId=shiftId obtido no passo 2, retornando orderId, status, orderType, createdAt, deliveredAt para todos os pedidos do turno corrente.", "4. Para cada pedido retornado, coletar os OrderItem associados (via orderId) e agregar por menuItemId somando quantity e calculando receita total (quantity * unitPrice) para produzir topSellers (rule topSellersFromDayOrders).", "5. Consultar a porta StockLevel para obter todos os níveis de estoque atuais (stockItemId, currentQuantity, minimumLevel, unit).", "6. Consolidar orders, topSellers e stockLevels em um resumo estruturado (summaryText) que o assistente IA consome — apenas dados agregados de pedidos e estoque do domínio, sem fontes externas (rule aiConsumesDomainData).", "7. Retornar shiftId, orders, topSellers, stockLevels e summaryText. Não permitir consulta de períodos históricos ou múltiplos turnos (rule dashboardCurrentShiftOnly)."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default requestAiSalesSummaryUsecase;
    export const pipeline: readonly [{
        readonly id: "requestAiSalesSummary__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs" {
    export const updateOrderStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderStatus";
            readonly ports: readonly ["Order", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "updateOrderStatus";
                readonly inputTypeName: "UpdateOrderStatusInput";
                readonly outputTypeName: "UpdateOrderStatusOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Pedido selecionado pelo cozinheiro na fila da cozinha";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Novo status que o cozinheiro deseja atribuir ao pedido (inPreparation ou ready)";
                }, {
                    readonly name: "inPreparationAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp definido quando o status passa a inPreparation (resolvido via ctx.clock.now quando aplicável)";
                }, {
                    readonly name: "readyAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp definido quando o status passa a ready (resolvido via ctx.clock.now quando aplicável)";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID do pedido atualizado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Status final do pedido após a atualização";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp da última atualização do registro";
                }];
                readonly ports: readonly ["Order", "Shift", "StockConsumption"];
                readonly rulesApplied: readonly ["orderStatusFlow", "inProgressBeforeReady"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolver o turno ativo consultando o port Shift por status='open' para obter shiftId (activeLifecycleInstance)", "2. Carregar o Order pelo orderId informado via port Order", "3. Validar que order.shiftId === activeShift.shiftId — o pedido deve pertencer ao turno atualmente aberto", "4. Aplicar regra orderStatusFlow: o fluxo deve seguir received → inPreparation → ready sem pulos. Se o novo status for 'inPreparation', o status atual deve ser 'received'; se for 'ready', o status atual deve ser 'inPreparation'", "5. Aplicar regra inProgressBeforeReady: o pedido só pode ser marcado como 'ready' se o status atual for 'inPreparation'", "6. Definir timestamps: inPreparationAt = ctx.clock.now() quando status transita para 'inPreparation'; readyAt = ctx.clock.now() quando status transita para 'ready'; updatedAt = ctx.clock.now() em toda alteração", "7. Atualizar o Order com novo status e timestamps via port Order dentro da mesma transação", "8. Emitir evento de auditoria StockConsumption via port StockConsumption dentro da mesma transação (append-only)", "9. Retornar orderId, status e updatedAt do pedido atualizado"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateOrderStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.defs" {
    export const viewDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewDashboard";
            readonly ports: readonly ["Order", "StockLevel", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "viewDashboard";
                readonly inputTypeName: "ViewDashboardInput";
                readonly outputTypeName: "ViewDashboardOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "ID do turno atualmente aberto usado para filtrar os dados";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total de vendas do turno atual somando todos os pedidos";
                }, {
                    readonly name: "orders";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Lista de pedidos do turno atual com status, tipo, data de criação e data de entrega";
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "topSellers";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Itens mais vendidos calculados a partir dos OrderItem dos pedidos do turno atual";
                }, {
                    readonly name: "lowStockAlerts";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Alertas de estoque baixo para itens cujo StockLevel está abaixo do mínimo";
                    readonly ofEntity: "StockLevel";
                }];
                readonly ports: readonly ["Order", "StockLevel", "Shift"];
                readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "topSellersFromDayOrders"];
                readonly transactional: false;
                readonly steps: readonly ["1. Extrair actorId de ctx.sessionContext.actorId para autorização do gerente", "2. Consultar a porta Shift para localizar o único Shift com status='open' (regra dashboardCurrentShiftOnly); se nenhum turno aberto existir, retornar erro de validação", "3. Usar o shiftId do turno aberto para filtrar todos os pedidos via porta Order (listar pedidos cujo shiftId corresponda ao turno atual)", "4. Calcular totalSales somando o valor de todos os pedidos do turno atual", "5. Para cada pedido do turno, coletar os OrderItem e agregar por menuItemId somando quantity (regra topSellersFromDayOrders); ordenar por quantidade descendente para obter topSellers", "6. Consultar a porta StockLevel para todos os itens de estoque e filtrar aqueles cujo currentQuantity < minimumLevel para compor lowStockAlerts", "7. Montar e retornar o objeto de dashboard com shiftId, totalSales, orders, topSellers e lowStockAlerts"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.defs" {
    export const viewKitchenBoardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewKitchenBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewKitchenBoard";
            readonly ports: readonly ["Order", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "viewKitchenBoard";
                readonly inputTypeName: "ViewKitchenBoardInput";
                readonly outputTypeName: "ViewKitchenBoardOutput";
                readonly input: readonly [{
                    readonly name: "statusFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Optional override for status filter; defaults to ['received','inPreparation'] resolved by systemDefault";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "priority";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "priorityReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "receivedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "inPreparationAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "OrderItem";
                    readonly description: "Order items belonging to each order in the kitchen board";
                }];
                readonly ports: readonly ["Order"];
                readonly rulesApplied: readonly ["fifoKitchenQueue", "dashboardCurrentShiftOnly"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve shiftId from the active lifecycle instance (the single Shift with status='open') via ctx.sessionContext.activeLifecycleInstanceId; do NOT require it as user input", "2. Determine statusFilter: use the provided optional input if supplied, otherwise default to ['received','inPreparation'] per systemDefault", "3. Apply rule dashboardCurrentShiftOnly: query Order port for all orders where shiftId equals the resolved open shift id AND status is in the statusFilter set", "4. Apply rule fifoKitchenQueue: sort results with priority=true orders first, then by receivedAt ascending (oldest first) to maintain FIFO kitchen queue order", "5. For each order, load its embedded OrderItem collection from the parent Order aggregate", "6. Project each order with orderId, status, orderType, tableNumber (when applicable), priority, priorityReason, receivedAt, inPreparationAt, createdAt, and its items array", "7. Return the ordered list; orders with status 'ready' or 'delivered' are excluded by the status filter"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewKitchenBoardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewKitchenBoard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.defs" {
    export const viewOrderBoardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewOrderBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewOrderBoard";
            readonly ports: readonly ["Order", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "viewOrderBoard";
                readonly inputTypeName: "ViewOrderBoardInput";
                readonly outputTypeName: "OrderBoardItem";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Shift";
                    readonly description: "ID do turno atualmente aberto. Resolvido pelo backend consultando a Shift com status 'open' quando não informado pelo chamador (activeLifecycleInstance).";
                }, {
                    readonly name: "limit";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Limite opcional de pedidos retornados (paginação).";
                }, {
                    readonly name: "offset";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Deslocamento opcional para paginação.";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identificador único do pedido.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Status atual do pedido: registered, received, inPreparation, ready ou delivered.";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Tipo do pedido: table ou takeout.";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Número da mesa quando orderType = table.";
                }, {
                    readonly name: "priority";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Indicador de priorização do pedido no painel.";
                }, {
                    readonly name: "priorityReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Motivo da priorização quando priority = true.";
                }, {
                    readonly name: "receivedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp de recebimento do pedido.";
                }, {
                    readonly name: "inPreparationAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp de início da preparação.";
                }, {
                    readonly name: "readyAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp de pronto para entrega.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp de criação do pedido — usado para ordenação FIFO.";
                }];
                readonly ports: readonly ["Order", "Shift"];
                readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "fifoKitchenQueue", "orderStatusFlow"];
                readonly transactional: false;
                readonly steps: readonly ["Resolver shiftId: se informado pelo chamador, usar diretamente; caso contrário, consultar a porta Shift pelo único registro com status 'open' (regra dashboardCurrentShiftOnly).", "Validar regra dashboardCurrentShiftOnly: se nenhuma Shift com status 'open' for encontrada, lançar erro indicando que não há turno ativo e o painel não pode ser exibido.", "Consultar a porta Order filtrando todos os pedidos cujo shiftId corresponda ao turno resolvido no passo anterior.", "Aplicar regra fifoKitchenQueue: ordenar a lista de pedidos por createdAt em ordem crescente (FIFO — primeiro a entrar, primeiro a ser exibido).", "Aplicar regra orderStatusFlow: validar que cada pedido possui status dentro do conjunto permitido {registered, received, inPreparation, ready, delivered}; pedidos em status inválido são filtrados e registrados como anomalia.", "Projetar cada pedido para os campos do painel: orderId, status, orderType, tableNumber, priority, priorityReason, receivedAt, inPreparationAt, readyAt, createdAt.", "Aplicar paginação opcional (limit/offset) se fornecida, após a ordenação FIFO.", "Retornar a lista ordenada de OrderBoardItem representando o painel da cozinha."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewOrderBoardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewOrderBoard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.defs" {
    export const viewShiftClosingReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewShiftClosingReport";
            readonly ports: readonly ["ShiftClosingReport", "Shift"];
            readonly functions: readonly [{
                readonly functionName: "viewShiftClosingReport";
                readonly inputTypeName: "ViewShiftClosingReportInput";
                readonly outputTypeName: "ViewShiftClosingReportOutput";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Identificador do turno fechado cujo relatório de fechamento será exibido.";
                }];
                readonly output: readonly [{
                    readonly name: "shiftClosingReportId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Identificador único do relatório de fechamento.";
                }, {
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Identificador do turno ao qual o relatório pertence.";
                }, {
                    readonly name: "totalApurado";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Total apurado do turno para conferência do gerente.";
                }, {
                    readonly name: "paidOrderCount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Quantidade de pedidos pagos consolidados no período do turno.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Data e hora de criação do relatório.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Data e hora da última atualização do relatório.";
                }];
                readonly ports: readonly ["ShiftClosingReport", "Shift"];
                readonly rulesApplied: readonly ["shiftClosingRecordsRevenue", "shiftClosingConsolidatesPaidOrders"];
                readonly transactional: false;
                readonly steps: readonly ["1. Load the ShiftClosingReport from the ShiftClosingReport port using shiftId as the lookup key (getById on ShiftClosingReport.shiftId).", "2. If no ShiftClosingReport is found for the given shiftId, throw a NOT_FOUND error indicating that no closing report exists for the specified shift.", "3. Load the Shift from the Shift port using the same shiftId to verify the shift exists and is in 'closed' status.", "4. If the Shift is not found or its status is not 'closed', throw a VALIDATION error indicating the shift must be closed before its closing report can be viewed.", "5. Apply rule 'shiftClosingRecordsRevenue': verify that the report.totalApurado is consistent with the shift's recorded revenue (shift.totalApurado). If they diverge, include a warning detail in the response metadata but still return the report data — the rule is an assertion of data integrity, not a blocking condition for a view operation.", "6. Apply rule 'shiftClosingConsolidatesPaidOrders': verify that report.paidOrderCount is a non-negative integer representing only paid orders consolidated within the shift period. If the value is negative or non-integer, throw a DATA_INTEGRITY error referencing the rule id.", "7. Return the ShiftClosingReport fields: shiftClosingReportId, shiftId, totalApurado, paidOrderCount, createdAt, updatedAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewShiftClosingReportUsecase;
    export const pipeline: readonly [{
        readonly id: "viewShiftClosingReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.defs" {
    export const menuItemIngredientDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "MenuItemIngredient";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItemIngredient";
            readonly fields: readonly [{
                readonly fieldId: "menuItemIngredientId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do vínculo entre item de cardápio e ingrediente de estoque.";
            }, {
                readonly fieldId: "menuItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de cardápio ao qual este ingrediente está vinculado.";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de estoque master consumido quando o item de cardápio é pedido.";
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade do ingrediente consumida a cada pedido do item de cardápio.";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida da quantidade consumida do ingrediente.";
                readonly enum: readonly ["kg", "gram", "liter", "milliliter", "portion", "unit"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do vínculo de ingrediente.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do vínculo de ingrediente.";
            }];
            readonly statusEnum: readonly [];
            readonly valueObjects: readonly [];
            readonly invariants: readonly ["quantity deve ser maior que zero", "A unidade do vínculo deve ser compatível com a unidade do item de estoque referenciado", "Não pode haver mais de um vínculo entre o mesmo menuItemId e stockItemId"];
        };
    };
    export default menuItemIngredientDomainEntity;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredient__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido";
            }, {
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Turno aberto no momento do lançamento do pedido";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do pedido no fluxo de acompanhamento";
                readonly enum: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
            }, {
                readonly fieldId: "orderType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo do pedido: consumo na mesa ou para viagem";
                readonly enum: readonly ["table", "takeout"];
            }, {
                readonly fieldId: "tableNumber";
                readonly type: "string";
                readonly required: false;
                readonly description: "Número da mesa quando o pedido é do tipo mesa";
            }, {
                readonly fieldId: "priority";
                readonly type: "boolean";
                readonly required: false;
                readonly description: "Indica se o pedido recebeu priorização no preparo fora da ordem de chegada";
            }, {
                readonly fieldId: "priorityReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Justificativa para a priorização do pedido fora da ordem de chegada";
            }, {
                readonly fieldId: "receivedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o pedido foi recebido pela cozinha";
            }, {
                readonly fieldId: "inPreparationAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o cozinheiro iniciou o preparo do pedido";
            }, {
                readonly fieldId: "readyAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o pedido foi marcado como pronto pela cozinha";
            }, {
                readonly fieldId: "deliveredAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o pedido foi entregue ao cliente";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Momento de criação do registro do pedido";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Momento da última atualização do registro do pedido";
            }];
            readonly statusEnum: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
            readonly valueObjects: readonly [{
                readonly name: "OrderItem";
                readonly fields: readonly [{
                    readonly fieldId: "orderItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único da linha do pedido.";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido ao qual esta linha pertence.";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio cadastrado que foi solicitado.";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade solicitada do item do cardápio nesta linha do pedido.";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário do item no momento do lançamento do pedido, snapshot para fins de fechamento.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora em que a linha do pedido foi criada.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização da linha do pedido.";
                }];
                readonly collection: true;
            }];
            readonly invariants: readonly ["tableNumber is required when orderType is 'table'", "tableNumber must be null when orderType is 'takeout'", "priorityReason is required when priority is true", "Status transitions must follow the sequence: registered → received → inPreparation → ready → delivered", "receivedAt must be set when status is 'received' or beyond", "inPreparationAt must be set when status is 'inPreparation' or beyond", "readyAt must be set when status is 'ready' or beyond", "deliveredAt must be set when status is 'delivered'", "Order must belong to an open shift at creation time", "Each OrderItem quantity must be greater than zero", "Each OrderItem unitPrice must be greater than or equal to zero", "Order must have at least one OrderItem"];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/order.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.defs" {
    export const shiftDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Shift";
            readonly fields: readonly [{
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do turno";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do turno";
                readonly enum: readonly ["open", "closed"];
            }, {
                readonly fieldId: "openedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de abertura do turno pelo gerente";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora de fechamento do turno";
            }, {
                readonly fieldId: "openedBy";
                readonly type: "string";
                readonly required: true;
                readonly description: "Identificador do gerente que abriu o turno";
            }, {
                readonly fieldId: "closedBy";
                readonly type: "string";
                readonly required: false;
                readonly description: "Identificador do gerente que fechou o turno";
            }, {
                readonly fieldId: "totalApurado";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor total apurado no fechamento do turno para conferência, sem conciliação bancária";
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações gerais sobre o turno";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["open", "closed"];
            readonly valueObjects: readonly [];
            readonly invariants: readonly ["closedAt is required when status is 'closed'", "closedBy is required when status is 'closed'", "totalApurado is required when status is 'closed'", "closedAt must be after openedAt", "Only one shift may be open at a time", "A closed shift cannot be reopened"];
        };
    };
    export default shiftDomainEntity;
    export const pipeline: readonly [{
        readonly id: "shift__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.defs" {
    export const shiftClosingReportDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "ShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftClosingReport";
            readonly fields: readonly [{
                readonly fieldId: "shiftClosingReportId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do relatório de fechamento de turno.";
            }, {
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao turno fechado ao qual este relatório corresponde.";
            }, {
                readonly fieldId: "totalApurado";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total apurado no fechamento do turno para conferência do gerente.";
            }, {
                readonly fieldId: "paidOrderCount";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade de pedidos pagos consolidados no período do turno.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora em que o relatório de fechamento foi gerado.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do relatório de fechamento.";
            }];
            readonly statusEnum: readonly [];
            readonly valueObjects: readonly [];
            readonly invariants: readonly ["shiftId must reference a shift whose status is 'closed'", "totalApurado must be greater than or equal to zero", "paidOrderCount must be greater than or equal to zero", "There is at most one ShiftClosingReport per shiftId"];
        };
    };
    export default shiftClosingReportDomainEntity;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReport__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.defs" {
    export const stockAdjustmentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockAdjustment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockAdjustment";
            readonly fields: readonly [{
                readonly fieldId: "stockAdjustmentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do ajuste de estoque.";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Item de estoque ao qual o ajuste se aplica.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação do ajuste: lançado ou anulado.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade ajustada, positiva para reposição e negativa para correção ou baixa.";
            }, {
                readonly fieldId: "reason";
                readonly type: "text";
                readonly required: true;
                readonly description: "Motivo do ajuste informado pelo gerente ao registrar a reposição ou correção.";
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o ajuste foi anulado.";
            }, {
                readonly fieldId: "voidedReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo da anulação do ajuste de estoque.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro do ajuste.";
            }];
            readonly statusEnum: readonly ["posted", "voided"];
            readonly valueObjects: readonly [];
            readonly invariants: readonly [];
        };
    };
    export default stockAdjustmentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockAdjustment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.defs" {
    export const stockConsumptionDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockConsumption";
            readonly fields: readonly [{
                readonly fieldId: "stockConsumptionId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do consumo de estoque.";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Item de estoque cuja quantidade foi decrementada por este consumo.";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Pedido que disparou este consumo de estoque no momento do lançamento.";
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade do item de estoque consumida e decrementada neste lançamento.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação do consumo: lançado ou estornado.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora do registro do consumo de estoque.";
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o consumo foi estornado, quando aplicável.";
            }, {
                readonly fieldId: "voidReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do estorno do consumo de estoque.";
            }];
            readonly statusEnum: readonly ["posted", "voided"];
            readonly valueObjects: readonly [];
            readonly invariants: readonly [];
        };
    };
    export default stockConsumptionDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockConsumption__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.defs" {
    export const stockLevelDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockLevel";
            readonly fields: readonly [{
                readonly fieldId: "stockLevelId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do nível de estoque";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de estoque master ao qual este nível pertence";
            }, {
                readonly fieldId: "currentQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade atual disponível em estoque, decrementada por consumos e ajustada por reposições";
            }, {
                readonly fieldId: "minimumLevel";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida do estoque do ingrediente";
                readonly enum: readonly ["kg", "liter", "portion", "unit"];
            }, {
                readonly fieldId: "lastDecrementAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do último decremento de estoque por lançamento de pedido";
            }, {
                readonly fieldId: "lastAdjustmentAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do último ajuste manual de reposição de estoque";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro de nível de estoque";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do nível de estoque";
            }];
            readonly statusEnum: readonly [];
            readonly valueObjects: readonly [];
            readonly invariants: readonly ["currentQuantity must be greater than or equal to zero", "minimumLevel must be greater than or equal to zero", "Low-stock alert is triggered when currentQuantity is less than or equal to minimumLevel", "There is exactly one StockLevel per stockItemId"];
        };
    };
    export default stockLevelDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockLevel__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102051_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.defs" {
    export const definition: ({
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: any[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    } | {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        }[];
        output: any[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    })[];
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/kitchenQueue" {
    export interface CafeFlowViewKitchenBoardInput {
    }
    export interface CafeFlowViewKitchenBoardOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        priority: boolean;
        priorityReason: string;
        receivedAt: string;
        inPreparationAt: string;
        createdAt: string;
    }
    export interface CafeFlowViewKitchenBoardOutput {
        items: CafeFlowViewKitchenBoardOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowUpdateOrderStatusInput {
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
    }
    export interface CafeFlowUpdateOrderStatusOutput {
    }
}
declare module "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/managerDashboard.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: any[];
        output: ({
            name: string;
            type: string;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "managerDashboard__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/managerDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/managerDashboard.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/managerDashboard" {
    export interface CafeFlowViewDashboardInput {
    }
    export interface CafeFlowViewDashboardOutputItem {
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        createdAt: string;
        shiftId: string;
        deliveredAt: string;
    }
    export type CafeFlowViewDashboardOutput = CafeFlowViewDashboardOutputItem[];
    export interface CafeFlowRequestAiSalesSummaryInput {
    }
    export interface CafeFlowRequestAiSalesSummaryOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        createdAt: string;
        deliveredAt: string;
    }
    export type CafeFlowRequestAiSalesSummaryOutput = CafeFlowRequestAiSalesSummaryOutputItem[];
    export interface CafeFlowRequestAiPromoSuggestionsInput {
    }
    export interface CafeFlowRequestAiPromoSuggestionsOutputItem {
        orderId: string;
        orderType: "table" | "takeout";
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        createdAt: string;
    }
    export type CafeFlowRequestAiPromoSuggestionsOutput = CafeFlowRequestAiPromoSuggestionsOutputItem[];
}
declare module "_102051_/l2/cafeFlow/web/contracts/managerDashboard.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/menuManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "menuManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/menuManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/menuManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/menuManagement" {
    export interface CafeFlowBrowseMenuItemsInput {
        statusFilter?: "draft" | "active" | "inactive";
        menuCategoryIdFilter?: string;
    }
    export interface CafeFlowBrowseMenuItemsOutputItem {
        menuItemId: string;
        name: string;
        description: string;
        menuCategoryId: string;
        price: number;
        itemType: "simple" | "variant";
        status: "draft" | "active" | "inactive";
        activatedAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface CafeFlowBrowseMenuItemsOutput {
        items: CafeFlowBrowseMenuItemsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowManageMenuItemInput {
        name: string;
        description?: string;
        menuCategoryId: string;
        price: number;
        itemType: "simple" | "variant";
        status: "draft" | "active" | "inactive";
    }
    export interface CafeFlowManageMenuItemOutput {
        menuItemId: string;
        name: string;
        description: string;
        menuCategoryId: string;
        price: number;
        itemType: "simple" | "variant";
        status: "draft" | "active" | "inactive";
        activatedAt: string;
        inactivatedAt: string;
        updatedAt: string;
    }
}
declare module "_102051_/l2/cafeFlow/web/contracts/menuManagement.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/posOrder.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "posOrder__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/posOrder.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/posOrder.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/posOrder" {
    export interface CafeFlowCreateOrderInput {
        orderType: "table" | "takeout";
        tableNumber?: string;
        priority?: boolean;
        priorityReason?: string;
    }
    export interface CafeFlowCreateOrderOutput {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        createdAt: string;
    }
    export interface CafeFlowViewOrderBoardInput {
        statusFilter?: "registered" | "received" | "inPreparation" | "ready" | "delivered";
    }
    export interface CafeFlowViewOrderBoardOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        priority: boolean;
        priorityReason: string;
        receivedAt: string;
        inPreparationAt: string;
        readyAt: string;
        createdAt: string;
    }
    export interface CafeFlowViewOrderBoardOutput {
        items: CafeFlowViewOrderBoardOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowDeliverOrderInput {
    }
    export interface CafeFlowDeliverOrderOutput {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        deliveredAt: string;
        orderType: "table" | "takeout";
        tableNumber: string;
    }
}
declare module "_102051_/l2/cafeFlow/web/contracts/posOrder.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/posWorkspace.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "posWorkspace__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/posWorkspace.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/posWorkspace.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/posWorkspace" {
    export interface CafeFlowCreateOrderInput {
        orderType: "table" | "takeout";
        tableNumber?: string;
        orderItems: string;
        priority?: boolean;
        priorityReason?: string;
    }
    export interface CafeFlowCreateOrderOutput {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        createdAt: string;
    }
    export interface CafeFlowViewOrderBoardInput {
    }
    export interface CafeFlowViewOrderBoardOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        priority: boolean;
        priorityReason: string;
        receivedAt: string;
        inPreparationAt: string;
        readyAt: string;
        createdAt: string;
    }
    export interface CafeFlowViewOrderBoardOutput {
        items: CafeFlowViewOrderBoardOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowDeliverOrderInput {
    }
    export interface CafeFlowDeliverOrderOutput {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        deliveredAt: string;
        updatedAt: string;
    }
}
declare module "_102051_/l2/cafeFlow/web/contracts/posWorkspace.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/salesDashboard.defs" {
    export const definition: ({
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: any[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
            required?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
            required?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            description?: undefined;
            enum?: undefined;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    } | {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    })[];
    export const pipeline: readonly [{
        readonly id: "salesDashboard__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/salesDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/salesDashboard.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/salesDashboard" {
    export interface CafeFlowViewDashboardInput {
    }
    export interface CafeFlowViewDashboardOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        createdAt: string;
        shiftId: string;
        menuItemId: string;
        quantity: number;
        stockItemId: string;
        currentQuantity: number;
        minimumQuantity?: string;
    }
    export type CafeFlowViewDashboardOutput = CafeFlowViewDashboardOutputItem[];
    export interface CafeFlowRequestAiSalesSummaryInput {
        summaryRequest: string;
    }
    export interface CafeFlowRequestAiSalesSummaryOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        createdAt: string;
        deliveredAt: string;
    }
    export type CafeFlowRequestAiSalesSummaryOutput = CafeFlowRequestAiSalesSummaryOutputItem[];
    export interface CafeFlowRequestAiPromoSuggestionsInput {
    }
    export interface CafeFlowRequestAiPromoSuggestionsOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        createdAt: string;
        quantity: number;
        menuItemId: string;
        name: string;
    }
    export type CafeFlowRequestAiPromoSuggestionsOutput = CafeFlowRequestAiPromoSuggestionsOutputItem[];
}
declare module "_102051_/l2/cafeFlow/web/contracts/salesDashboard.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/shiftManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/shiftManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/shiftManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/shiftManagement" {
    export interface CafeFlowOpenShiftInput {
        notes?: string;
    }
    export interface CafeFlowOpenShiftOutput {
        shiftId: string;
        status: "open" | "closed";
        openedAt: string;
        openedBy: string;
    }
    export interface CafeFlowCloseShiftInput {
        totalApurado: number;
        notes?: string;
    }
    export interface CafeFlowCloseShiftOutput {
        status: "open" | "closed";
        closedAt: string;
        closedBy: string;
        totalApurado: number;
        notes: string;
    }
    export interface CafeFlowViewShiftClosingReportInput {
    }
    export interface CafeFlowViewShiftClosingReportOutputItem {
        shiftClosingReportId: string;
        shiftId: string;
        totalApurado: number;
        paidOrderCount: number;
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowViewShiftClosingReportOutput = CafeFlowViewShiftClosingReportOutputItem;
}
declare module "_102051_/l2/cafeFlow/web/contracts/shiftManagement.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/stockManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "stockManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/stockManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/stockManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/stockManagement" {
    export interface CafeFlowBrowseStockItemsInput {
        searchTerm?: string;
    }
    export interface CafeFlowBrowseStockItemsOutputItem {
        stockItemId: string;
        name: string;
        unit: "kg" | "liter" | "portion" | "unit";
        minimumLevel: number;
        createdAt: string;
        updatedAt: string;
    }
    export interface CafeFlowBrowseStockItemsOutput {
        items: CafeFlowBrowseStockItemsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowManageStockItemInput {
        name: string;
        unit: "kg" | "liter" | "portion" | "unit";
        minimumLevel: number;
    }
    export interface CafeFlowManageStockItemOutput {
        stockItemId: string;
        name: string;
        unit: "kg" | "liter" | "portion" | "unit";
        minimumLevel: number;
        updatedAt: string;
    }
}
declare module "_102051_/l2/cafeFlow/web/contracts/stockManagement.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                    stateKey?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        source?: undefined;
                        binding?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        source?: undefined;
                        binding?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/kitchenQueue.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/kitchenQueue.defs.ts", "_102051_/l2/cafeFlow/web/shared/kitchenQueue.ts", "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.defs.ts", "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/kitchenQueue" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewKitchenBoardOutput } from "_102051_/l2/cafeFlow/web/contracts/kitchenQueue";
    const message_pt: {
        "kitchenQueue.section.title": string;
        "kitchenQueue.viewKitchenBoard.title": string;
        "kitchenQueue.viewKitchenBoard.list.title": string;
        "kitchenQueue.updateOrderStatus.title": string;
        "kitchenQueue.updateOrderStatus.form.title": string;
        "kitchenQueue.summary.title": string;
        "kitchenQueue.field.orderId": string;
        "kitchenQueue.field.status": string;
        "kitchenQueue.field.orderType": string;
        "kitchenQueue.field.tableNumber": string;
        "kitchenQueue.field.priority": string;
        "kitchenQueue.field.priorityReason": string;
        "kitchenQueue.field.receivedAt": string;
        "kitchenQueue.field.inPreparationAt": string;
        "kitchenQueue.field.createdAt": string;
        "kitchenQueue.action.refreshBoard": string;
        "kitchenQueue.action.updateStatus": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowKitchenQueueBase extends CollabLitElement {
        status: string;
        viewKitchenBoardState: "idle" | "loading" | "success" | "error";
        viewKitchenBoardData: CafeFlowViewKitchenBoardOutput;
        updateOrderStatusState: "idle" | "loading" | "success" | "error";
        updateOrderStatusStatus: "registered" | "received" | "inPreparation" | "ready" | "delivered" | "";
        LayoutSumOrderId: string;
        LayoutSumOrderType: string;
        LayoutSumTableNumber: string;
        LayoutSumPriority: string;
        LayoutSumPriorityReason: string;
        LayoutSumReceivedAt: string;
        LayoutSumInPreparationAt: string;
        protected get msg(): MessageType;
        setUpdateOrderStatusStatus(value: "registered" | "received" | "inPreparation" | "ready" | "delivered" | ""): void;
        handleUpdateOrderStatusStatusChange(e: Event): void;
        loadViewKitchenBoard(): Promise<void>;
        handleViewKitchenBoardClick(_e: Event): void;
        updateOrderStatus(): Promise<void>;
        handleUpdateOrderStatusClick(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/kitchenQueue" {
    import { CafeFlowKitchenQueueBase } from "_102051_/l2/cafeFlow/web/shared/kitchenQueue";
    export class CafeFlowDesktopPage11KitchenQueuePage extends CafeFlowKitchenQueueBase {
        render(): any;
        private _statusBadgeClass;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    })[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            description: string;
            stateKey: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/managerDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/managerDashboard.defs.ts", "_102051_/l2/cafeFlow/web/shared/managerDashboard.ts", "_102051_/l2/cafeFlow/web/contracts/managerDashboard.defs.ts", "_102051_/l2/cafeFlow/web/contracts/managerDashboard.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/managerDashboard" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewDashboardOutput, CafeFlowRequestAiSalesSummaryOutput, CafeFlowRequestAiPromoSuggestionsOutput } from "_102051_/l2/cafeFlow/web/contracts/managerDashboard";
    const message_pt: {
        "managerDashboard.section.dashboard.title": string;
        "managerDashboard.organism.viewDashboard.title": string;
        "managerDashboard.organism.requestAiSalesSummary.title": string;
        "managerDashboard.organism.requestAiPromoSuggestions.title": string;
        "managerDashboard.intention.viewDashboard.list.title": string;
        "managerDashboard.intention.requestAiSalesSummary.list.title": string;
        "managerDashboard.intention.requestAiPromoSuggestions.list.title": string;
        "managerDashboard.field.status": string;
        "managerDashboard.field.orderType": string;
        "managerDashboard.field.createdAt": string;
        "managerDashboard.field.shiftId": string;
        "managerDashboard.field.deliveredAt": string;
        "managerDashboard.field.orderId": string;
        "managerDashboard.action.viewDashboard": string;
        "managerDashboard.action.requestAiSalesSummary": string;
        "managerDashboard.action.requestAiPromoSuggestions": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowManagerDashboardBase extends CollabLitElement {
        status: string;
        viewDashboardState: 'idle' | 'loading' | 'success' | 'error';
        viewDashboardData: CafeFlowViewDashboardOutput;
        requestAiSalesSummaryState: 'idle' | 'loading' | 'success' | 'error';
        requestAiSalesSummaryData: CafeFlowRequestAiSalesSummaryOutput;
        requestAiPromoSuggestionsState: 'idle' | 'loading' | 'success' | 'error';
        requestAiPromoSuggestionsData: CafeFlowRequestAiPromoSuggestionsOutput;
        private subscribedKeys;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadViewDashboard(): Promise<void>;
        handleViewDashboardClick(_e: Event): void;
        loadRequestAiSalesSummary(): Promise<void>;
        handleRequestAiSalesSummaryClick(_e: Event): void;
        loadRequestAiPromoSuggestions(): Promise<void>;
        handleRequestAiPromoSuggestionsClick(_e: Event): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/managerDashboard" {
    import { type TemplateResult } from 'lit';
    import { CafeFlowManagerDashboardBase } from "_102051_/l2/cafeFlow/web/shared/managerDashboard";
    export class CafeFlowDesktopPage11ManagerDashboardPage extends CafeFlowManagerDashboardBase {
        render(): TemplateResult;
        private renderViewDashboard;
        private renderRequestAiSalesSummary;
        private renderRequestAiPromoSuggestions;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                })[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                })[];
            }[];
        })[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        source?: undefined;
                        binding?: undefined;
                        action?: undefined;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    })[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        binding?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/menuManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/menuManagement.defs.ts", "_102051_/l2/cafeFlow/web/shared/menuManagement.ts", "_102051_/l2/cafeFlow/web/contracts/menuManagement.defs.ts", "_102051_/l2/cafeFlow/web/contracts/menuManagement.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/menuManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowBrowseMenuItemsOutput } from "_102051_/l2/cafeFlow/web/contracts/menuManagement";
    const message_pt: {
        "menuManagement.section.main.title": string;
        "menuManagement.organism.browseMenuItems.title": string;
        "menuManagement.organism.manageMenuItem.title": string;
        "menuManagement.intention.context.title": string;
        "menuManagement.intention.browseMenuItems.list.title": string;
        "menuManagement.intention.manageMenuItem.form.title": string;
        "menuManagement.intention.manageMenuItem.status.title": string;
        "menuManagement.field.name.label": string;
        "menuManagement.field.description.label": string;
        "menuManagement.field.menuCategoryId.label": string;
        "menuManagement.field.price.label": string;
        "menuManagement.field.itemType.label": string;
        "menuManagement.field.status.label": string;
        "menuManagement.field.updatedAt.label": string;
        "menuManagement.field.activatedAt.label": string;
        "menuManagement.field.inactivatedAt.label": string;
        "menuManagement.filter.statusFilter.label": string;
        "menuManagement.filter.menuCategoryIdFilter.label": string;
        "menuManagement.action.browseMenuItems.label": string;
        "menuManagement.action.manageMenuItem.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowMenuManagementBase extends CollabLitElement {
        status: string;
        browseMenuItemsState: "idle" | "loading" | "success" | "error";
        browseMenuItemsStatusFilter: string;
        browseMenuItemsMenuCategoryIdFilter: string;
        browseMenuItemsData: CafeFlowBrowseMenuItemsOutput;
        manageMenuItemState: "idle" | "loading" | "success" | "error";
        manageMenuItemName: string;
        manageMenuItemDescription: string;
        manageMenuItemMenuCategoryId: string;
        manageMenuItemPrice: string;
        manageMenuItemItemType: string;
        manageMenuItemStatus: string;
        activeCompanyId: string;
        LayoutFieldManageMenuItemActivatedAt: string;
        LayoutFieldManageMenuItemInactivatedAt: string;
        LayoutFieldManageMenuItemUpdatedAt: string;
        private subscribedKeys;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        loadBrowseMenuItems(): Promise<void>;
        handleBrowseMenuItemsClick(_e: Event): void;
        manageMenuItem(): Promise<void>;
        handleManageMenuItemClick(_e: Event): void;
        setBrowseMenuItemsStatusFilter(value: string): void;
        handleBrowseMenuItemsStatusFilterChange(e: Event): void;
        setBrowseMenuItemsMenuCategoryIdFilter(value: string): void;
        handleBrowseMenuItemsMenuCategoryIdFilterChange(e: Event): void;
        setManageMenuItemName(value: string): void;
        handleManageMenuItemNameChange(e: Event): void;
        setManageMenuItemDescription(value: string): void;
        handleManageMenuItemDescriptionChange(e: Event): void;
        setManageMenuItemMenuCategoryId(value: string): void;
        handleManageMenuItemMenuCategoryIdChange(e: Event): void;
        setManageMenuItemPrice(value: string): void;
        handleManageMenuItemPriceChange(e: Event): void;
        setManageMenuItemItemType(value: string): void;
        handleManageMenuItemItemTypeChange(e: Event): void;
        setManageMenuItemStatus(value: string): void;
        handleManageMenuItemStatusChange(e: Event): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/menuManagement" {
    import { CafeFlowMenuManagementBase } from "_102051_/l2/cafeFlow/web/shared/menuManagement";
    export class CafeFlowDesktopPage11MenuManagementPage extends CafeFlowMenuManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/posOrder.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            inputId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                })[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "posOrder__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/posOrder.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/posOrder.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/posOrder.defs.ts", "_102051_/l2/cafeFlow/web/shared/posOrder.ts", "_102051_/l2/cafeFlow/web/contracts/posOrder.defs.ts", "_102051_/l2/cafeFlow/web/contracts/posOrder.ts"];
        readonly dependsOn: readonly ["posOrder__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/posOrder" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewOrderBoardOutput } from "_102051_/l2/cafeFlow/web/contracts/posOrder";
    const message_pt: {
        "posOrder.section.main.title": string;
        "posOrder.organism.createOrder.title": string;
        "posOrder.intent.createOrder.form.title": string;
        "posOrder.intent.createOrder.summary.title": string;
        "posOrder.organism.viewOrderBoard.title": string;
        "posOrder.intent.viewOrderBoard.list.title": string;
        "posOrder.organism.deliverOrder.title": string;
        "posOrder.intent.deliverOrder.confirm.title": string;
        "posOrder.intent.deliverOrder.summary.title": string;
        "posOrder.field.orderType.label": string;
        "posOrder.field.tableNumber.label": string;
        "posOrder.field.priority.label": string;
        "posOrder.field.priorityReason.label": string;
        "posOrder.field.orderId.label": string;
        "posOrder.field.status.label": string;
        "posOrder.field.createdAt.label": string;
        "posOrder.field.receivedAt.label": string;
        "posOrder.field.inPreparationAt.label": string;
        "posOrder.field.readyAt.label": string;
        "posOrder.field.deliveredAt.label": string;
        "posOrder.filter.statusFilter.label": string;
        "posOrder.action.viewOrderBoard.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowPosOrderBase extends CollabLitElement {
        status: string;
        createOrderState: "idle" | "loading" | "success" | "error";
        createOrderOrderType: string;
        createOrderTableNumber: string;
        createOrderPriority: string;
        createOrderPriorityReason: string;
        viewOrderBoardState: "idle" | "loading" | "success" | "error";
        viewOrderBoardStatusFilter: string;
        viewOrderBoardData: CafeFlowViewOrderBoardOutput;
        deliverOrderState: "idle" | "loading" | "success" | "error";
        activeCompanyId: string;
        LayoutFieldCreateOrderOrderId: string;
        LayoutFieldCreateOrderStatus: string;
        LayoutFieldCreateOrderCreatedAt: string;
        LayoutFieldDeliverOrderOrderId: string;
        LayoutFieldDeliverOrderStatus: string;
        LayoutFieldDeliverOrderDeliveredAt: string;
        LayoutFieldDeliverOrderOrderType: string;
        LayoutFieldDeliverOrderTableNumber: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setCreateOrderOrderType(value: string): void;
        handleCreateOrderOrderTypeChange(e: Event): void;
        setCreateOrderTableNumber(value: string): void;
        handleCreateOrderTableNumberChange(e: Event): void;
        setCreateOrderPriority(value: string): void;
        handleCreateOrderPriorityChange(e: Event): void;
        setCreateOrderPriorityReason(value: string): void;
        handleCreateOrderPriorityReasonChange(e: Event): void;
        setViewOrderBoardStatusFilter(value: string): void;
        handleViewOrderBoardStatusFilterChange(e: Event): void;
        loadViewOrderBoard(): Promise<boolean>;
        handleViewOrderBoardClick(): void;
        createOrder(signal?: AbortSignal): Promise<void>;
        handleCreateOrderClick(): void;
        deliverOrder(orderId?: string, signal?: AbortSignal): Promise<void>;
        handleDeliverOrderClick(orderId?: string): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/posOrder" {
    import { CafeFlowPosOrderBase } from "_102051_/l2/cafeFlow/web/shared/posOrder";
    export class CafeFlowDesktopPage11PosOrderPage extends CafeFlowPosOrderBase {
        render(): any;
        private renderCreateOrderOrganism;
        private renderViewOrderBoardOrganism;
        private renderDeliverOrderOrganism;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        })[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        action: string;
                        displayHint: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/posWorkspace.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/posWorkspace.defs.ts", "_102051_/l2/cafeFlow/web/shared/posWorkspace.ts", "_102051_/l2/cafeFlow/web/contracts/posWorkspace.defs.ts", "_102051_/l2/cafeFlow/web/contracts/posWorkspace.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/posWorkspace" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewOrderBoardOutput } from "_102051_/l2/cafeFlow/web/contracts/posWorkspace";
    const message_pt: {
        "posWorkspace.section.main.title": string;
        "posWorkspace.organism.createOrder.title": string;
        "posWorkspace.createOrder.form.title": string;
        "posWorkspace.createOrder.orderType.label": string;
        "posWorkspace.createOrder.tableNumber.label": string;
        "posWorkspace.createOrder.orderItems.label": string;
        "posWorkspace.createOrder.priority.label": string;
        "posWorkspace.createOrder.priorityReason.label": string;
        "posWorkspace.createOrder.review.title": string;
        "posWorkspace.createOrder.submit.label": string;
        "posWorkspace.organism.viewOrderBoard.title": string;
        "posWorkspace.viewOrderBoard.list.title": string;
        "posWorkspace.viewOrderBoard.orderId.label": string;
        "posWorkspace.viewOrderBoard.status.label": string;
        "posWorkspace.viewOrderBoard.orderType.label": string;
        "posWorkspace.viewOrderBoard.tableNumber.label": string;
        "posWorkspace.viewOrderBoard.priority.label": string;
        "posWorkspace.viewOrderBoard.priorityReason.label": string;
        "posWorkspace.viewOrderBoard.receivedAt.label": string;
        "posWorkspace.viewOrderBoard.inPreparationAt.label": string;
        "posWorkspace.viewOrderBoard.readyAt.label": string;
        "posWorkspace.viewOrderBoard.createdAt.label": string;
        "posWorkspace.viewOrderBoard.refresh.label": string;
        "posWorkspace.viewOrderBoard.deliver.label": string;
        "posWorkspace.organism.deliverOrder.title": string;
        "posWorkspace.deliverOrder.confirm.title": string;
        "posWorkspace.deliverOrder.submit.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowPosWorkspaceBase extends CollabLitElement {
        status: string;
        createOrderState: "idle" | "loading" | "success" | "error";
        createOrderOrderType: string;
        createOrderTableNumber: string;
        createOrderOrderItems: string;
        createOrderPriority: string;
        createOrderPriorityReason: string;
        viewOrderBoardState: "idle" | "loading" | "success" | "error";
        viewOrderBoardData: CafeFlowViewOrderBoardOutput;
        deliverOrderState: "idle" | "loading" | "success" | "error";
        protected get msg(): MessageType;
        setCreateOrderOrderType(value: string): void;
        handleCreateOrderOrderTypeChange(e: Event): void;
        setCreateOrderTableNumber(value: string): void;
        handleCreateOrderTableNumberChange(e: Event): void;
        setCreateOrderOrderItems(value: string): void;
        handleCreateOrderOrderItemsChange(e: Event): void;
        setCreateOrderPriority(value: string): void;
        handleCreateOrderPriorityChange(e: Event): void;
        setCreateOrderPriorityReason(value: string): void;
        handleCreateOrderPriorityReasonChange(e: Event): void;
        loadViewOrderBoard(): Promise<void>;
        handleViewOrderBoardClick(e: Event): void;
        createOrder(): Promise<void>;
        handleCreateOrderClick(e: Event): void;
        deliverOrder(): Promise<void>;
        handleDeliverOrderClick(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/posWorkspace" {
    import { type TemplateResult } from 'lit';
    import { CafeFlowPosWorkspaceBase } from "_102051_/l2/cafeFlow/web/shared/posWorkspace";
    export class CafeFlowDesktopPage11PosWorkspacePage extends CafeFlowPosWorkspaceBase {
        render(): TemplateResult;
        private renderCreateOrderOrganism;
        private renderViewOrderBoardOrganism;
        private renderDeliverOrderOrganism;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/salesDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            inputId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    submitAction?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    })[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        submitAction?: undefined;
                    })[];
                })[];
            }[];
        };
        dataBindings: any[];
    };
    export const pipeline: readonly [{
        readonly id: "salesDashboard__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/salesDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/salesDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/salesDashboard.defs.ts", "_102051_/l2/cafeFlow/web/shared/salesDashboard.ts", "_102051_/l2/cafeFlow/web/contracts/salesDashboard.defs.ts", "_102051_/l2/cafeFlow/web/contracts/salesDashboard.ts"];
        readonly dependsOn: readonly ["salesDashboard__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/salesDashboard" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewDashboardOutputItem, CafeFlowRequestAiSalesSummaryOutputItem, CafeFlowRequestAiPromoSuggestionsOutputItem } from "_102051_/l2/cafeFlow/web/contracts/salesDashboard";
    const message_pt: {
        "salesDashboard.section.dashboardAi.title": string;
        "salesDashboard.organism.viewDashboard.title": string;
        "salesDashboard.organism.requestAiSalesSummary.title": string;
        "salesDashboard.organism.requestAiPromoSuggestions.title": string;
        "salesDashboard.intent.dashboard.context.title": string;
        "salesDashboard.intent.dashboard.data.title": string;
        "salesDashboard.intent.dashboard.lowStock.title": string;
        "salesDashboard.intent.aiSales.request.title": string;
        "salesDashboard.intent.aiSales.output.title": string;
        "salesDashboard.intent.aiPromo.request.title": string;
        "salesDashboard.intent.aiPromo.output.title": string;
        "salesDashboard.field.shiftId.label": string;
        "salesDashboard.field.orderId.label": string;
        "salesDashboard.field.status.label": string;
        "salesDashboard.field.orderType.label": string;
        "salesDashboard.field.createdAt.label": string;
        "salesDashboard.field.menuItemId.label": string;
        "salesDashboard.field.quantity.label": string;
        "salesDashboard.field.stockItemId.label": string;
        "salesDashboard.field.currentQuantity.label": string;
        "salesDashboard.field.minimumQuantity.label": string;
        "salesDashboard.field.summaryRequest.label": string;
        "salesDashboard.field.deliveredAt.label": string;
        "salesDashboard.field.menuItemName.label": string;
        "salesDashboard.action.viewDashboard.label": string;
        "salesDashboard.action.requestAiSalesSummary.label": string;
        "salesDashboard.action.requestAiPromoSuggestions.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowSalesDashboardBase extends CollabLitElement {
        status: string;
        viewDashboardState: "idle" | "loading" | "success" | "error";
        viewDashboardData: CafeFlowViewDashboardOutputItem[];
        requestAiSalesSummaryState: "idle" | "loading" | "success" | "error";
        requestAiSalesSummarySummaryRequest: string;
        requestAiSalesSummaryData: CafeFlowRequestAiSalesSummaryOutputItem[];
        requestAiPromoSuggestionsState: "idle" | "loading" | "success" | "error";
        requestAiPromoSuggestionsData: CafeFlowRequestAiPromoSuggestionsOutputItem[];
        activeCompanyId: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        loadViewDashboard(): Promise<void>;
        handleViewDashboardClick(_e: Event): void;
        loadRequestAiSalesSummary(): Promise<void>;
        handleRequestAiSalesSummaryClick(_e: Event): void;
        loadRequestAiPromoSuggestions(): Promise<void>;
        handleRequestAiPromoSuggestionsClick(_e: Event): void;
        setRequestAiSalesSummarySummaryRequest(value: string): void;
        handleRequestAiSalesSummarySummaryRequestChange(e: Event): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/salesDashboard" {
    import { CafeFlowSalesDashboardBase } from "_102051_/l2/cafeFlow/web/shared/salesDashboard";
    export class CafeFlowDesktopPage11SalesDashboardPage extends CafeFlowSalesDashboardBase {
        render(): unknown;
        private renderViewDashboardOrganism;
        private renderAiSalesSummaryOrganism;
        private renderAiPromoSuggestionsOrganism;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        } | {
            id: string;
            source: string;
            description: string;
            stateKey: string;
            entity?: undefined;
            command?: undefined;
            inputStateKeys?: undefined;
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/shiftManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/shiftManagement.defs.ts", "_102051_/l2/cafeFlow/web/shared/shiftManagement.ts", "_102051_/l2/cafeFlow/web/contracts/shiftManagement.defs.ts", "_102051_/l2/cafeFlow/web/contracts/shiftManagement.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/shiftManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewShiftClosingReportOutput } from "_102051_/l2/cafeFlow/web/contracts/shiftManagement";
    const message_pt: {
        "shiftManagement.section.title": string;
        "shiftManagement.openShift.title": string;
        "shiftManagement.openShift.form.title": string;
        "shiftManagement.openShift.notes.label": string;
        "shiftManagement.openShift.submit.label": string;
        "shiftManagement.closeShift.title": string;
        "shiftManagement.closeShift.form.title": string;
        "shiftManagement.closeShift.totalApurado.label": string;
        "shiftManagement.closeShift.notes.label": string;
        "shiftManagement.closeShift.submit.label": string;
        "shiftManagement.viewReport.title": string;
        "shiftManagement.viewReport.action.title": string;
        "shiftManagement.viewReport.action.label": string;
        "shiftManagement.viewReport.summary.title": string;
        "shiftManagement.viewReport.shiftClosingReportId.label": string;
        "shiftManagement.viewReport.shiftId.label": string;
        "shiftManagement.viewReport.totalApurado.label": string;
        "shiftManagement.viewReport.paidOrderCount.label": string;
        "shiftManagement.viewReport.createdAt.label": string;
        "shiftManagement.viewReport.updatedAt.label": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowShiftManagementBase extends CollabLitElement {
        status: string;
        openShiftState: 'idle' | 'loading' | 'success' | 'error';
        openShiftNotes: string;
        closeShiftState: 'idle' | 'loading' | 'success' | 'error';
        closeShiftTotalApurado: string;
        closeShiftNotes: string;
        viewShiftClosingReportState: 'idle' | 'loading' | 'success' | 'error';
        viewShiftClosingReportData: CafeFlowViewShiftClosingReportOutput | null;
        private subscribedKeys;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        setOpenShiftNotes(value: string): void;
        handleOpenShiftNotesChange(e: Event): void;
        setCloseShiftTotalApurado(value: string): void;
        handleCloseShiftTotalApuradoChange(e: Event): void;
        setCloseShiftNotes(value: string): void;
        handleCloseShiftNotesChange(e: Event): void;
        loadViewShiftClosingReport(): Promise<void>;
        handleViewShiftClosingReportClick(_e: Event): void;
        openShift(): Promise<void>;
        handleOpenShiftClick(_e: Event): void;
        closeShift(): Promise<void>;
        handleCloseShiftClick(_e: Event): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/shiftManagement" {
    import { CafeFlowShiftManagementBase } from "_102051_/l2/cafeFlow/web/shared/shiftManagement";
    export class CafeFlowDesktopPage11ShiftManagementPage extends CafeFlowShiftManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/stockManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/stockManagement.defs.ts", "_102051_/l2/cafeFlow/web/shared/stockManagement.ts", "_102051_/l2/cafeFlow/web/contracts/stockManagement.defs.ts", "_102051_/l2/cafeFlow/web/contracts/stockManagement.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/stockManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowBrowseStockItemsOutput } from "_102051_/l2/cafeFlow/web/contracts/stockManagement";
    const message_pt: {
        "stockManagement.section.main.title": string;
        "stockManagement.organism.browseStockItems.title": string;
        "stockManagement.intentions.browseStockItems.queryList.title": string;
        "stockManagement.intentions.browseStockItems.queryList.empty": string;
        "stockManagement.filters.searchTerm": string;
        "stockManagement.fields.name": string;
        "stockManagement.fields.unit": string;
        "stockManagement.fields.minimumLevel": string;
        "stockManagement.fields.updatedAt": string;
        "stockManagement.fields.createdAt": string;
        "stockManagement.actions.browseStockItems": string;
        "stockManagement.organism.manageStockItem.title": string;
        "stockManagement.intentions.manageStockItem.form.title": string;
        "stockManagement.actions.manageStockItem": string;
        "stockManagement.intentions.manageStockItem.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowStockManagementBase extends CollabLitElement {
        status: string;
        browseStockItemsState: 'idle' | 'loading' | 'success' | 'error';
        browseStockItemsSearchTerm: string;
        browseStockItemsData: CafeFlowBrowseStockItemsOutput;
        manageStockItemState: 'idle' | 'loading' | 'success' | 'error';
        manageStockItemName: string;
        manageStockItemUnit: string;
        manageStockItemMinimumLevel: string;
        LayoutSummaryManageStockItemUpdatedAt: string;
        protected get msg(): MessageType;
        loadBrowseStockItems(): Promise<boolean>;
        handleBrowseStockItemsClick(): Promise<void>;
        manageStockItem(signal?: AbortSignal): Promise<void>;
        handleManageStockItemClick(): Promise<void>;
        setBrowseStockItemsSearchTerm(value: string): void;
        handleBrowseStockItemsSearchTermChange(e: Event): void;
        setManageStockItemName(value: string): void;
        handleManageStockItemNameChange(e: Event): void;
        setManageStockItemUnit(value: string): void;
        handleManageStockItemUnitChange(e: Event): void;
        setManageStockItemMinimumLevel(value: string): void;
        handleManageStockItemMinimumLevelChange(e: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/stockManagement" {
    import { CafeFlowStockManagementBase } from "_102051_/l2/cafeFlow/web/shared/stockManagement";
    export class CafeFlowDesktopPage11StockManagementPage extends CafeFlowStockManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                    stateKey?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        source?: undefined;
                        binding?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        source?: undefined;
                        binding?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/kitchenQueue.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/kitchenQueue.defs.ts", "_102051_/l2/cafeFlow/web/shared/kitchenQueue.ts", "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.defs.ts", "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/kitchenQueue" {
    import { CafeFlowKitchenQueueBase } from "_102051_/l2/cafeFlow/web/shared/kitchenQueue";
    export class CafeFlowDesktopPage21KitchenQueuePage extends CafeFlowKitchenQueueBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    })[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            description: string;
            stateKey: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/managerDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/managerDashboard.defs.ts", "_102051_/l2/cafeFlow/web/shared/managerDashboard.ts", "_102051_/l2/cafeFlow/web/contracts/managerDashboard.defs.ts", "_102051_/l2/cafeFlow/web/contracts/managerDashboard.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/managerDashboard" {
    import { CafeFlowManagerDashboardBase } from "_102051_/l2/cafeFlow/web/shared/managerDashboard";
    export class CafeFlowDesktopPage21ManagerDashboardPage extends CafeFlowManagerDashboardBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                })[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                })[];
            }[];
        })[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        source?: undefined;
                        binding?: undefined;
                        action?: undefined;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    })[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        binding?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/menuManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/menuManagement.defs.ts", "_102051_/l2/cafeFlow/web/shared/menuManagement.ts", "_102051_/l2/cafeFlow/web/contracts/menuManagement.defs.ts", "_102051_/l2/cafeFlow/web/contracts/menuManagement.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/menuManagement" {
    import { CafeFlowMenuManagementBase } from "_102051_/l2/cafeFlow/web/shared/menuManagement";
    export class CafeFlowDesktopPage21MenuManagementPage extends CafeFlowMenuManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        })[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        action: string;
                        displayHint: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/posWorkspace.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/posWorkspace.defs.ts", "_102051_/l2/cafeFlow/web/shared/posWorkspace.ts", "_102051_/l2/cafeFlow/web/contracts/posWorkspace.defs.ts", "_102051_/l2/cafeFlow/web/contracts/posWorkspace.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/posWorkspace" {
    import { CafeFlowPosWorkspaceBase } from "_102051_/l2/cafeFlow/web/shared/posWorkspace";
    export class CafeFlowDesktopPage11PosWorkspacePage extends CafeFlowPosWorkspaceBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        } | {
            id: string;
            source: string;
            description: string;
            stateKey: string;
            entity?: undefined;
            command?: undefined;
            inputStateKeys?: undefined;
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/shiftManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/shiftManagement.defs.ts", "_102051_/l2/cafeFlow/web/shared/shiftManagement.ts", "_102051_/l2/cafeFlow/web/contracts/shiftManagement.defs.ts", "_102051_/l2/cafeFlow/web/contracts/shiftManagement.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/shiftManagement" {
    import { CafeFlowShiftManagementBase } from "_102051_/l2/cafeFlow/web/shared/shiftManagement";
    export class CafeFlowDesktopPage21ShiftManagementPage extends CafeFlowShiftManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/stockManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/stockManagement.defs.ts", "_102051_/l2/cafeFlow/web/shared/stockManagement.ts", "_102051_/l2/cafeFlow/web/contracts/stockManagement.defs.ts", "_102051_/l2/cafeFlow/web/contracts/stockManagement.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/stockManagement" {
    import { CafeFlowStockManagementBase } from "_102051_/l2/cafeFlow/web/shared/stockManagement";
    export class CafeFlowDesktopPage21StockManagementPage extends CafeFlowStockManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                    stateKey?: undefined;
                })[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        source?: undefined;
                        binding?: undefined;
                        stateKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        source?: undefined;
                        binding?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page31/kitchenQueue.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page31/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/kitchenQueue.defs.ts", "_102051_/l2/cafeFlow/web/shared/kitchenQueue.ts", "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.defs.ts", "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/kitchenQueue" {
    import { CafeFlowKitchenQueueBase } from "_102051_/l2/cafeFlow/web/shared/kitchenQueue";
    export class CafeFlowDesktopPage31KitchenQueuePage extends CafeFlowKitchenQueueBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                        stateKey: string;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    })[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            description: string;
            stateKey: string;
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page31/managerDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page31/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/managerDashboard.defs.ts", "_102051_/l2/cafeFlow/web/shared/managerDashboard.ts", "_102051_/l2/cafeFlow/web/contracts/managerDashboard.defs.ts", "_102051_/l2/cafeFlow/web/contracts/managerDashboard.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/managerDashboard" {
    import { CafeFlowManagerDashboardBase } from "_102051_/l2/cafeFlow/web/shared/managerDashboard";
    export class CafeFlowDesktopPage31ManagerDashboardPage extends CafeFlowManagerDashboardBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                    action?: undefined;
                } | {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                })[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                } | {
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                })[];
            }[];
        })[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                        source?: undefined;
                        binding?: undefined;
                        action?: undefined;
                        emptyKey?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    })[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            format: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        binding?: undefined;
                        submitAction?: undefined;
                    })[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page31/menuManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page31/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/menuManagement.defs.ts", "_102051_/l2/cafeFlow/web/shared/menuManagement.ts", "_102051_/l2/cafeFlow/web/contracts/menuManagement.defs.ts", "_102051_/l2/cafeFlow/web/contracts/menuManagement.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/menuManagement" {
    import { CafeFlowMenuManagementBase } from "_102051_/l2/cafeFlow/web/shared/menuManagement";
    export class CafeFlowDesktopPage11MenuManagementPage extends CafeFlowMenuManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: ({
                    id: string;
                    intent: string;
                    order: number;
                    submitAction?: undefined;
                } | {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                })[];
            }[];
        })[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        action: string;
                        displayHint: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        displayHint: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        submitAction?: undefined;
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        submitAction: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    })[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page31/posWorkspace.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page31/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/posWorkspace.defs.ts", "_102051_/l2/cafeFlow/web/shared/posWorkspace.ts", "_102051_/l2/cafeFlow/web/contracts/posWorkspace.defs.ts", "_102051_/l2/cafeFlow/web/contracts/posWorkspace.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/posWorkspace" {
    import { CafeFlowPosWorkspaceBase } from "_102051_/l2/cafeFlow/web/shared/posWorkspace";
    export class CafeFlowDesktopPage31PosWorkspacePage extends CafeFlowPosWorkspaceBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        action: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: ({
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        } | {
            id: string;
            source: string;
            description: string;
            stateKey: string;
            entity?: undefined;
            command?: undefined;
            inputStateKeys?: undefined;
        })[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page31/shiftManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page31/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/shiftManagement.defs.ts", "_102051_/l2/cafeFlow/web/shared/shiftManagement.ts", "_102051_/l2/cafeFlow/web/contracts/shiftManagement.defs.ts", "_102051_/l2/cafeFlow/web/contracts/shiftManagement.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/shiftManagement" {
    import { CafeFlowShiftManagementBase } from "_102051_/l2/cafeFlow/web/shared/shiftManagement";
    export class CafeFlowDesktopPage11ShiftManagementPage extends CafeFlowShiftManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: ({
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    submitAction: string;
                    order: number;
                }[];
            } | {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            })[];
        }[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: ({
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        stateKey: string;
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        submitAction: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            actionKey: string;
                        }[];
                    }[];
                } | {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                })[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page31/stockManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page31/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/stockManagement.defs.ts", "_102051_/l2/cafeFlow/web/shared/stockManagement.ts", "_102051_/l2/cafeFlow/web/contracts/stockManagement.defs.ts", "_102051_/l2/cafeFlow/web/contracts/stockManagement.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page31/stockManagement" {
    import { CafeFlowStockManagementBase } from "_102051_/l2/cafeFlow/web/shared/stockManagement";
    export class CafeFlowDesktopPage31StockManagementPage extends CafeFlowStockManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/shared/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "kitchenQueue.section.queue.title": string;
            "kitchenQueue.queueCards.title": string;
            "kitchenQueue.queueCards.list.title": string;
            "kitchenQueue.queueCards.transition.title": string;
            "kitchenQueue.queueCards.summary.title": string;
            "kitchenQueue.field.orderId": string;
            "kitchenQueue.field.status": string;
            "kitchenQueue.field.orderType": string;
            "kitchenQueue.field.tableNumber": string;
            "kitchenQueue.field.priority": string;
            "kitchenQueue.field.priorityReason": string;
            "kitchenQueue.field.receivedAt": string;
            "kitchenQueue.field.inPreparationAt": string;
            "kitchenQueue.field.createdAt": string;
            "kitchenQueue.action.startOrFinish": string;
            "kitchenQueue.action.updateStatus": string;
            "kitchenQueue.workflowQueue.title": string;
            "kitchenQueue.workflowQueue.list.title": string;
            "kitchenQueue.workflowQueue.transition.title": string;
            "kitchenQueue.workflowQueue.summary.title": string;
            "kitchenQueue.kanbanBoard.title": string;
            "kitchenQueue.kanbanBoard.lanes.title": string;
            "kitchenQueue.kanbanBoard.transition.title": string;
            "kitchenQueue.kanbanBoard.summary.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/kitchenQueue.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/kitchenQueue.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/kitchenQueue.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
        }[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "managerDashboard.section.dashboard.title": string;
            "managerDashboard.dashboard.title": string;
            "managerDashboard.dashboard.list.title": string;
            "managerDashboard.dashboard.summary.title": string;
            "managerDashboard.field.status": string;
            "managerDashboard.field.orderType": string;
            "managerDashboard.field.createdAt": string;
            "managerDashboard.field.deliveredAt": string;
            "managerDashboard.field.shiftId": string;
            "managerDashboard.aiSales.title": string;
            "managerDashboard.aiSales.actions.title": string;
            "managerDashboard.aiSales.list.title": string;
            "managerDashboard.aiPromo.title": string;
            "managerDashboard.aiPromo.actions.title": string;
            "managerDashboard.aiPromo.list.title": string;
            "managerDashboard.action.viewDashboard": string;
            "managerDashboard.action.requestAiSalesSummary": string;
            "managerDashboard.action.requestAiPromoSuggestions": string;
            "managerDashboard.empty.dashboard": string;
            "managerDashboard.empty.aiSales": string;
            "managerDashboard.empty.aiPromo": string;
            "managerDashboard.field.orderId": string;
            "managerDashboard.master.title": string;
            "managerDashboard.master.list.title": string;
            "managerDashboard.detail.title": string;
            "managerDashboard.detail.summary.title": string;
            "managerDashboard.cards.dashboard.title": string;
            "managerDashboard.cards.aiSales.title": string;
            "managerDashboard.cards.aiPromo.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/managerDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/managerDashboard.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/managerDashboard.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            targetRef: string;
            required: boolean;
            selector: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.queue": string;
            "section.details": string;
            "section.context": string;
            "org.browse.title": string;
            "org.manage.title": string;
            "intent.queue.list.title": string;
            "intent.queue.filters.title": string;
            "intent.context.badge.title": string;
            "intent.manage.form.title": string;
            "intent.manage.status.title": string;
            "intent.manage.summary.title": string;
            "field.statusFilter": string;
            "field.menuCategoryIdFilter": string;
            "column.name": string;
            "column.menuCategoryId": string;
            "column.price": string;
            "column.itemType": string;
            "column.status": string;
            "column.updatedAt": string;
            "action.browseMenuItems": string;
            "field.name": string;
            "field.description": string;
            "field.menuCategoryId": string;
            "field.price": string;
            "field.itemType": string;
            "field.status": string;
            "field.activatedAt": string;
            "field.inactivatedAt": string;
            "field.updatedAt": string;
            "field.createdAt": string;
            "action.manageMenuItem": string;
            "empty.queue": string;
            "section.board": string;
            "intent.board.title": string;
            "intent.board.filters.title": string;
            "empty.board": string;
            "section.cards": string;
            "intent.cards.list.title": string;
            "intent.cards.filters.title": string;
            "empty.cards": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/menuManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/menuManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/menuManagement.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/posOrder.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            targetRef: string;
            required: boolean;
            selector: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: any[];
            statusStateKey: string;
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: {
            operationId: string;
            inputId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "posOrder.section.main.title": string;
            "posOrder.organism.createOrder.title": string;
            "posOrder.intent.createOrder.form.title": string;
            "posOrder.intent.createOrder.summary.title": string;
            "posOrder.organism.viewOrderBoard.title": string;
            "posOrder.intent.viewOrderBoard.list.title": string;
            "posOrder.organism.deliverOrder.title": string;
            "posOrder.intent.deliverOrder.confirm.title": string;
            "posOrder.intent.deliverOrder.summary.title": string;
            "posOrder.field.orderType.label": string;
            "posOrder.field.tableNumber.label": string;
            "posOrder.field.priority.label": string;
            "posOrder.field.priorityReason.label": string;
            "posOrder.field.orderId.label": string;
            "posOrder.field.status.label": string;
            "posOrder.field.createdAt.label": string;
            "posOrder.field.receivedAt.label": string;
            "posOrder.field.inPreparationAt.label": string;
            "posOrder.field.readyAt.label": string;
            "posOrder.field.deliveredAt.label": string;
            "posOrder.filter.statusFilter.label": string;
            "posOrder.action.viewOrderBoard.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "posOrder__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/posOrder.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/posOrder.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/posOrder.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["posOrder__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/posOrder.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "posWorkspace.section.orderBoard.title": string;
            "posWorkspace.organism.viewOrderBoard.title": string;
            "posWorkspace.intent.orderBoard.query.title": string;
            "posWorkspace.action.refreshBoard": string;
            "posWorkspace.section.createOrder.title": string;
            "posWorkspace.organism.createOrder.title": string;
            "posWorkspace.intent.createOrder.type.title": string;
            "posWorkspace.intent.createOrder.items.title": string;
            "posWorkspace.intent.createOrder.priority.title": string;
            "posWorkspace.intent.createOrder.summary.title": string;
            "posWorkspace.intent.createOrder.submit.title": string;
            "posWorkspace.action.createOrder": string;
            "posWorkspace.section.deliverOrder.title": string;
            "posWorkspace.organism.deliverOrder.title": string;
            "posWorkspace.intent.deliverOrder.summary.title": string;
            "posWorkspace.intent.deliverOrder.submit.title": string;
            "posWorkspace.action.deliverOrder": string;
            "posWorkspace.field.orderId": string;
            "posWorkspace.field.status": string;
            "posWorkspace.field.orderType": string;
            "posWorkspace.field.tableNumber": string;
            "posWorkspace.field.priority": string;
            "posWorkspace.field.priorityReason": string;
            "posWorkspace.field.readyAt": string;
            "posWorkspace.field.createdAt": string;
            "posWorkspace.field.orderItems": string;
            "posWorkspace.section.kanbanBoard.title": string;
            "posWorkspace.organism.kanbanBoard.title": string;
            "posWorkspace.intent.kanban.query.title": string;
            "posWorkspace.section.queue.title": string;
            "posWorkspace.organism.queueBoard.title": string;
            "posWorkspace.intent.queue.query.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/posWorkspace.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/posWorkspace.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/posWorkspace.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/salesDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            targetRef: string;
            required: boolean;
            selector: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: {
            operationId: string;
            inputId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "salesDashboard.section.dashboardAi.title": string;
            "salesDashboard.organism.viewDashboard.title": string;
            "salesDashboard.organism.requestAiSalesSummary.title": string;
            "salesDashboard.organism.requestAiPromoSuggestions.title": string;
            "salesDashboard.intent.dashboard.context.title": string;
            "salesDashboard.intent.dashboard.data.title": string;
            "salesDashboard.intent.dashboard.lowStock.title": string;
            "salesDashboard.intent.aiSales.request.title": string;
            "salesDashboard.intent.aiSales.output.title": string;
            "salesDashboard.intent.aiPromo.request.title": string;
            "salesDashboard.intent.aiPromo.output.title": string;
            "salesDashboard.field.shiftId.label": string;
            "salesDashboard.field.orderId.label": string;
            "salesDashboard.field.status.label": string;
            "salesDashboard.field.orderType.label": string;
            "salesDashboard.field.createdAt.label": string;
            "salesDashboard.field.menuItemId.label": string;
            "salesDashboard.field.quantity.label": string;
            "salesDashboard.field.stockItemId.label": string;
            "salesDashboard.field.currentQuantity.label": string;
            "salesDashboard.field.minimumQuantity.label": string;
            "salesDashboard.field.summaryRequest.label": string;
            "salesDashboard.field.deliveredAt.label": string;
            "salesDashboard.field.menuItemName.label": string;
            "salesDashboard.action.viewDashboard.label": string;
            "salesDashboard.action.requestAiSalesSummary.label": string;
            "salesDashboard.action.requestAiPromoSuggestions.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "salesDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/salesDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/salesDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/salesDashboard.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["salesDashboard__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/salesDashboard.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "shiftManagement.section.main.title": string;
            "shiftManagement.report.cards.title": string;
            "shiftManagement.report.cards.list.title": string;
            "shiftManagement.report.field.shiftId": string;
            "shiftManagement.report.field.totalApurado": string;
            "shiftManagement.report.field.paidOrderCount": string;
            "shiftManagement.report.field.createdAt": string;
            "shiftManagement.report.action.refresh": string;
            "shiftManagement.report.action.view": string;
            "shiftManagement.openShift.title": string;
            "shiftManagement.openShift.form.title": string;
            "shiftManagement.openShift.field.notes": string;
            "shiftManagement.openShift.action.submit": string;
            "shiftManagement.closeShift.title": string;
            "shiftManagement.closeShift.form.title": string;
            "shiftManagement.closeShift.field.totalApurado": string;
            "shiftManagement.closeShift.field.notes": string;
            "shiftManagement.closeShift.action.submit": string;
            "shiftManagement.summary.title": string;
            "shiftManagement.summary.section.title": string;
            "shiftManagement.summary.field.status": string;
            "shiftManagement.summary.field.openedAt": string;
            "shiftManagement.summary.field.closedAt": string;
            "shiftManagement.summary.field.totalApurado": string;
            "shiftManagement.board.title": string;
            "shiftManagement.board.intent.title": string;
            "shiftManagement.board.field.status": string;
            "shiftManagement.board.field.shiftId": string;
            "shiftManagement.board.field.openedAt": string;
            "shiftManagement.board.field.closedAt": string;
            "shiftManagement.board.field.totalApurado": string;
            "shiftManagement.board.field.paidOrderCount": string;
            "shiftManagement.queue.title": string;
            "shiftManagement.queue.list.title": string;
            "shiftManagement.report.field.updatedAt": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/shiftManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/shiftManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/shiftManagement.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "stockManagement.section.main.title": string;
            "stockManagement.browseStockItems.title": string;
            "stockManagement.browseStockItems.list.title": string;
            "stockManagement.browseStockItems.searchTerm.label": string;
            "stockManagement.manageStockItem.title": string;
            "stockManagement.manageStockItem.form.title": string;
            "stockManagement.manageStockItem.submit.label": string;
            "stockManagement.summary.title": string;
            "stockManagement.summary.detail.title": string;
            "stockManagement.stockItem.name.label": string;
            "stockManagement.stockItem.unit.label": string;
            "stockManagement.stockItem.minimumLevel.label": string;
            "stockManagement.stockItem.updatedAt.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/stockManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/stockManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/stockManagement.test" {
    export {};
}
