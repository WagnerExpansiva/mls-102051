declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems.defs" {
    export const browseMenuItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "menuItemLifecycle";
            readonly controllerName: "BrowseMenuItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowBrowseMenuItemsHandler";
                readonly command: "browseMenuItems";
                readonly usecaseRef: "browseMenuItems";
                readonly inputTypeName: "BrowseMenuItemsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "MenuItem.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por status do item (draft, active, inactive) informado pelo gerente";
                }, {
                    readonly inputId: "menuCategoryIdFilter";
                    readonly fieldRef: "MenuItem.menuCategoryId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Filtro opcional por categoria do item informado pelo gerente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "MenuItem.menuCategoryId";
                    readonly source: "businessContext";
                    readonly originRef: "businessContext.activeCompanyId";
                    readonly description: "O backend resolve o escopo da consulta limitando os itens do cardápio à empresa ativa da sessão do gerente";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "MenuItem";
                    readonly keyField: "MenuItem.menuItemId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.description", "MenuItem.menuCategoryId", "MenuItem.price", "MenuItem.itemType", "MenuItem.status", "MenuItem.activatedAt", "MenuItem.createdAt", "MenuItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.menuItemLifecycle.browseMenuItems";
                readonly handlerName: "cafeFlowBrowseMenuItemsHandler";
            }];
        };
    };
    export default browseMenuItemsController;
    export const pipeline: readonly [{
        readonly id: "browseMenuItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseMenuItemsInput {
        statusFilter?: string;
        menuCategoryIdFilter?: string;
    }
    export interface BrowseMenuItemProjection {
        menuItemId: string;
        name: string;
        description: string | null;
        menuCategoryId: string | null;
        price: number | null;
        itemType: string;
        status: string;
        activatedAt: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface BrowseMenuItemsOutput {
        items: BrowseMenuItemProjection[];
    }
    /**
     * MODELING GAP: MenuItem does not declare a `companyId` field in the MDM model.
     * The active-company scope filter (ctx.sessionContext.activeCompanyId) cannot be
     * applied directly. We record the gap and proceed without the company filter.
     */
    export function browseMenuItems(ctx: RequestContext, input: BrowseMenuItemsInput): Promise<BrowseMenuItemsOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseMenuItems" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowBrowseMenuItemsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems.defs" {
    export const browseStockItemsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseStockItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseStockItems";
            readonly controllerName: "BrowseStockItemsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowBrowseStockItemsHandler";
                readonly command: "browseStockItems";
                readonly usecaseRef: "browseStockItems";
                readonly inputTypeName: "BrowseStockItemsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "searchTerm";
                    readonly fieldRef: "StockItem.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Termo de busca opcional para filtrar itens de estoque pelo nome.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "StockItem.stockItemId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que está consultando o estoque.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "StockItem.stockItemId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend extrai o actorId da sessão autenticada do gerente para autorizar o acesso à lista de itens de estoque.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "StockItem";
                    readonly keyField: "StockItem.stockItemId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["StockItem.stockItemId", "StockItem.name", "StockItem.unit", "StockItem.minimumLevel", "StockItem.createdAt", "StockItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.browseStockItems.browseStockItems";
                readonly handlerName: "cafeFlowBrowseStockItemsHandler";
            }];
        };
    };
    export default browseStockItemsController;
    export const pipeline: readonly [{
        readonly id: "browseStockItems__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel" {
    export type StockLevelUnit = 'kg' | 'liter' | 'portion' | 'unit';
    export interface StockLevel {
        stockLevelId: string;
        stockItemId: string;
        currentQuantity: number;
        minimumLevel: number;
        unit: StockLevelUnit;
        lastDecrementAt: string | null;
        lastAdjustmentAt: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export function isStockLevelUnit(value: string): value is StockLevelUnit;
    export function validateStockLevelInvariants(stockLevel: Pick<StockLevel, 'currentQuantity' | 'minimumLevel'>): string[];
    export function isLowStock(stockLevel: Pick<StockLevel, 'currentQuantity' | 'minimumLevel'>): boolean;
    export function canDecrement(stockLevel: Pick<StockLevel, 'currentQuantity'>, amount: number): boolean;
    export function decrementStockLevel(stockLevel: StockLevel, amount: number, nowIso: string): StockLevel;
    export function adjustStockLevel(stockLevel: StockLevel, newQuantity: number, nowIso: string): StockLevel;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository" {
    import type { StockLevel, StockLevelUnit } from "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    export type StockLevelId = string;
    export interface Location {
        locationId: string;
        name?: string;
    }
    export interface StockLevelFilter {
        stockItemId?: string;
        unit?: StockLevelUnit;
    }
    export interface IStockLevelRepository {
        getById(stockLevelId: StockLevelId): Promise<StockLevel>;
        list(filter?: StockLevelFilter): Promise<StockLevel[]>;
        save(stockLevel: StockLevel): Promise<void>;
        findBelowMinimum(): Promise<StockLevel[]>;
        findByLocation(location: Location): Promise<StockLevel[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/browseStockItems" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseStockItemsInput {
        searchTerm?: string;
        page?: number;
        pageSize?: number;
    }
    export interface StockItemSummary {
        stockItemId: string;
        name: string;
        unit: string;
        minimumLevel: number;
        createdAt: string;
        updatedAt: string;
        currentQuantity: number | null;
        isLowStock: boolean;
    }
    export interface BrowseStockItemsOutput {
        stockItems: StockItemSummary[];
        total: number;
    }
    export function browseStockItems(ctx: RequestContext, input: BrowseStockItemsInput): Promise<BrowseStockItemsOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/browseStockItems" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowBrowseStockItemsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.defs" {
    export const closeShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "closeShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "CloseShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCloseShiftHandler";
                readonly command: "closeShift";
                readonly usecaseRef: "closeShift";
                readonly inputTypeName: "CloseShiftInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "totalApurado";
                    readonly fieldRef: "Shift.totalApurado";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Valor total apurado no fechamento do turno, informado pelo gerente para conferência.";
                }, {
                    readonly inputId: "notes";
                    readonly fieldRef: "Shift.notes";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Observações gerais sobre o turno, opcionais.";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Identificador do turno atualmente aberto que será fechado.";
                }, {
                    readonly inputId: "closedBy";
                    readonly fieldRef: "Shift.closedBy";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente que está fechando o turno.";
                }, {
                    readonly inputId: "closedAt";
                    readonly fieldRef: "Shift.closedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora do fechamento do turno, definida automaticamente pelo sistema.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Shift.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend localiza o único Shift com status 'open' (turno ativo) e utiliza seu shiftId como alvo do fechamento.";
                }, {
                    readonly targetRef: "Shift.closedBy";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend obtém o identificador do gerente autenticado a partir da sessão ativa.";
                }, {
                    readonly targetRef: "Shift.closedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define a data e hora de fechamento como o timestamp atual no momento da confirmação.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Shift.status", "Shift.closedAt", "Shift.closedBy", "Shift.totalApurado", "Shift.notes"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.closeShift";
                readonly handlerName: "cafeFlowCloseShiftHandler";
            }];
        };
    };
    export default closeShiftController;
    export const pipeline: readonly [{
        readonly id: "closeShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/closeShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/shift" {
    export type ShiftStatus = 'open' | 'closed';
    export interface Shift {
        shiftId: string;
        status: ShiftStatus;
        openedAt: string;
        closedAt: string | null;
        openedBy: string;
        closedBy: string | null;
        totalApurado: number | null;
        notes: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const SHIFT_STATUS_TRANSITIONS: Record<ShiftStatus, ShiftStatus[]>;
    export function canTransitionShift(from: ShiftStatus, to: ShiftStatus): boolean;
    export function validateShiftInvariants(shift: Shift): string[];
    export function hasSingleOpenShift(shifts: Shift[]): boolean;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository" {
    import type { Shift, ShiftStatus } from "_102051_/l1/cafeFlow/layer_3_domain/entities/shift";
    export type ShiftId = string;
    export type EmployeeId = string;
    export interface ShiftFilter {
        status?: ShiftStatus;
        openedBy?: string;
    }
    export interface IShiftRepository {
        getById(shiftId: ShiftId): Promise<Shift>;
        list(filter: ShiftFilter): Promise<Shift[]>;
        save(shift: Shift): Promise<void>;
        findByEmployeeId(employeeId: EmployeeId): Promise<Shift[]>;
        findByPeriod(start: Date, end: Date): Promise<Shift[]>;
        findOpenShifts(): Promise<Shift[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/order" {
    export type OrderStatus = 'registered' | 'received' | 'inPreparation' | 'ready' | 'delivered';
    export type OrderType = 'table' | 'takeout';
    export interface OrderItem {
        orderItemId: string;
        orderId: string;
        menuItemId: string;
        quantity: number;
        unitPrice: number;
        createdAt: string;
        updatedAt: string;
    }
    export interface Order {
        orderId: string;
        shiftId: string;
        status: OrderStatus;
        orderType: OrderType;
        tableNumber: string | null;
        priority: boolean | null;
        priorityReason: string | null;
        receivedAt: string | null;
        inPreparationAt: string | null;
        readyAt: string | null;
        deliveredAt: string | null;
        createdAt: string;
        updatedAt: string;
        items: OrderItem[];
    }
    export const ORDER_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]>;
    export function canTransitionOrder(from: OrderStatus, to: OrderStatus): boolean;
    export function orderRequiresItem(order: Pick<Order, 'items'>): boolean;
    export function validateTableNumber(order: Pick<Order, 'orderType' | 'tableNumber'>): boolean;
    export function validatePriorityReason(order: Pick<Order, 'priority' | 'priorityReason'>): boolean;
    export function validateStatusTimestamps(order: Pick<Order, 'status' | 'receivedAt' | 'inPreparationAt' | 'readyAt' | 'deliveredAt'>): boolean;
    export function validateOrderInvariants(order: Order): string[];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository" {
    import type { Order, OrderStatus } from "_102051_/l1/cafeFlow/layer_3_domain/entities/order";
    export type OrderId = string;
    export type CustomerId = string;
    export interface OrderFilter {
        shiftId?: string;
        status?: OrderStatus;
        orderType?: 'table' | 'takeout';
        tableNumber?: string;
    }
    export interface IOrderRepository {
        getById(orderId: OrderId): Promise<Order>;
        list(filter?: OrderFilter): Promise<Order[]>;
        save(order: Order): Promise<void>;
        findByCustomerId(customerId: CustomerId): Promise<Order[]>;
        findByStatus(status: OrderStatus): Promise<Order[]>;
        findByPeriod(start: Date, end: Date): Promise<Order[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport" {
    export interface ShiftClosingReport {
        shiftClosingReportId: string;
        shiftId: string;
        totalApurado: number;
        paidOrderCount: number;
        createdAt: string;
        updatedAt: string;
    }
    export function shiftClosingReportTotalApuradoIsValid(report: Pick<ShiftClosingReport, 'totalApurado'>): boolean;
    export function shiftClosingReportPaidOrderCountIsValid(report: Pick<ShiftClosingReport, 'paidOrderCount'>): boolean;
    export function shiftClosingReportIsUniquePerShift(report: Pick<ShiftClosingReport, 'shiftId'>, existing: Array<Pick<ShiftClosingReport, 'shiftClosingReportId' | 'shiftId'>>): boolean;
    export function validateShiftClosingReport(report: Pick<ShiftClosingReport, 'totalApurado' | 'paidOrderCount'>): string[];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository" {
    import type { ShiftClosingReport } from "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport";
    export type ShiftClosingReportId = string;
    export type ShiftId = string;
    export interface ShiftClosingReportFilter {
        shiftClosingReportId?: ShiftClosingReportId;
        shiftId?: ShiftId;
    }
    export interface IShiftClosingReportRepository {
        getById(reportId: ShiftClosingReportId): Promise<ShiftClosingReport>;
        list(filter?: ShiftClosingReportFilter): Promise<ShiftClosingReport[]>;
        save(report: ShiftClosingReport): Promise<void>;
        findByShiftId(shiftId: ShiftId): Promise<ShiftClosingReport[]>;
        findByPeriod(start: Date, end: Date): Promise<ShiftClosingReport[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/closeShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CloseShiftInput {
        totalApurado: number;
        notes?: string;
    }
    export interface CloseShiftOutput {
        shiftId: string;
        status: string;
        closedAt: string;
        closedBy: string;
        totalApurado: number;
        notes?: string;
        shiftClosingReportId: string;
        paidOrderCount: number;
    }
    export function closeShift(ctx: RequestContext, input: CloseShiftInput): Promise<CloseShiftOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/closeShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCloseShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs" {
    export const createOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "CreateOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowCreateOrderHandler";
                readonly command: "createOrder";
                readonly usecaseRef: "createOrder";
                readonly inputTypeName: "CreateOrderInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "orderType";
                    readonly fieldRef: "Order.orderType";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Tipo do pedido selecionado pelo atendente: 'table' (consumo na mesa) ou 'takeout' (para viagem)";
                }, {
                    readonly inputId: "tableNumber";
                    readonly fieldRef: "Order.tableNumber";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Número da mesa informado pelo atendente, obrigatório quando orderType = 'table'";
                }, {
                    readonly inputId: "orderItems";
                    readonly fieldRef: "OrderItem.menuItemId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Lista de itens do cardápio selecionados pelo cliente, cada um com menuItemId e quantidade";
                }, {
                    readonly inputId: "priority";
                    readonly fieldRef: "Order.priority";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Indica se o atendente marcou o pedido como prioritário no preparo";
                }, {
                    readonly inputId: "priorityReason";
                    readonly fieldRef: "Order.priorityReason";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Justificativa da priorização, obrigatória quando priority = true";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno aberto no momento do lançamento do pedido";
                }, {
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.orderId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único gerado para o novo pedido";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Order.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento de criação do registro do pedido";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Order.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento da última atualização do registro do pedido";
                }];
                readonly contextResolution: readonly [{
                    readonly inputId: "shiftId";
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolves the single Shift with status open — the active shift at the moment of order creation";
                }, {
                    readonly inputId: "orderId";
                    readonly targetRef: "Order.orderId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "Generates a new UUID to identify the order being created";
                }, {
                    readonly inputId: "createdAt";
                    readonly targetRef: "Order.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Sets the creation timestamp to the current server time at the moment of order launch";
                }, {
                    readonly inputId: "updatedAt";
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Sets the last-update timestamp to the current server time at the moment of order launch";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.createOrder";
                readonly handlerName: "cafeFlowCreateOrderHandler";
            }];
        };
    };
    export default createOrderController;
    export const pipeline: readonly [{
        readonly id: "createOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/createOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption" {
    export type StockConsumptionStatus = 'posted' | 'voided';
    export interface StockConsumption {
        stockConsumptionId: string;
        stockItemId: string;
        orderId: string;
        quantity: number;
        status: StockConsumptionStatus;
        createdAt: string;
        voidedAt: string | null;
        voidReason: string | null;
    }
    export const STOCK_CONSUMPTION_STATUS_TRANSITIONS: Record<StockConsumptionStatus, StockConsumptionStatus[]>;
    export function canTransitionStockConsumption(from: StockConsumptionStatus, to: StockConsumptionStatus): boolean;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository" {
    import type { StockConsumption } from "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption";
    export type OrderId = string;
    export type ProductId = string;
    export interface IStockConsumptionRepository {
        append(record: StockConsumption): Promise<void>;
        listByOwnerId(orderId: OrderId): Promise<StockConsumption[]>;
        listByPeriod(start: Date, end: Date): Promise<StockConsumption[]>;
        listByProductId(productId: ProductId): Promise<StockConsumption[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/createOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateOrderItemInput {
        menuItemId: string;
        quantity: number;
    }
    export interface CreateOrderInput {
        orderType: string;
        tableNumber?: string;
        orderItems: CreateOrderItemInput[];
        priority?: boolean;
        priorityReason?: string;
    }
    export interface CreateOrderOutput {
        orderId: string;
        status: string;
        orderType: string;
        tableNumber?: string;
        createdAt: string;
    }
    export function createOrder(ctx: RequestContext, input: CreateOrderInput): Promise<CreateOrderOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/createOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowCreateOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder.defs" {
    export const deliverOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "deliverOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "DeliverOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowDeliverOrderHandler";
                readonly command: "deliverOrder";
                readonly usecaseRef: "deliverOrder";
                readonly inputTypeName: "DeliverOrderInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.orderId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Pedido selecionado pelo atendente no painel para entrega";
                }, {
                    readonly inputId: "deliveredAt";
                    readonly fieldRef: "Order.deliveredAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento em que o pedido foi entregue ao cliente, gerado automaticamente";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Order.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Momento da última atualização do registro do pedido, gerado automaticamente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.orderId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Order.orderId";
                    readonly description: "O backend resolve o orderId a partir do pedido atualmente selecionado pelo atendente no painel de pedidos.";
                }, {
                    readonly targetRef: "Order.deliveredAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define deliveredAt com o timestamp atual no momento da confirmação da entrega.";
                }, {
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define updatedAt com o timestamp atual no momento da atualização do registro.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.deliveredAt", "Order.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.deliverOrder";
                readonly handlerName: "cafeFlowDeliverOrderHandler";
            }];
        };
    };
    export default deliverOrderController;
    export const pipeline: readonly [{
        readonly id: "deliverOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/deliverOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface DeliverOrderInput {
        orderId: string;
    }
    export interface DeliverOrderOutput {
        orderId: string;
        status: string;
        deliveredAt: string;
        updatedAt: string;
    }
    export function deliverOrder(ctx: RequestContext, input: DeliverOrderInput): Promise<DeliverOrderOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/deliverOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowDeliverOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem.defs" {
    export const manageMenuItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "menuItemLifecycle";
            readonly controllerName: "ManageMenuItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageMenuItemHandler";
                readonly command: "manageMenuItem";
                readonly usecaseRef: "manageMenuItem";
                readonly inputTypeName: "ManageMenuItemInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "menuItemId";
                    readonly fieldRef: "MenuItem.menuItemId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador do item do cardápio selecionado para edição";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "MenuItem.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do item do cardápio exibido no POS";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "MenuItem.description";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada do item do cardápio";
                }, {
                    readonly inputId: "menuCategoryId";
                    readonly fieldRef: "MenuItem.menuCategoryId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Categoria de classificação à qual o item pertence";
                }, {
                    readonly inputId: "price";
                    readonly fieldRef: "MenuItem.price";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Preço de venda do item do cardápio";
                }, {
                    readonly inputId: "itemType";
                    readonly fieldRef: "MenuItem.itemType";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Tipo do item: deve ser 'simple' nesta fase";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "MenuItem.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Status do item: rascunho, ativo ou inativo";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "MenuItem.menuItemId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que realiza a alteração";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "MenuItem.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "MenuItem.menuItemId";
                    readonly source: "selectedEntity";
                    readonly originRef: "MenuItem.menuItemId";
                    readonly description: "O backend resolve o menuItemId a partir do item atualmente selecionado na tela de gestão de cardápio";
                }, {
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend obtém o identificador do gerente a partir da sessão autenticada do usuário";
                }, {
                    readonly targetRef: "MenuItem.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend atribui o timestamp atual do sistema ao campo updatedAt no momento da persistência";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "MenuItem";
                    readonly keyField: "MenuItem.menuItemId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.description", "MenuItem.menuCategoryId", "MenuItem.price", "MenuItem.itemType", "MenuItem.status", "MenuItem.activatedAt", "MenuItem.inactivatedAt", "MenuItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.menuItemLifecycle.manageMenuItem";
                readonly handlerName: "cafeFlowManageMenuItemHandler";
            }];
        };
    };
    export default manageMenuItemController;
    export const pipeline: readonly [{
        readonly id: "manageMenuItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateMenuItemInput {
        menuItemId: string;
        name: string;
        description?: string;
        menuCategoryId: string;
        price: number;
        itemType: string;
        status: string;
    }
    export interface UpdateMenuItemOutput {
        menuItemId: string;
        name: string;
        description?: string;
        menuCategoryId: string;
        price: number;
        itemType: string;
        status: string;
        activatedAt?: string;
        inactivatedAt?: string;
        updatedAt: string;
    }
    export function updateMenuItem(ctx: RequestContext, input: UpdateMenuItemInput): Promise<UpdateMenuItemOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageMenuItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowManageMenuItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem.defs" {
    export const manageStockItemController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "manageStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "manageStockItem";
            readonly controllerName: "ManageStockItemController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowManageStockItemHandler";
                readonly command: "manageStockItem";
                readonly usecaseRef: "manageStockItem";
                readonly inputTypeName: "ManageStockItemInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "stockItemId";
                    readonly fieldRef: "StockItem.stockItemId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do item de estoque a ser atualizado, obtido da rota de edição.";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "StockItem.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Nome do ingrediente editado pelo gerente.";
                }, {
                    readonly inputId: "unit";
                    readonly fieldRef: "StockItem.unit";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Unidade de medida do ingrediente (kg, liter, portion ou unit).";
                }, {
                    readonly inputId: "minimumLevel";
                    readonly fieldRef: "StockItem.minimumLevel";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "StockItem.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do item de estoque.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "StockItem.stockItemId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.stockItemId";
                    readonly description: "O backend extrai o identificador do item de estoque do parâmetro de rota da tela de edição.";
                }, {
                    readonly targetRef: "StockItem.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend atribui automaticamente o timestamp atual no momento da persistência da atualização.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "StockItem";
                    readonly keyField: "StockItem.stockItemId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["StockItem.stockItemId", "StockItem.name", "StockItem.unit", "StockItem.minimumLevel", "StockItem.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.manageStockItem.manageStockItem";
                readonly handlerName: "cafeFlowManageStockItemHandler";
            }];
        };
    };
    export default manageStockItemController;
    export const pipeline: readonly [{
        readonly id: "manageStockItem__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/manageStockItem" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ManageStockItemInput {
        stockItemId: string;
        name: string;
        unit: string;
        minimumLevel: number;
    }
    export interface ManageStockItemOutput {
        stockItemId: string;
        name: string;
        unit: string;
        minimumLevel: number;
        updatedAt: string;
    }
    export function manageStockItem(ctx: RequestContext, input: ManageStockItemInput): Promise<ManageStockItemOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/manageStockItem" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowManageStockItemHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.defs" {
    export const openShiftController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "openShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "OpenShiftController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowOpenShiftHandler";
                readonly command: "openShift";
                readonly usecaseRef: "openShift";
                readonly inputTypeName: "OpenShiftInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "notes";
                    readonly fieldRef: "Shift.notes";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Observações gerais opcionais sobre o turno, informadas pelo gerente ao abrir.";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Shift.shiftId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Identificador único do turno, gerado automaticamente pelo sistema.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Shift.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Situação inicial do turno, definida como 'open' no momento da criação.";
                }, {
                    readonly inputId: "openedAt";
                    readonly fieldRef: "Shift.openedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de abertura do turno, definida automaticamente como o momento atual.";
                }, {
                    readonly inputId: "openedBy";
                    readonly fieldRef: "Shift.openedBy";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente que abriu o turno, obtido da sessão ativa.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Shift.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora de criação do registro, definida automaticamente como o momento atual.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Shift.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data e hora da última atualização do registro, definida automaticamente como o momento atual.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Shift.shiftId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "O backend gera um UUID para o novo turno no momento da criação.";
                }, {
                    readonly targetRef: "Shift.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend define o status como 'open' fixamente na criação do turno.";
                }, {
                    readonly targetRef: "Shift.openedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data e hora de abertura do turno.";
                }, {
                    readonly targetRef: "Shift.openedBy";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend obtém o identificador do gerente autenticado a partir da sessão ativa.";
                }, {
                    readonly targetRef: "Shift.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data de criação do registro.";
                }, {
                    readonly targetRef: "Shift.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend registra o timestamp atual do servidor como data da última atualização do registro.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Shift";
                    readonly keyField: "Shift.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Shift.shiftId", "Shift.status", "Shift.openedAt", "Shift.openedBy"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.openShift";
                readonly handlerName: "cafeFlowOpenShiftHandler";
            }];
        };
    };
    export default openShiftController;
    export const pipeline: readonly [{
        readonly id: "openShift__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/openShift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/openShift" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface OpenShiftInput {
        notes?: string;
    }
    export interface OpenShiftOutput {
        shiftId: string;
        status: string;
        openedAt: string;
        openedBy: string;
    }
    export function openShift(ctx: RequestContext, input: OpenShiftInput): Promise<OpenShiftOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/openShift" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowOpenShiftHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions.defs" {
    export const requestAiPromoSuggestionsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "requestAiPromoSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "requestAiPromoSuggestions";
            readonly controllerName: "RequestAiPromoSuggestionsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRequestAiPromoSuggestionsHandler";
                readonly command: "requestAiPromoSuggestions";
                readonly usecaseRef: "requestAiPromoSuggestions";
                readonly inputTypeName: "RequestAiPromoSuggestionsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "actorId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identidade do gerente que solicita as sugestões, para auditoria e contexto de permissão";
                }, {
                    readonly inputId: "windowStart";
                    readonly fieldRef: "Order.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Data de início da janela de análise (7 dias antes do momento atual)";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend resolve o identificador do gerente a partir da sessão ativa para validar permissão e registrar auditoria da solicitação";
                }, {
                    readonly targetRef: "Order.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O backend calcula o início da janela de 7 dias subtraindo 7 dias do timestamp atual (systemDefault.now) para filtrar apenas pedidos dentro do período relevante";
                }];
                readonly accessPattern: {
                    readonly kind: "lookup";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.orderType", "Order.status", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.requestAiPromoSuggestions.requestAiPromoSuggestions";
                readonly handlerName: "cafeFlowRequestAiPromoSuggestionsHandler";
            }];
        };
    };
    export default requestAiPromoSuggestionsController;
    export const pipeline: readonly [{
        readonly id: "requestAiPromoSuggestions__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface RequestAiPromoSuggestionsInput {
    }
    export interface PromoSuggestion {
        menuItemId: string;
        suggestedPromoType: 'bundle' | 'discount' | 'featured';
        reason: string;
        currentStockLevel: number;
        recentSalesQuantity: number;
    }
    export interface RequestAiPromoSuggestionsOutput {
        suggestions: string;
        windowStart: string;
        windowEnd: string;
        analyzedOrderCount: number;
    }
    /**
     * Rule aiPromoBasedOnLast7Days: only orders within the 7-day window are considered.
     * Rule aiConsumesDomainData: every suggestion is derived exclusively from Order, OrderItem,
     * and StockLevel domain data — no external data sources are consulted.
     */
    export function requestAiPromoSuggestions(ctx: RequestContext, _input: RequestAiPromoSuggestionsInput): Promise<RequestAiPromoSuggestionsOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiPromoSuggestions" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowRequestAiPromoSuggestionsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary.defs" {
    export const requestAiSalesSummaryController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "requestAiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "requestAiSalesSummary";
            readonly controllerName: "RequestAiSalesSummaryController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowRequestAiSalesSummaryHandler";
                readonly command: "requestAiSalesSummary";
                readonly usecaseRef: "requestAiSalesSummary";
                readonly inputTypeName: "AiSalesSummaryInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno atualmente aberto para filtrar apenas os pedidos do dia corrente";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que solicita o resumo";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolvido a partir do único Shift com status open, filtrando apenas pedidos do turno/dia corrente";
                }, {
                    readonly targetRef: "Order.shiftId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "Resolvido a partir da sessão autenticada do gerente para autorizar o acesso ao resumo de vendas";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.createdAt", "Order.deliveredAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.requestAiSalesSummary.requestAiSalesSummary";
                readonly handlerName: "cafeFlowRequestAiSalesSummaryHandler";
            }];
        };
    };
    export default requestAiSalesSummaryController;
    export const pipeline: readonly [{
        readonly id: "requestAiSalesSummary__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { StockLevelUnit } from "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel";
    export interface RequestAiSalesSummaryInput {
    }
    export interface AiSalesSummaryOrderProjection {
        orderId: string;
        status: string;
        orderType: string;
        createdAt: string;
        deliveredAt: string | null;
    }
    export interface AiSalesSummaryTopSeller {
        menuItemId: string;
        totalQuantity: number;
    }
    export interface AiSalesSummaryStockAlert {
        stockItemId: string;
        currentQuantity: number;
        minimumLevel: number;
        unit: StockLevelUnit;
    }
    export interface AiSalesSummary {
        shiftId: string | null;
        totalOrders: number;
        orders: AiSalesSummaryOrderProjection[];
        topSellers: AiSalesSummaryTopSeller[];
        stockAlerts: AiSalesSummaryStockAlert[];
    }
    export function requestAiSalesSummary(ctx: RequestContext, _input: RequestAiSalesSummaryInput): Promise<AiSalesSummary>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/requestAiSalesSummary" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowRequestAiSalesSummaryHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs" {
    export const updateOrderStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "UpdateOrderStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
                readonly command: "updateOrderStatus";
                readonly usecaseRef: "updateOrderStatus";
                readonly inputTypeName: "UpdateOrderStatusInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "orderId";
                    readonly fieldRef: "Order.orderId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Pedido selecionado pelo cozinheiro na fila da cozinha";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Order.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Novo status que o cozinheiro deseja atribuir ao pedido (inPreparation ou ready)";
                }, {
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno aberto no momento da atualização, para validar que o pedido pertence ao turno atual";
                }, {
                    readonly inputId: "inPreparationAt";
                    readonly fieldRef: "Order.inPreparationAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp definido quando o status passa a inPreparation";
                }, {
                    readonly inputId: "readyAt";
                    readonly fieldRef: "Order.readyAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp definido quando o status passa a ready";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Order.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp da última atualização do registro";
                }];
                readonly contextResolution: readonly [{
                    readonly inputId: "shiftId";
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolve o turno atualmente aberto (single Shift with status open) para validar que o pedido pertence ao turno ativo";
                }, {
                    readonly inputId: "inPreparationAt";
                    readonly targetRef: "Order.inPreparationAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Define o timestamp atual quando o status transita para inPreparation";
                }, {
                    readonly inputId: "readyAt";
                    readonly targetRef: "Order.readyAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Define o timestamp atual quando o status transita para ready";
                }, {
                    readonly inputId: "updatedAt";
                    readonly targetRef: "Order.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Define o timestamp atual em toda atualização do registro";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "single";
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.updateOrderStatus";
                readonly handlerName: "cafeFlowUpdateOrderStatusHandler";
            }];
        };
    };
    export default updateOrderStatusController;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateOrderStatusInput {
        orderId: string;
        status: string;
    }
    export interface UpdateOrderStatusOutput {
        orderId: string;
        status: string;
        updatedAt: string;
    }
    export function updateOrderStatus(ctx: RequestContext, input: UpdateOrderStatusInput): Promise<UpdateOrderStatusOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/updateOrderStatus" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowUpdateOrderStatusHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.defs" {
    export const viewDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewDashboard";
            readonly controllerName: "ViewDashboardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewDashboardHandler";
                readonly command: "viewDashboard";
                readonly usecaseRef: "viewDashboard";
                readonly inputTypeName: "ViewDashboardInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno atualmente aberto, usado para filtrar todos os dados do dashboard";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Identificador do gerente autenticado que solicita o dashboard";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend localiza o único Shift com status aberto no momento e usa seu shiftId para filtrar todos os pedidos e dados agregados do dashboard";
                }, {
                    readonly targetRef: "Order.shiftId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "O backend extrai o actorId da sessão autenticada do gerente para autorizar o acesso ao dashboard";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "Lista agregada de pedidos do turno atual para composição do dashboard com total de vendas, itens mais vendidos e alertas de estoque baixo";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Order.status", "Order.orderType", "Order.createdAt", "Order.shiftId", "Order.deliveredAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.viewDashboard.viewDashboard";
                readonly handlerName: "cafeFlowViewDashboardHandler";
            }];
        };
    };
    export default viewDashboardController;
    export const pipeline: readonly [{
        readonly id: "viewDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewDashboard" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewDashboardInput {
    }
    export interface DashboardOrder {
        orderId: string;
        status: string;
        orderType: string;
        createdAt: string;
        shiftId: string;
        deliveredAt: string | null;
    }
    export interface DashboardTopSeller {
        menuItemId: string;
        totalQuantity: number;
        totalRevenue: number;
    }
    export interface DashboardLowStockAlert {
        stockLevelId: string;
        stockItemId: string;
        currentQuantity: number;
        minimumLevel: number;
        unit: string;
    }
    export interface ViewDashboardOutput {
        shiftId: string | null;
        totalSales: number;
        orders: DashboardOrder[];
        topSellers: DashboardTopSeller[];
        lowStockAlerts: DashboardLowStockAlert[];
    }
    export function viewDashboard(ctx: RequestContext, _input: ViewDashboardInput): Promise<ViewDashboardOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewDashboard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewDashboardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard.defs" {
    export const viewKitchenBoardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewKitchenBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "ViewKitchenBoardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewKitchenBoardHandler";
                readonly command: "viewKitchenBoard";
                readonly usecaseRef: "viewKitchenBoard";
                readonly inputTypeName: "ViewKitchenBoardInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno aberto no momento, usado para filtrar apenas pedidos do turno atual";
                }, {
                    readonly inputId: "statusFilter";
                    readonly fieldRef: "Order.status";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Filtro padrão de status: exibe pedidos com status 'received' ou 'inPreparation'";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "Resolvido buscando o único Shift com status 'open' no momento da consulta, garantindo que apenas pedidos do turno atual sejam exibidos";
                }, {
                    readonly targetRef: "Order.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "O filtro de status é aplicado automaticamente pelo backend, restringindo a lista aos status 'received' e 'inPreparation' sem exigir entrada do usuário";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly filters: readonly ["Order.status", "Order.shiftId"];
                    readonly sort: readonly ["Order.priority", "Order.receivedAt"];
                    readonly pagination: "optional";
                    readonly selection: "single";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.priority", "Order.priorityReason", "Order.receivedAt", "Order.inPreparationAt", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.viewKitchenBoard";
                readonly handlerName: "cafeFlowViewKitchenBoardHandler";
            }];
        };
    };
    export default viewKitchenBoardController;
    export const pipeline: readonly [{
        readonly id: "viewKitchenBoard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewKitchenBoardInput {
    }
    export interface KitchenBoardOrderItem {
        orderItemId: string;
        menuItemId: string;
        quantity: number;
        unitPrice: number;
    }
    export interface KitchenBoardOrder {
        orderId: string;
        status: string;
        orderType: string;
        tableNumber: string | null;
        priority: boolean | null;
        priorityReason: string | null;
        receivedAt: string | null;
        inPreparationAt: string | null;
        createdAt: string;
        items: KitchenBoardOrderItem[];
    }
    export interface ViewKitchenBoardOutput {
        orders: KitchenBoardOrder[];
    }
    /**
     * View the kitchen board: returns all orders in 'received' or 'inPreparation' status,
     * sorted by priority (DESC) then receivedAt (ASC) per the fifoKitchenQueue rule.
     *
     * Rules applied:
     * - dashboardCurrentShiftOnly: orders should be filtered to the active (open) shift.
     *   Modeling gap: the Shift port is not available in this module's ports, so the active
     *   shift cannot be resolved. We proceed without the shift filter rather than inventing
     *   a shiftId. If/when the Shift port is added, filter `kitchenOrders` by `shiftId`.
     * - fifoKitchenQueue: sort by priority DESC (true first), then receivedAt ASC (oldest first).
     */
    export function viewKitchenBoard(ctx: RequestContext, _input: ViewKitchenBoardInput): Promise<ViewKitchenBoardOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewKitchenBoard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewKitchenBoardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard.defs" {
    export const viewOrderBoardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewOrderBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "orderLifecycle";
            readonly controllerName: "ViewOrderBoardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewOrderBoardHandler";
                readonly command: "viewOrderBoard";
                readonly usecaseRef: "viewOrderBoard";
                readonly inputTypeName: "ViewOrderBoardInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "Order.shiftId";
                    readonly required: true;
                    readonly source: "activeLifecycleInstance";
                    readonly description: "Turno atualmente aberto para filtrar apenas pedidos do turno corrente";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Order.shiftId";
                    readonly source: "activeLifecycleInstance";
                    readonly originRef: "Shift.shiftId";
                    readonly description: "O backend resolve o turno atualmente aberto consultando a única Shift com status open e utiliza seu shiftId para filtrar os pedidos exibidos no painel";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Order";
                    readonly keyField: "Order.orderId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Order.orderId", "Order.status", "Order.orderType", "Order.tableNumber", "Order.priority", "Order.priorityReason", "Order.receivedAt", "Order.inPreparationAt", "Order.readyAt", "Order.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.orderLifecycle.viewOrderBoard";
                readonly handlerName: "cafeFlowViewOrderBoardHandler";
            }];
        };
    };
    export default viewOrderBoardController;
    export const pipeline: readonly [{
        readonly id: "viewOrderBoard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { OrderStatus } from "_102051_/l1/cafeFlow/layer_3_domain/entities/order";
    /** Projected order item for the kitchen board view. */
    export interface OrderBoardItem {
        orderId: string;
        status: OrderStatus;
        orderType: 'table' | 'takeout';
        tableNumber: string | null;
        priority: boolean | null;
        priorityReason: string | null;
        receivedAt: string | null;
        inPreparationAt: string | null;
        readyAt: string | null;
        createdAt: string;
    }
    export interface ViewOrderBoardInput {
    }
    export interface ViewOrderBoardOutput {
        orders: OrderBoardItem[];
    }
    /**
     * View the kitchen order board for the currently open shift.
     *
     * Rules applied:
     * - dashboardCurrentShiftOnly: only orders belonging to the single open shift are shown.
     * - fifoKitchenQueue: orders are sorted by createdAt ascending (oldest first).
     * - orderStatusFlow: only orders with a valid status are included.
     */
    export function viewOrderBoard(ctx: RequestContext, _input: ViewOrderBoardInput): Promise<ViewOrderBoardOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewOrderBoard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewOrderBoardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport.defs" {
    export const viewShiftClosingReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "shiftLifecycle";
            readonly controllerName: "ViewShiftClosingReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "cafeFlowViewShiftClosingReportHandler";
                readonly command: "viewShiftClosingReport";
                readonly usecaseRef: "viewShiftClosingReport";
                readonly inputTypeName: "ViewShiftClosingReportInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "shiftId";
                    readonly fieldRef: "ShiftClosingReport.shiftId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identificador do turno fechado cujo relatório de fechamento será exibido.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ShiftClosingReport.shiftId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.shiftId";
                    readonly description: "O shiftId é extraído do parâmetro de rota para localizar o único relatório de fechamento correspondente ao turno fechado.";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "";
                    readonly entity: "ShiftClosingReport";
                    readonly keyField: "ShiftClosingReport.shiftId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["ShiftClosingReport.shiftClosingReportId", "ShiftClosingReport.shiftId", "ShiftClosingReport.totalApurado", "ShiftClosingReport.paidOrderCount", "ShiftClosingReport.createdAt", "ShiftClosingReport.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "cafeFlow.shiftLifecycle.viewShiftClosingReport";
                readonly handlerName: "cafeFlowViewShiftClosingReportHandler";
            }];
        };
    };
    export default viewShiftClosingReportController;
    export const pipeline: readonly [{
        readonly id: "viewShiftClosingReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewShiftClosingReportInput {
        shiftId: string;
    }
    export interface ViewShiftClosingReportOutput {
        shiftClosingReportId: string;
        shiftId: string;
        totalApurado: number;
        paidOrderCount: number;
        createdAt: string;
        updatedAt: string;
    }
    export function viewShiftClosingReport(ctx: RequestContext, input: ViewShiftClosingReportInput): Promise<ViewShiftClosingReportOutput>;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/http/controllers/viewShiftClosingReport" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const cafeFlowViewShiftClosingReportHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.defs" {
    export const menuItemIngredientTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "MenuItemIngredient";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "MenuItemIngredient";
            readonly tableName: "menu_item_ingredient";
            readonly columns: readonly [{
                readonly name: "menu_item_ingredient_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "menu_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "stock_item_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "unit";
                readonly type: "varchar";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "quantity, updatedAt";
            }];
            readonly primaryKey: readonly ["menu_item_ingredient_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_menu_item_ingredient_menu_item_id";
                readonly columns: readonly ["menu_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_ingredient_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_ingredient_unit";
                readonly columns: readonly ["unit"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_menu_item_ingredient_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
        };
    };
    export default menuItemIngredientTableDefinition;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredient__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const menuItemIngredientTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter.defs" {
    export const menuItemIngredientRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "MenuItemIngredientRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "MenuItemIngredientRepositoryAdapter";
            readonly entityId: "MenuItemIngredient";
            readonly portRef: "IMenuItemIngredientRepository";
            readonly tableRef: "menu_item_ingredients";
            readonly mdmReads: readonly ["ctx.mdm.collection.getMany/hydrateMany({ type: 'MenuItem', ids: [...menuItemIds] })", "ctx.mdm.collection.getMany/hydrateMany({ type: 'StockItem', ids: [...stockItemIds] })"];
            readonly notes: readonly ["columns: menu_item_ingredient_id, menu_item_id, stock_item_id, unit, created_at", "details JSONB: quantity, updatedAt", "menu_item_id -> MenuItem and stock_item_id -> StockItem resolved via bulk ctx.mdm.collection.getMany/hydrateMany"];
        };
    };
    export default menuItemIngredientRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredientRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredient.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient" {
    export type MenuItemIngredientUnit = 'kg' | 'gram' | 'liter' | 'milliliter' | 'portion' | 'unit';
    export interface MenuItemIngredient {
        menuItemIngredientId: string;
        menuItemId: string;
        stockItemId: string;
        quantity: number;
        unit: MenuItemIngredientUnit;
        createdAt: string;
        updatedAt: string;
    }
    /**
     * Unit compatibility groups — ingredients whose stock item uses a unit from the
     * same group are considered compatible.
     */
    export const UNIT_COMPATIBILITY_GROUPS: Record<MenuItemIngredientUnit, MenuItemIngredientUnit[]>;
    /**
     * Invariant: quantity must be greater than zero.
     */
    export function menuItemIngredientQuantityIsValid(ingredient: Pick<MenuItemIngredient, 'quantity'>): boolean;
    /**
     * Invariant: the unit of the link must be compatible with the unit of the
     * referenced stock item.
     */
    export function menuItemIngredientUnitIsCompatible(ingredientUnit: MenuItemIngredientUnit, stockItemUnit: MenuItemIngredientUnit): boolean;
    /**
     * Invariant: cannot have more than one link between the same menuItemId and stockItemId.
     * Returns true when the given list has no duplicate (menuItemId, stockItemId) pairs.
     */
    export function menuItemIngredientNoDuplicateLinks(ingredients: Array<Pick<MenuItemIngredient, 'menuItemId' | 'stockItemId'>>): boolean;
    /**
     * Returns the duplicate key if one exists, or null otherwise.
     */
    export function findDuplicateMenuItemIngredientLink(ingredients: Array<Pick<MenuItemIngredient, 'menuItemId' | 'stockItemId'>>): {
        menuItemId: string;
        stockItemId: string;
    } | null;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository" {
    import type { MenuItemIngredient } from "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient";
    export interface MenuItemIngredientFilter {
        menuItemId?: string;
        stockItemId?: string;
        unit?: MenuItemIngredient['unit'];
    }
    export interface IMenuItemIngredientRepository {
        /** Retrieve a menu item ingredient by its unique identifier. Throws NOT_FOUND when absent. */
        getById(id: string): Promise<MenuItemIngredient>;
        /** List menu item ingredients matching the given filter. */
        list(filter?: MenuItemIngredientFilter): Promise<MenuItemIngredient[]>;
        /** Persist the menu item ingredient aggregate (upsert). */
        save(menuItemIngredient: MenuItemIngredient): Promise<void>;
        /** Find ingredient mappings for a specific menu item. */
        findByMenuItemId(menuItemId: string): Promise<MenuItemIngredient[]>;
        /** Find menu item mappings for a specific ingredient (stock item). */
        findByIngredientId(ingredientId: string): Promise<MenuItemIngredient[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/menuItemIngredientRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IMenuItemIngredientRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository";
    export function createMenuItemIngredientRepositoryAdapter(ctx: RequestContext): IMenuItemIngredientRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Order";
            readonly tableName: "order";
            readonly columns: readonly [{
                readonly name: "order_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique order identifier";
            }, {
                readonly name: "shift_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to shift";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "order lifecycle status";
            }, {
                readonly name: "order_type";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "order type discriminator";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "tableNumber, priority, priorityReason, receivedAt, inPreparationAt, readyAt, deliveredAt, updatedAt + child collection OrderItem";
            }];
            readonly primaryKey: readonly ["order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_order_shift_id";
                readonly columns: readonly ["shift_id"];
            }, {
                readonly indexName: "idx_order_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_order_order_type";
                readonly columns: readonly ["order_type"];
            }, {
                readonly indexName: "idx_order_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly ["OrderItem"];
            };
            readonly purpose: "operational";
            readonly appendOnly: false;
        };
    };
    export default orderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "order__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/order.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/order" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const orderTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs" {
    export const orderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "OrderRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "OrderRepositoryAdapter";
            readonly entityId: "Order";
            readonly portRef: "IOrderRepository";
            readonly tableRef: "orders";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain aggregate Order <-> orders table row", "Real columns: order_id, shift_id, status, order_type, created_at", "details JSONB contains: tableNumber, priority, priorityReason, receivedAt, inPreparationAt, readyAt, deliveredAt, updatedAt, items (embedded OrderItem[])", "Uses ctx.data.moduleData.orders"];
        };
    };
    export default orderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "orderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/orderRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IOrderRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository";
    export function createOrderRepositoryAdapter(ctx: RequestContext): IOrderRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IShiftRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository";
    export function createShiftRepositoryAdapter(ctx: RequestContext): IShiftRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IShiftClosingReportRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository";
    export function createShiftClosingReportRepositoryAdapter(ctx: RequestContext): IShiftClosingReportRepository;
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment" {
    export type StockAdjustmentStatus = 'posted' | 'voided';
    export interface StockAdjustment {
        stockAdjustmentId: string;
        stockItemId: string;
        status: StockAdjustmentStatus;
        quantity: number;
        reason: string;
        voidedAt: string | null;
        voidedReason: string | null;
        createdAt: string;
    }
    export const STOCK_ADJUSTMENT_STATUS_TRANSITIONS: Record<StockAdjustmentStatus, StockAdjustmentStatus[]>;
    export function canTransitionStockAdjustment(from: StockAdjustmentStatus, to: StockAdjustmentStatus): boolean;
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository" {
    import type { StockAdjustment } from "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment";
    export type ProductId = string;
    export type AdjustmentReason = string;
    export interface IStockAdjustmentRepository {
        append(record: StockAdjustment): Promise<void>;
        listByProductId(productId: ProductId): Promise<StockAdjustment[]>;
        listByPeriod(start: Date, end: Date): Promise<StockAdjustment[]>;
        listByReason(reason: AdjustmentReason): Promise<StockAdjustment[]>;
    }
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockAdjustmentRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository";
    export function createStockAdjustmentRepositoryAdapter(ctx: RequestContext): IStockAdjustmentRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockConsumptionRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository";
    export function createStockConsumptionRepositoryAdapter(ctx: RequestContext): IStockConsumptionRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStockLevelRepository } from "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository";
    export function createStockLevelRepositoryAdapter(ctx: RequestContext): IStockLevelRepository;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/registerRepositories" { }
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/seeds" {
    import type { TableSeedRows } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const menuItemIngredientSeeds: TableSeedRows;
    export const orderSeeds: TableSeedRows;
    export const shiftSeeds: TableSeedRows;
    export const shiftClosingReportSeeds: TableSeedRows;
    export const stockAdjustmentSeeds: TableSeedRows;
    export const stockConsumptionSeeds: TableSeedRows;
    export const stockLevelSeeds: TableSeedRows;
    export const mdmEntityIndexSeeds: TableSeedRows;
    export const mdmDocumentSeeds: TableSeedRows;
    export const mdmRelationshipSeeds: TableSeedRows;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.defs" {
    export const shiftTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Shift";
            readonly tableName: "shift";
            readonly columns: readonly [{
                readonly name: "shift_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique shift identifier";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "shift lifecycle status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "openedAt, closedAt, openedBy, closedBy, totalApurado, notes, updatedAt";
            }];
            readonly primaryKey: readonly ["shift_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_shift_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_shift_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly purpose: "operational";
            readonly appendOnly: false;
        };
    };
    export default shiftTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shift__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shift" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.defs" {
    export const shiftClosingReportTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "ShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "ShiftClosingReport";
            readonly tableName: "shift_closing_report";
            readonly columns: readonly [{
                readonly name: "shift_closing_report_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique report identifier";
            }, {
                readonly name: "shift_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to shift";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "totalApurado, paidOrderCount, updatedAt";
            }];
            readonly primaryKey: readonly ["shift_closing_report_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_shift_closing_report_shift_id";
                readonly columns: readonly ["shift_id"];
            }, {
                readonly indexName: "idx_shift_closing_report_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly purpose: "operational";
            readonly appendOnly: false;
        };
    };
    export default shiftClosingReportTableDefinition;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReport__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const shiftClosingReportTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter.defs" {
    export const shiftClosingReportRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ShiftClosingReportRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ShiftClosingReportRepositoryAdapter";
            readonly entityId: "ShiftClosingReport";
            readonly portRef: "IShiftClosingReportRepository";
            readonly tableRef: "shift_closing_reports";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain aggregate ShiftClosingReport <-> shift_closing_reports table row", "Real columns: shift_closing_report_id, shift_id, created_at", "details JSONB contains: totalApurado, paidOrderCount, updatedAt", "Uses ctx.data.moduleData.shift_closing_reports"];
        };
    };
    export default shiftClosingReportRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReportRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReportRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftClosingReport.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.defs" {
    export const shiftRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ShiftRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ShiftRepositoryAdapter";
            readonly entityId: "Shift";
            readonly portRef: "IShiftRepository";
            readonly tableRef: "shifts";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Domain aggregate Shift <-> shifts table row", "Real columns: shift_id, status, created_at", "details JSONB contains: openedAt, closedAt, openedBy, closedBy, totalApurado, notes, updatedAt", "Uses ctx.data.moduleData.shifts"];
        };
    };
    export default shiftRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "shiftRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shiftRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.defs" {
    export const stockAdjustmentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockAdjustment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockAdjustment";
            readonly tableName: "stock_adjustment";
            readonly columns: readonly [{
                readonly name: "stock_adjustment_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique adjustment identifier";
            }, {
                readonly name: "stock_item_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to stock item (owner)";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "adjustment status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "quantity, reason, voidedAt, voidedReason";
            }];
            readonly primaryKey: readonly ["stock_adjustment_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_adjustment_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
            }, {
                readonly indexName: "idx_stock_adjustment_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_stock_adjustment_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly purpose: "controle";
            readonly appendOnly: true;
            readonly retentionDays: 365;
        };
    };
    export default stockAdjustmentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockAdjustment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockAdjustmentTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter.defs" {
    export const stockAdjustmentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockAdjustmentRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockAdjustmentRepositoryAdapter";
            readonly entityId: "StockAdjustment";
            readonly portRef: "IStockAdjustmentRepository";
            readonly tableRef: "stock_adjustments";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Event StockAdjustment <-> stock_adjustments table row", "Real columns: stock_adjustment_id, stock_item_id, status, created_at", "details JSONB contains: quantity, reason, voidedAt, voidedReason", "Append-only: insert row only, no update/delete; provides read finders", "Uses ctx.data.moduleData.stock_adjustments"];
        };
    };
    export default stockAdjustmentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockAdjustmentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustmentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockAdjustment.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.defs" {
    export const stockConsumptionTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockConsumption";
            readonly tableName: "stock_consumption";
            readonly columns: readonly [{
                readonly name: "stock_consumption_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique consumption identifier";
            }, {
                readonly name: "stock_item_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to stock item (owner)";
            }, {
                readonly name: "order_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to order";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "consumption status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "quantity, voidedAt, voidReason";
            }];
            readonly primaryKey: readonly ["stock_consumption_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_consumption_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
            }, {
                readonly indexName: "idx_stock_consumption_order_id";
                readonly columns: readonly ["order_id"];
            }, {
                readonly indexName: "idx_stock_consumption_status";
                readonly columns: readonly ["status"];
            }, {
                readonly indexName: "idx_stock_consumption_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly purpose: "controle";
            readonly appendOnly: true;
            readonly retentionDays: 365;
        };
    };
    export default stockConsumptionTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockConsumption__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockConsumptionTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter.defs" {
    export const stockConsumptionRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockConsumptionRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockConsumptionRepositoryAdapter";
            readonly entityId: "StockConsumption";
            readonly portRef: "IStockConsumptionRepository";
            readonly tableRef: "stock_consumptions";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Event StockConsumption <-> stock_consumptions table row", "Real columns: stock_consumption_id, stock_item_id, order_id, status, created_at", "details JSONB contains: quantity, voidedAt, voidReason", "Append-only: insert row only, no update/delete; provides read finders", "Uses ctx.data.moduleData.stock_consumptions"];
        };
    };
    export default stockConsumptionRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockConsumptionRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumptionRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockConsumption.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.defs" {
    export const stockLevelTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StockLevel";
            readonly tableName: "stock_level";
            readonly columns: readonly [{
                readonly name: "stock_level_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "PK – unique stock level identifier";
            }, {
                readonly name: "stock_item_id";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "FK to stock item";
            }, {
                readonly name: "unit";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "unit of measure discriminator";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering timestamp";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "currentQuantity, minimumLevel, lastDecrementAt, lastAdjustmentAt, updatedAt";
            }];
            readonly primaryKey: readonly ["stock_level_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_stock_level_stock_item_id";
                readonly columns: readonly ["stock_item_id"];
            }, {
                readonly indexName: "idx_stock_level_unit";
                readonly columns: readonly ["unit"];
            }, {
                readonly indexName: "idx_stock_level_created_at";
                readonly columns: readonly ["created_at"];
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly purpose: "operational";
            readonly appendOnly: false;
        };
    };
    export default stockLevelTableDefinition;
    export const pipeline: readonly [{
        readonly id: "stockLevel__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const stockLevelTableDef: TableDefinition;
}
declare module "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.defs" {
    export const stockLevelRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StockLevelRepositoryAdapter";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StockLevelRepositoryAdapter";
            readonly entityId: "StockLevel";
            readonly portRef: "IStockLevelRepository";
            readonly tableRef: "stock_levels";
            readonly mdmReads: readonly ["StockItem"];
            readonly notes: readonly ["Domain aggregate StockLevel <-> stock_levels table row", "Real columns: stock_level_id, stock_item_id, unit, created_at", "details JSONB contains: currentQuantity, minimumLevel, lastDecrementAt, lastAdjustmentAt, updatedAt", "MDM ref StockItem resolved via ctx.mdm.collection.getMany/hydrateMany using stock_item_id (bulk load, never in loop)", "Uses ctx.data.moduleData.stock_levels"];
        };
    };
    export default stockLevelRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "stockLevelRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevelRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_1_external/adapters/persistence/stockLevel.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.defs" {
    export const menuItemIngredientRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "MenuItemIngredientRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItemIngredient";
            readonly interfaceName: "IMenuItemIngredientRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: MenuItemIngredientId"];
                readonly returns: "MenuItemIngredient";
                readonly description: "Retrieve a menu item ingredient by its unique identifier";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: MenuItemIngredientFilter"];
                readonly returns: "MenuItemIngredient[]";
                readonly description: "List menu item ingredients matching the given filter";
            }, {
                readonly name: "save";
                readonly params: readonly ["menuItemIngredient: MenuItemIngredient"];
                readonly returns: "void";
                readonly description: "Persist the menu item ingredient aggregate";
            }, {
                readonly name: "findByMenuItemId";
                readonly params: readonly ["menuItemId: MenuItemId"];
                readonly returns: "MenuItemIngredient[]";
                readonly description: "Find ingredient mappings for a specific menu item";
            }, {
                readonly name: "findByIngredientId";
                readonly params: readonly ["ingredientId: IngredientId"];
                readonly returns: "MenuItemIngredient[]";
                readonly description: "Find menu item mappings for a specific ingredient";
            }];
        };
    };
    export default menuItemIngredientRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredientRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/menuItemIngredientRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs" {
    export const orderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "OrderRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly interfaceName: "IOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Order";
                readonly params: readonly ["id: OrderId"];
            }, {
                readonly name: "list";
                readonly returns: "Order[]";
                readonly params: readonly ["filter: OrderFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["order: Order"];
            }, {
                readonly name: "findByOrderNumber";
                readonly returns: "Order | null";
                readonly params: readonly ["orderNumber: OrderNumber"];
            }, {
                readonly name: "listByShiftId";
                readonly returns: "Order[]";
                readonly params: readonly ["shiftId: ShiftId"];
            }];
        };
    };
    export default orderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "orderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.defs" {
    export const shiftClosingReportRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ShiftClosingReportRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftClosingReport";
            readonly interfaceName: "IShiftClosingReportRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "ShiftClosingReport";
                readonly params: readonly ["id: ShiftClosingReportId"];
            }, {
                readonly name: "list";
                readonly returns: "ShiftClosingReport[]";
                readonly params: readonly ["filter: ShiftClosingReportFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["report: ShiftClosingReport"];
            }, {
                readonly name: "findByShiftId";
                readonly returns: "ShiftClosingReport | null";
                readonly params: readonly ["shiftId: ShiftId"];
            }];
        };
    };
    export default shiftClosingReportRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReportRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.defs" {
    export const shiftRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ShiftRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Shift";
            readonly interfaceName: "IShiftRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "Shift";
                readonly params: readonly ["id: ShiftId"];
            }, {
                readonly name: "list";
                readonly returns: "Shift[]";
                readonly params: readonly ["filter: ShiftFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["shift: Shift"];
            }, {
                readonly name: "findOpenShift";
                readonly returns: "Shift | null";
                readonly params: readonly [];
            }, {
                readonly name: "listByDate";
                readonly returns: "Shift[]";
                readonly params: readonly ["date: LocalDate"];
            }];
        };
    };
    export default shiftRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "shiftRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.defs" {
    export const stockAdjustmentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockAdjustmentRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockAdjustment";
            readonly interfaceName: "IStockAdjustmentRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly returns: "void";
                readonly params: readonly ["adjustment: StockAdjustment"];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "StockAdjustment[]";
                readonly params: readonly ["period: DateRange"];
            }, {
                readonly name: "listByProductId";
                readonly returns: "StockAdjustment[]";
                readonly params: readonly ["productId: ProductId"];
            }, {
                readonly name: "listByReason";
                readonly returns: "StockAdjustment[]";
                readonly params: readonly ["reason: AdjustmentReason"];
            }];
        };
    };
    export default stockAdjustmentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockAdjustmentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockAdjustmentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.defs" {
    export const stockConsumptionRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockConsumptionRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockConsumption";
            readonly interfaceName: "IStockConsumptionRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly returns: "void";
                readonly params: readonly ["consumption: StockConsumption"];
            }, {
                readonly name: "listByOwnerId";
                readonly returns: "StockConsumption[]";
                readonly params: readonly ["orderId: OrderId"];
            }, {
                readonly name: "listByPeriod";
                readonly returns: "StockConsumption[]";
                readonly params: readonly ["period: DateRange"];
            }, {
                readonly name: "listByProductId";
                readonly returns: "StockConsumption[]";
                readonly params: readonly ["productId: ProductId"];
            }];
        };
    };
    export default stockConsumptionRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockConsumptionRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.defs" {
    export const stockLevelRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StockLevelRepository";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockLevel";
            readonly interfaceName: "IStockLevelRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "StockLevel";
                readonly params: readonly ["id: StockLevelId"];
            }, {
                readonly name: "list";
                readonly returns: "StockLevel[]";
                readonly params: readonly ["filter: StockLevelFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["stockLevel: StockLevel"];
            }, {
                readonly name: "findByProductId";
                readonly returns: "StockLevel | null";
                readonly params: readonly ["productId: ProductId"];
            }, {
                readonly name: "listLowStock";
                readonly returns: "StockLevel[]";
                readonly params: readonly [];
            }];
        };
    };
    export default stockLevelRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "stockLevelRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.defs" {
    export const browseMenuItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseMenuItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseMenuItems";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "browseMenuItems";
                readonly inputTypeName: "BrowseMenuItemsInput";
                readonly outputTypeName: "BrowseMenuItemsOutput";
                readonly input: readonly [{
                    readonly name: "statusFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filtro opcional por status do item (draft, active, inactive) informado pelo gerente";
                }, {
                    readonly name: "menuCategoryIdFilter";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Filtro opcional por categoria do item informado pelo gerente";
                }];
                readonly output: readonly [{
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Lista de itens do cardápio projetados com: menuItemId, name, description, menuCategoryId, price, itemType, status, activatedAt, createdAt, updatedAt";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["simpleItemsOnly"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver activeCompanyId a partir de ctx.sessionContext.businessContext.activeCompanyId. MODELING GAP: MenuItem não possui campo companyId no modelo MDM — o filtro de escopo por empresa ativa não pode ser aplicado diretamente; registrar a lacuna e seguir sem o filtro de empresa.", "2. Listar todas as entidades MenuItem do MDM via ctx.mdm.collection.listByType({ type: 'MenuItem' }).", "3. Se statusFilter foi informado, filtrar in-memory os itens cujo campo status === statusFilter.", "4. Se menuCategoryIdFilter foi informado, filtrar in-memory os itens cujo campo menuCategoryId === menuCategoryIdFilter.", "5. Aplicar regra simpleItemsOnly: todos os itens (incluindo itemType 'variant') aparecem na lista como entradas separadas — o browse não filtra por itemType; a regra indica que apenas itens simples são plenamente suportados pelo sistema, mas variantes ainda são listadas individualmente.", "6. Projetar cada item para os campos: menuItemId, name, description, menuCategoryId, price, itemType, status, activatedAt, createdAt, updatedAt.", "7. Retornar a coleção projetada no campo items."];
            }];
            readonly mdmRefs: readonly ["MenuItem", "MenuCategory"];
        };
    };
    export default browseMenuItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseMenuItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/browseMenuItems.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.defs" {
    export const browseStockItemsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseStockItems";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseStockItems";
            readonly ports: readonly ["StockLevel"];
            readonly functions: readonly [{
                readonly functionName: "browseStockItems";
                readonly inputTypeName: "BrowseStockItemsInput";
                readonly outputTypeName: "BrowseStockItemsOutput";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Termo de busca opcional para filtrar itens de estoque pelo nome.";
                }];
                readonly output: readonly [{
                    readonly name: "items";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Lista de itens de estoque com nome, unidade, limite mínimo, quantidade atual e flag de alerta de estoque baixo.";
                    readonly ofEntity: "StockItem";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Número total de itens retornados na lista.";
                }];
                readonly ports: readonly ["StockLevel"];
                readonly rulesApplied: readonly ["lowStockAlertCalculation"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver o actorId a partir de ctx.sessionContext para autorização do gerente autenticado.", "2. Listar todos os StockItems do MDM via ctx.mdm.collection.listByType({ type: 'StockItem' }).", "3. Se searchTerm foi informado, filtrar os itens cujo name contém o termo (case-insensitive).", "4. Ordenar os itens resultantes por name em ordem ascendente.", "5. Coletar todos os stockItemId dos itens filtrados e buscar os StockLevels correspondentes em lote através da porta StockLevel (list/find by stockItemId).", "6. Para cada StockItem, localizar seu StockLevel correspondente e aplicar a regra lowStockAlertCalculation: se currentQuantity <= minimumLevel, marcar lowStockAlert = true; caso contrário false.", "7. Montar a lista de saída com stockItemId, name, unit, minimumLevel, createdAt, updatedAt, currentQuantity e lowStockAlert para cada item.", "8. Retornar { items, total } onde total é o número de itens na lista."];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default browseStockItemsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseStockItems__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/browseStockItems.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/closeShift.defs" {
    export const closeShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeShift";
            readonly ports: readonly ["Shift", "Order", "ShiftClosingReport", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "closeShift";
                readonly inputTypeName: "CloseShiftInput";
                readonly outputTypeName: "CloseShiftOutput";
                readonly input: readonly [{
                    readonly name: "totalApurado";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Valor total apurado no fechamento do turno, informado pelo gerente para conferência.";
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Observações gerais sobre o turno, opcionais.";
                    readonly ofEntity: "Shift";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "closedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "closedBy";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "totalApurado";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Shift";
                }];
                readonly ports: readonly ["Shift", "Order", "ShiftClosingReport"];
                readonly rulesApplied: readonly ["singleOpenShift", "shiftClosingRecordsRevenue", "dashboardCurrentShiftOnly"];
                readonly transactional: true;
                readonly steps: readonly ["1. Query Shift port for all shifts with status='open' (resolve activeLifecycleInstance).", "2. Apply rule singleOpenShift: if zero or more than one open shift is found, throw validation error 'closeShift.singleOpenShift: exactly one open shift required'.", "3. Resolve closedBy from ctx.sessionContext.actorId (actorSession).", "4. Resolve closedAt from ctx.clock.now() (systemDefault).", "5. Load the open Shift aggregate via Shift port getById.", "6. Validate the Shift is in 'open' status (guard against race condition).", "7. Mutate the Shift: set status='closed', closedAt=resolved timestamp, closedBy=resolved actor id, totalApurado=input value, notes=input value (or null), updatedAt=ctx.clock.now().", "8. Save the Shift aggregate via Shift port save.", "9. Query Order port for all orders with shiftId=open shift id and status='delivered' to count paid orders (shiftClosingRecordsRevenue context).", "10. Generate shiftClosingReportId via ctx.idGenerator.", "11. Create ShiftClosingReport via ShiftClosingReport port: shiftId, totalApurado (from input), paidOrderCount (count of delivered orders), createdAt=ctx.clock.now(), updatedAt=ctx.clock.now().", "12. Apply rule dashboardCurrentShiftOnly: after closing, no shift remains 'open', so dashboard will show no active shift — this is the expected terminal state.", "13. Return shiftId, status='closed', closedAt, closedBy, totalApurado, notes."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default closeShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "closeShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/closeShift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/closeShift.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs" {
    export const createOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createOrder";
            readonly ports: readonly ["Order", "StockLevel", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "createOrder";
                readonly inputTypeName: "CreateOrderInput";
                readonly outputTypeName: "CreateOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Tipo do pedido: 'table' (consumo na mesa) ou 'takeout' (para viagem)";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Número da mesa; obrigatório quando orderType = 'table', nulo quando orderType = 'takeout'";
                }, {
                    readonly name: "orderItems";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Lista de itens do cardápio selecionados: [{ menuItemId: string, quantity: number }]";
                }, {
                    readonly name: "priority";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Indica se o pedido foi marcado como prioritário no preparo";
                }, {
                    readonly name: "priorityReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Justificativa da priorização; obrigatória quando priority = true";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Identificador único gerado para o novo pedido";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Status inicial do pedido: 'registered'";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Tipo do pedido criado";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Order";
                    readonly description: "Número da mesa (nulo quando takeout)";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Momento de criação do pedido";
                }];
                readonly ports: readonly ["Order", "StockLevel", "Shift"];
                readonly rulesApplied: readonly ["stockDecrementOnOrderLaunch", "orderStatusFlow", "fifoKitchenQueue"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve active shift: query Shift port for status='open'; if none open, throw validation error 'No active shift found for order creation'", "Generate orderId via ctx.idGenerator; set createdAt and updatedAt to ctx.clock.now()", "Validate orderType: if 'table', tableNumber is required (rule orderStatusFlow context); if 'takeout', tableNumber must be null", "Validate priority: if priority=true, priorityReason is required; throw validation error if missing", "Apply orderStatusFlow: set initial status to 'registered' (first state in mandatory flow: registered → received → inPreparation → ready → delivered)", "Collect all menuItemIds from orderItems; fetch MenuItem records from MDM via ctx.mdm.collection.getMany({ mdmIds: menuItemIds })", "Validate all menu items exist and have status='active'; throw validation error for any missing or inactive item", "Fetch ingredient/stock-item relationships for all menu items via ctx.mdm.collection.relatedOfMany({ mdmIds: menuItemIds, relationType: 'ingredient' }) to determine which stock items each menu item consumes", "Aggregate total required quantity per stockItemId across all order items (menu item quantity × ingredient ratio)", "Load StockLevel records from StockLevel port for each stockItemId involved; collect and batch-load", "Apply stockDecrementOnOrderLaunch: for each stock item, verify currentQuantity >= required quantity; if insufficient, throw validation error with stockItemId and shortfall; decrement currentQuantity by consumed amount; set lastDecrementAt to ctx.clock.now()", "Generate orderItemId for each OrderItem via ctx.idGenerator; set unitPrice from MenuItem.price fetched from MDM; set createdAt/updatedAt", "Build StockConsumption records: generate stockConsumptionId via ctx.idGenerator, set orderId, stockItemId, quantity consumed, status='posted', createdAt=ctx.clock.now()", "Apply fifoKitchenQueue: order enters kitchen queue positioned by createdAt (FIFO ordering — earlier createdAt means earlier preparation priority)", "Create Order aggregate with embedded OrderItems and StockConsumption children; set shiftId from resolved active shift, status='registered', orderId, orderType, tableNumber, priority, priorityReason, createdAt, updatedAt", "Save Order aggregate through Order port (includes OrderItem and StockConsumption children) inside transaction", "Save updated StockLevel records through StockLevel port inside same transaction", "Append StockConsumption audit events (status='posted') as part of Order aggregate save through Order port (StockConsumption is child of Order aggregate; port 'StockConsumption' not in provided ports — persisted via Order port)", "Return orderId, status, orderType, tableNumber, createdAt"];
            }];
            readonly mdmRefs: readonly ["MenuItem"];
        };
    };
    export default createOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/createOrder.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/createOrder.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.defs" {
    export const deliverOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deliverOrder";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deliverOrder";
            readonly ports: readonly ["Order", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "deliverOrder";
                readonly inputTypeName: "DeliverOrderInput";
                readonly outputTypeName: "DeliverOrderOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Pedido selecionado pelo atendente no painel para entrega";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "deliveredAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly ofEntity: "Order";
                }];
                readonly ports: readonly ["Order", "StockConsumption"];
                readonly rulesApplied: readonly ["orderStatusFlow", "readyBeforeDelivered"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Order aggregate by orderId via OrderPort.getById(orderId); throw NotFoundError if absent.", "Apply rule readyBeforeDelivered: verify order.status === 'ready'; if not, throw ValidationError with detail { rule: 'readyBeforeDelivered', currentStatus: order.status, expectedStatus: 'ready' }.", "Apply rule orderStatusFlow: verify the transition 'ready' -> 'delivered' is permitted in the status flow enum [registered, received, inPreparation, ready, delivered]; if not allowed, throw ValidationError with detail { rule: 'orderStatusFlow', from: order.status, to: 'delivered' }.", "Mutate the Order in memory: set status = 'delivered', deliveredAt = ctx.clock.now(), updatedAt = ctx.clock.now().", "Persist the updated Order via OrderPort.save(order) inside the transaction.", "Append a StockConsumption audit event record (entityId: StockConsumption, owner: Order, purpose: audit) through the StockConsumption port inside the same transaction, capturing the orderId, previous status 'ready', new status 'delivered', and deliveredAt timestamp.", "Return { orderId, status: 'delivered', deliveredAt, updatedAt }."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default deliverOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "deliverOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/deliverOrder.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.defs" {
    export const manageMenuItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageMenuItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageMenuItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateMenuItem";
                readonly inputTypeName: "UpdateMenuItemInput";
                readonly outputTypeName: "UpdateMenuItemOutput";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identificador do item do cardápio selecionado para edição";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Nome do item do cardápio exibido no POS";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Descrição detalhada do item do cardápio";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Categoria de classificação à qual o item pertence";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Preço de venda do item do cardápio";
                }, {
                    readonly name: "itemType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Tipo do item: deve ser 'simple' nesta fase";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Status do item: rascunho, ativo ou inativo";
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Identificador do item do cardápio atualizado";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Nome do item do cardápio";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Descrição detalhada do item do cardápio";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Categoria de classificação à qual o item pertence";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Preço de venda do item do cardápio";
                }, {
                    readonly name: "itemType";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Tipo do item";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Status do item";
                }, {
                    readonly name: "activatedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Data e hora de ativação do item";
                }, {
                    readonly name: "inactivatedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Data e hora de inativação do item";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MenuItem";
                    readonly description: "Data e hora da última atualização";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["simpleItemsOnly", "menuItemRequiresIngredient"];
                readonly transactional: false;
                readonly steps: readonly ["1. Load the current MenuItem from MDM via ctx.mdm.entity.get({ mdmId: menuItemId }). If not found, throw a validation error 'MenuItem not found'.", "2. Apply rule simpleItemsOnly: validate that itemType === 'simple'. If itemType is 'variant' or any other value, throw validation error with rule id 'simpleItemsOnly' — only simple items are allowed in this phase.", "3. Validate the referenced MenuCategory exists by calling ctx.mdm.entity.get({ mdmId: menuCategoryId }). If not found, throw validation error 'MenuCategory not found'.", "4. Determine status transition by comparing the current MenuItem.status with the input status:", "  4a. If status changes from 'draft' or 'inactive' to 'active', apply rule menuItemRequiresIngredient: query MenuItemIngredient records linked to this MenuItem via ctx.mdm.collection.listByType({ type: 'MenuItemIngredient' }) and filter in memory by menuItemId. If no MenuItemIngredient records are found, throw validation error with rule id 'menuItemRequiresIngredient' — an active MenuItem must have at least one ingredient.", "  4b. If status changes from 'draft' or 'inactive' to 'active', set activatedAt = ctx.clock.now().", "  4c. If status changes from 'active' to 'inactive', set inactivatedAt = ctx.clock.now().", "  4d. If status remains unchanged, preserve existing activatedAt / inactivatedAt values from the loaded entity.", "5. Set updatedAt = ctx.clock.now() (systemDefault, resolved from ctx.clock — never accepted as user input).", "6. Build the update payload with fields: name, description, menuCategoryId, price, itemType, status, activatedAt (if computed), inactivatedAt (if computed), updatedAt.", "7. Persist the update via ctx.mdm.entity.update({ mdmId: menuItemId, details: { name, description, menuCategoryId, price, itemType, status, activatedAt, inactivatedAt, updatedAt } }).", "8. Return the updated MenuItem fields: menuItemId, name, description, menuCategoryId, price, itemType, status, activatedAt, inactivatedAt, updatedAt."];
            }];
            readonly mdmRefs: readonly ["MenuItem", "MenuCategory"];
        };
    };
    export default manageMenuItemUsecase;
    export const pipeline: readonly [{
        readonly id: "manageMenuItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/manageMenuItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.defs" {
    export const manageStockItemUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "manageStockItem";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "manageStockItem";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "manageStockItem";
                readonly inputTypeName: "ManageStockItemInput";
                readonly outputTypeName: "ManageStockItemOutput";
                readonly input: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identificador do item de estoque a ser atualizado, obtido do parâmetro de rota.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Nome do ingrediente editado pelo gerente.";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unidade de medida do ingrediente (kg, liter, portion ou unit).";
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo.";
                }];
                readonly output: readonly [{
                    readonly name: "stockItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Identificador do item de estoque atualizado.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Nome do ingrediente após atualização.";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Unidade de medida após atualização.";
                }, {
                    readonly name: "minimumLevel";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Limite mínimo configurado após atualização.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StockItem";
                    readonly description: "Timestamp da última atualização atribuído pelo sistema.";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["lowStockAlertCalculation"];
                readonly transactional: true;
                readonly steps: readonly ["1. Retrieve the existing StockItem from MDM via ctx.mdm.entity.get({ mdmId: stockItemId }) to confirm it exists and capture current state.", "2. Validate that 'unit' is one of the allowed enum values: kg, liter, portion, unit. If invalid, throw a validation error referencing rule lowStockAlertCalculation.", "3. Validate that 'minimumLevel' is a non-negative number (>= 0). If invalid, throw a validation error referencing rule lowStockAlertCalculation.", "4. Apply rule lowStockAlertCalculation inline: the new minimumLevel value will be the threshold used for all future low-stock alert comparisons against current StockLevel quantities. Ensure minimumLevel is a sensible positive value (> 0) so the alert can trigger; if minimumLevel is 0, log a warning that low-stock alerts will never fire for this item.", "5. Build the update payload: { name, unit, minimumLevel, updatedAt: ctx.clock.now() } and persist via ctx.mdm.entity.update({ mdmId: stockItemId, details: { name, unit, minimumLevel, updatedAt } }).", "6. Read back the updated StockItem via ctx.mdm.entity.get({ mdmId: stockItemId }) to confirm persistence and return the projected output fields: stockItemId, name, unit, minimumLevel, updatedAt."];
            }];
            readonly mdmRefs: readonly ["StockItem"];
        };
    };
    export default manageStockItemUsecase;
    export const pipeline: readonly [{
        readonly id: "manageStockItem__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/manageStockItem.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/openShift.defs" {
    export const openShiftUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "openShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "openShift";
            readonly ports: readonly ["Shift"];
            readonly functions: readonly [{
                readonly functionName: "openShift";
                readonly inputTypeName: "OpenShiftInput";
                readonly outputTypeName: "OpenShiftOutput";
                readonly input: readonly [{
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Shift";
                    readonly description: "Observações gerais opcionais sobre o turno, informadas pelo gerente ao abrir.";
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador único do turno criado.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Situação do turno, sempre 'open' após a criação.";
                }, {
                    readonly name: "openedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Data e hora de abertura do turno.";
                }, {
                    readonly name: "openedBy";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "Identificador do gerente que abriu o turno.";
                }];
                readonly ports: readonly ["Shift"];
                readonly rulesApplied: readonly ["singleOpenShift"];
                readonly transactional: true;
                readonly steps: readonly ["1. Query the Shift port for any existing Shift with status 'open' (singleOpenShift rule). If one is found, reject the operation with a validation error referencing rule 'singleOpenShift'.", "2. Generate a new UUID for shiftId via ctx.idGenerator.", "3. Resolve openedBy from ctx.sessionContext.actorId (actorSession).", "4. Set status = 'open', openedAt = ctx.clock.now(), createdAt = ctx.clock.now(), updatedAt = ctx.clock.now().", "5. Build the Shift aggregate with the provided notes (optional) and all resolved fields; closedAt, closedBy and totalApurado remain null.", "6. Persist the Shift through its port inside a single transaction (ctx.data transaction wrapper).", "7. Return shiftId, status, openedAt, openedBy."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default openShiftUsecase;
    export const pipeline: readonly [{
        readonly id: "openShift__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/openShift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/openShift.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.defs" {
    export const requestAiPromoSuggestionsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "requestAiPromoSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "requestAiPromoSuggestions";
            readonly ports: readonly ["Order", "StockLevel", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "requestAiPromoSuggestions";
                readonly inputTypeName: "RequestAiPromoSuggestionsInput";
                readonly outputTypeName: "AiPromoSuggestion";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "ID do item de menu sugerido para promoção";
                }, {
                    readonly name: "totalQuantitySold";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade total vendida do item nos últimos 7 dias";
                }, {
                    readonly name: "currentStockQuantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade atual em estoque do item";
                }, {
                    readonly name: "stockUnit";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Unidade de medida do estoque (kg, liter, portion, unit)";
                }, {
                    readonly name: "suggestionReason";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Motivo da sugestão derivado do padrão de vendas e nível de estoque";
                }, {
                    readonly name: "suggestedDiscountPercent";
                    readonly type: "number";
                    readonly required: false;
                    readonly description: "Percentual de desconto sugerido com base no volume de vendas e estoque";
                }];
                readonly ports: readonly ["Order", "StockLevel"];
                readonly rulesApplied: readonly ["aiPromoBasedOnLast7Days", "aiConsumesDomainData"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve windowStart = ctx.clock.now() minus 7 days (rule aiPromoBasedOnLast7Days) — this is the analysis window; no user input needed", "Resolve actorId from ctx.sessionContext for audit and permission context", "Query Order port for all orders with createdAt >= windowStart (last 7 days only)", "From each loaded Order aggregate, collect embedded OrderItems and aggregate total quantity by menuItemId across the entire window", "Query StockLevel port for all current stock levels to cross-reference with aggregated sales data (rule aiConsumesDomainData — only domain data from Order, OrderItem, StockLevel is consumed, no external sources)", "Cross-reference: items with high sales volume AND sufficient stock (currentQuantity > minimumLevel) are promo candidates; items with low stock (currentQuantity <= minimumLevel) are excluded to avoid supply constraints", "Compute suggestedDiscountPercent proportional to sales volume and stock surplus — higher volume + higher surplus yields larger suggested discount", "Build the promo suggestion list with menuItemId, totalQuantitySold, currentStockQuantity, stockUnit, suggestionReason, and suggestedDiscountPercent", "Append audit event to StockConsumption port recording the AI suggestion request (actorId, windowStart, suggestionCount) — note: StockConsumption port is referenced by eventWrites but not present in provided ports; this is a modeling gap that should be resolved by adding StockConsumption to ports", "Return the list of promo suggestions as the operation result — no Order, OrderItem, or StockLevel records are modified (strictly read-only)"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default requestAiPromoSuggestionsUsecase;
    export const pipeline: readonly [{
        readonly id: "requestAiPromoSuggestions__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiPromoSuggestions.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.defs" {
    export const requestAiSalesSummaryUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "requestAiSalesSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "requestAiSalesSummary";
            readonly ports: readonly ["Order", "Shift", "StockLevel", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "requestAiSalesSummary";
                readonly inputTypeName: "AiSalesSummaryInput";
                readonly outputTypeName: "AiSalesSummaryOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "ID of the currently open shift used to scope the summary";
                }, {
                    readonly name: "shiftOpenedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Timestamp when the current shift was opened";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total count of orders placed during the current open shift";
                }, {
                    readonly name: "totalRevenue";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of revenue across all orders in the current shift";
                }, {
                    readonly name: "orders";
                    readonly type: "array";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Orders from the current shift projected as {orderId, status, orderType, createdAt, deliveredAt}";
                }, {
                    readonly name: "topSellers";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Top-selling items aggregated from day orders: {menuItemId, totalQuantity, totalRevenue} sorted by totalQuantity descending";
                }, {
                    readonly name: "stockLevels";
                    readonly type: "array";
                    readonly ofEntity: "StockLevel";
                    readonly required: true;
                    readonly description: "Current stock levels projected as {stockItemId, currentQuantity, minimumLevel, unit} for AI consumption";
                }];
                readonly ports: readonly ["Order", "Shift", "StockLevel"];
                readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "aiConsumesDomainData", "topSellersFromDayOrders"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve the active lifecycle instance: query the Shift port for the single Shift with status='open' (rule: dashboardCurrentShiftOnly). If no open shift is found, return an empty summary with shiftId=null, zero counts, and empty arrays — never expose historical or multi-shift data.", "2. Extract the resolved shiftId and shiftOpenedAt from the open Shift record.", "3. Load all Orders for the resolved shiftId via the Order port (list filtered by shiftId). Each Order aggregate includes its embedded OrderItem collection.", "4. Project each Order to {orderId, status, orderType, createdAt, deliveredAt} for the orders output array.", "5. Aggregate OrderItems across all loaded Orders: group by menuItemId, sum quantity into totalQuantity and sum (quantity * unitPrice) into totalRevenue. Sort descending by totalQuantity to produce topSellers (rule: topSellersFromDayOrders).", "6. Compute totalOrders as the count of loaded Orders and totalRevenue as the sum of all OrderItem subtotals.", "7. Load all StockLevel records via the StockLevel port and project each to {stockItemId, currentQuantity, minimumLevel, unit} for the stockLevels output array.", "8. Assemble and return the AiSalesSummaryOutput containing only domain-sourced data — no external APIs, no historical periods, no multi-shift consolidation (rule: aiConsumesDomainData)."];
            }];
            readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "aiConsumesDomainData", "topSellersFromDayOrders"];
            readonly mdmRefs: readonly [];
        };
    };
    export default requestAiSalesSummaryUsecase;
    export const pipeline: readonly [{
        readonly id: "requestAiSalesSummary__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/requestAiSalesSummary.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "aiConsumesDomainData", "topSellersFromDayOrders"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs" {
    export const updateOrderStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateOrderStatus";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateOrderStatus";
            readonly ports: readonly ["Order", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "updateOrderStatus";
                readonly inputTypeName: "UpdateOrderStatusInput";
                readonly outputTypeName: "UpdateOrderStatusOutput";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Pedido selecionado pelo cozinheiro na fila da cozinha";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Novo status que o cozinheiro deseja atribuir ao pedido (inPreparation ou ready)";
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "ID do pedido atualizado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Status confirmado após a atualização";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly ofEntity: "Order";
                    readonly description: "Timestamp da última atualização do registro";
                }];
                readonly ports: readonly ["Order", "Shift", "StockConsumption"];
                readonly rulesApplied: readonly ["orderStatusFlow", "inProgressBeforeReady"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve o turno ativo consultando o port Shift por status='open'; se nenhum turno aberto existir, retorna erro de validação 'Nenhum turno aberto encontrado'", "2. Carrega o pedido pelo orderId através do port Order (getById)", "3. Valida que o pedido pertence ao turno ativo comparando order.shiftId com o shiftId resolvido no passo 1; se não pertencer, retorna erro 'Pedido não pertence ao turno ativo'", "4. Aplica a regra orderStatusFlow: o novo status deve seguir a sequência obrigatória received → inPreparation → ready. Se o status atual for 'received', só permite transição para 'inPreparation'. Se o status atual for 'inPreparation', só permite transição para 'ready'. Qualquer outro salto retorna erro com a regra orderStatusFlow", "5. Aplica a regra inProgressBeforeReady: o pedido só pode ser marcado como 'ready' se o status atual for 'inPreparation'; caso contrário retorna erro com a regra inProgressBeforeReady", "6. Define timestamps via ctx.clock.now(): se o novo status for 'inPreparation', preenche inPreparationAt; se for 'ready', preenche readyAt; sempre atualiza updatedAt", "7. Persiste o pedido atualizado através do port Order (update) dentro da mesma transação", "8. Emite evento StockConsumption (purpose=audit) através do port StockConsumption dentro da mesma transação, registrando a mudança de status do pedido", "9. Retorna orderId, status confirmado e updatedAt"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateOrderStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateOrderStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/updateOrderStatus.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.defs" {
    export const viewDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewDashboard";
            readonly ports: readonly ["Order", "StockLevel", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "viewDashboard";
                readonly inputTypeName: "ViewDashboardInput";
                readonly outputTypeName: "ViewDashboardOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Shift";
                    readonly description: "ID of the currently open shift used to filter all dashboard data";
                }, {
                    readonly name: "totalSales";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of all order totals (quantity * unitPrice across OrderItems) for the current shift";
                }, {
                    readonly name: "orders";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "List of orders in the current shift, each containing orderId, status, orderType, createdAt, shiftId, deliveredAt";
                }, {
                    readonly name: "topSellers";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Top selling menu items aggregated from OrderItems of current shift orders, each containing menuItemId, totalQuantity, totalRevenue";
                }, {
                    readonly name: "lowStockAlerts";
                    readonly type: "array";
                    readonly required: true;
                    readonly description: "Stock items whose currentQuantity is below minimumLevel, each containing stockLevelId, stockItemId, currentQuantity, minimumLevel, unit";
                }];
                readonly ports: readonly ["Order", "StockLevel", "Shift"];
                readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "topSellersFromDayOrders"];
                readonly transactional: false;
                readonly steps: readonly ["1. Extract actorId from ctx.sessionContext for authorization (context: actorSession)", "2. Resolve the active shift by querying the Shift port for status='open' (context: activeLifecycleInstance). If multiple open shifts exist, use the most recent by openedAt; if none open, return empty dashboard with shiftId=null, totalSales=0, orders=[], topSellers=[], lowStockAlerts=[] (rule dashboardCurrentShiftOnly)", "3. Load all Orders for the resolved shiftId via Order port (list filtered by shiftId). Orders include their embedded OrderItem children", "4. Extract all OrderItems from the loaded Orders", "5. Calculate totalSales as the sum of (quantity * unitPrice) across all OrderItems of the current shift orders (rule topSellersFromDayOrders)", "6. Aggregate OrderItems by menuItemId to compute topSellers: for each menuItemId sum quantity into totalQuantity and sum (quantity * unitPrice) into totalRevenue; sort descending by totalQuantity (rule topSellersFromDayOrders)", "7. Load all StockLevels via StockLevel port (list all)", "8. Filter StockLevels where currentQuantity < minimumLevel to build lowStockAlerts, each containing stockLevelId, stockItemId, currentQuantity, minimumLevel, unit", "9. Build and return the dashboard projection: shiftId, totalSales, orders (each with orderId, status, orderType, createdAt, shiftId, deliveredAt), topSellers, lowStockAlerts", "10. No events are emitted — this is a read-only view operation (opKind=view, writes=[]); the StockConsumption audit event in eventWrites applies only to mutating usecases"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockLevelRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.defs" {
    export const viewKitchenBoardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewKitchenBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewKitchenBoard";
            readonly ports: readonly ["Order", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "viewKitchenBoard";
                readonly inputTypeName: "ViewKitchenBoardInput";
                readonly outputTypeName: "ViewKitchenBoardOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Identificador único do pedido";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Status atual do pedido (received ou inPreparation)";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Tipo do pedido: table ou takeout";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: false;
                    readonly description: "Número da mesa quando orderType=table";
                }, {
                    readonly name: "priority";
                    readonly type: "boolean";
                    readonly ofEntity: "Order";
                    readonly required: false;
                    readonly description: "Indica se o pedido é prioritário";
                }, {
                    readonly name: "priorityReason";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: false;
                    readonly description: "Motivo da prioridade quando priority=true";
                }, {
                    readonly name: "receivedAt";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: false;
                    readonly description: "Data/hora em que o pedido foi recebido pela cozinha";
                }, {
                    readonly name: "inPreparationAt";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: false;
                    readonly description: "Data/hora em que o pedido entrou em preparação";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Data/hora de criação do pedido";
                }, {
                    readonly name: "orderItems";
                    readonly type: "OrderItem[]";
                    readonly ofEntity: "OrderItem";
                    readonly required: true;
                    readonly description: "Itens do pedido com orderItemId, menuItemId, quantity e unitPrice";
                }];
                readonly ports: readonly ["Order", "Shift"];
                readonly rulesApplied: readonly ["fifoKitchenQueue", "dashboardCurrentShiftOnly"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver o turno ativo: consultar o port Shift listando por status='open' para obter o shiftId do único turno aberto (activeLifecycleInstance). Se nenhum turno estiver aberto, retornar lista vazia.", "2. Aplicar regra dashboardCurrentShiftOnly: filtrar pedidos do port Order pelo shiftId resolvido no passo 1, garantindo que apenas pedidos do turno atual sejam exibidos.", "3. Aplicar filtro de status (systemDefault): restringir a lista aos pedidos cujo status seja 'received' ou 'inPreparation', excluindo pedidos 'registered', 'ready' ou 'delivered'.", "4. Aplicar regra fifoKitchenQueue: ordenar os pedidos colocando primeiro os com priority=true (destaque) e dentro de cada grupo ordenar por receivedAt em ordem crescente (FIFO).", "5. Projetar os campos de saída de cada Order (orderId, status, orderType, tableNumber, priority, priorityReason, receivedAt, inPreparationAt, createdAt) e incluir os OrderItems embarcados no agregado Order (orderItemId, menuItemId, quantity, unitPrice).", "6. Retornar a lista de pedidos projetada como coleção de ViewKitchenBoardOutput."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewKitchenBoardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewKitchenBoard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewKitchenBoard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.defs" {
    export const viewOrderBoardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewOrderBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewOrderBoard";
            readonly ports: readonly ["Order", "Shift", "StockConsumption"];
            readonly functions: readonly [{
                readonly functionName: "viewOrderBoard";
                readonly inputTypeName: "ViewOrderBoardInput";
                readonly outputTypeName: "ViewOrderBoardOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "orders";
                    readonly type: "Order[]";
                    readonly ofEntity: "Order";
                    readonly required: true;
                    readonly description: "Pedidos do turno atual aberto, ordenados por createdAt crescente (FIFO)";
                }, {
                    readonly name: "currentShiftId";
                    readonly type: "string";
                    readonly ofEntity: "Shift";
                    readonly required: false;
                    readonly description: "ID do turno aberto resolvido em runtime; ausente quando nenhum turno está aberto";
                }];
                readonly ports: readonly ["Order", "Shift"];
                readonly rulesApplied: readonly ["dashboardCurrentShiftOnly", "fifoKitchenQueue", "orderStatusFlow"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolver o turno atualmente aberto consultando o port Shift por status='open' (regra dashboardCurrentShiftOnly)", "2. Se nenhum turno aberto for encontrado, retornar lista vazia sem erro (regra dashboardCurrentShiftOnly)", "3. Consultar o port Order filtrando por shiftId igual ao shiftId do turno aberto resolvido no passo 1", "4. Ordenar os resultados por Order.createdAt em ordem crescente (regra fifoKitchenQueue)", "5. Validar que cada Order.status pertence ao enum permitido [registered, received, inPreparation, ready, delivered] (regra orderStatusFlow); pedidos com status inválido são filtrados e não exibidos", "6. Projetar os campos orderId, status, orderType, tableNumber, priority, priorityReason, receivedAt, inPreparationAt, readyAt, createdAt para cada pedido", "7. Retornar a lista projetada junto com o currentShiftId resolvido"];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewOrderBoardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewOrderBoard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewOrderBoard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/orderRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/stockConsumptionRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/order.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.defs" {
    export const viewShiftClosingReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewShiftClosingReport";
            readonly ports: readonly ["ShiftClosingReport", "Shift"];
            readonly functions: readonly [{
                readonly functionName: "viewShiftClosingReport";
                readonly inputTypeName: "ViewShiftClosingReportInput";
                readonly outputTypeName: "ViewShiftClosingReportOutput";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Identificador do turno fechado cujo relatório de fechamento será exibido.";
                }];
                readonly output: readonly [{
                    readonly name: "shiftClosingReportId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Identificador único do relatório de fechamento.";
                }, {
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Identificador do turno ao qual o relatório pertence.";
                }, {
                    readonly name: "totalApurado";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Total apurado do turno — soma da receita registrada conforme a regra shiftClosingRecordsRevenue.";
                }, {
                    readonly name: "paidOrderCount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Quantidade de pedidos pagos consolidados no período do turno conforme a regra shiftClosingConsolidatesPaidOrders.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Data e hora de criação do relatório.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ShiftClosingReport";
                    readonly description: "Data e hora da última atualização do relatório.";
                }];
                readonly ports: readonly ["ShiftClosingReport", "Shift"];
                readonly rulesApplied: readonly ["shiftClosingRecordsRevenue", "shiftClosingConsolidatesPaidOrders"];
                readonly transactional: false;
                readonly steps: readonly ["1. Load the Shift aggregate via Shift port using shiftId to verify the shift exists and its status is 'closed' — a closing report is only available for a closed shift.", "2. If the Shift is not found, return a validation error indicating the shift does not exist.", "3. If the Shift status is not 'closed', return a validation error indicating the closing report is only available for closed shifts (rule: shiftClosingRecordsRevenue requires a finalized shift).", "4. Load the ShiftClosingReport aggregate via ShiftClosingReport port using shiftId as the key field (getById pattern).", "5. If no ShiftClosingReport is found for the given shiftId, return an empty/not-found result.", "6. Verify the returned report's totalApurado reflects the revenue recorded for the shift (rule: shiftClosingRecordsRevenue) and paidOrderCount consolidates only paid orders (rule: shiftClosingConsolidatesPaidOrders) — these invariants were enforced at report creation; on read, validate that totalApurado >= 0 and paidOrderCount >= 0, returning a data-integrity error otherwise.", "7. Return the ShiftClosingReport fields: shiftClosingReportId, shiftId, totalApurado, paidOrderCount, createdAt, updatedAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewShiftClosingReportUsecase;
    export const pipeline: readonly [{
        readonly id: "viewShiftClosingReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_2_application/usecases/viewShiftClosingReport.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l1/cafeFlow/layer_2_application/ports/shiftClosingReportRepository.d.ts", "_102051_/l1/cafeFlow/layer_2_application/ports/shiftRepository.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.d.ts", "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.defs" {
    export const menuItemIngredientDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "MenuItemIngredient";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MenuItemIngredient";
            readonly fields: readonly [{
                readonly fieldId: "menuItemIngredientId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do vínculo entre item de cardápio e ingrediente de estoque.";
            }, {
                readonly fieldId: "menuItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de cardápio ao qual este ingrediente está vinculado.";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de estoque master consumido quando o item de cardápio é pedido.";
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade do ingrediente consumida a cada pedido do item de cardápio.";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida da quantidade consumida do ingrediente.";
                readonly enum: readonly ["kg", "gram", "liter", "milliliter", "portion", "unit"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do vínculo de ingrediente.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do vínculo de ingrediente.";
            }];
            readonly statusEnum: readonly [];
            readonly valueObjects: readonly [];
            readonly invariants: readonly ["quantity deve ser maior que zero", "A unidade do vínculo deve ser compatível com a unidade do item de estoque referenciado", "Não pode haver mais de um vínculo entre o mesmo menuItemId e stockItemId"];
        };
    };
    export default menuItemIngredientDomainEntity;
    export const pipeline: readonly [{
        readonly id: "menuItemIngredient__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/menuItemIngredient.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/order.defs" {
    export const orderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Order";
            readonly fields: readonly [{
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do pedido";
            }, {
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Turno aberto no momento do lançamento do pedido";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Status atual do pedido no fluxo de acompanhamento";
                readonly enum: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
            }, {
                readonly fieldId: "orderType";
                readonly type: "string";
                readonly required: true;
                readonly description: "Tipo do pedido: consumo na mesa ou para viagem";
                readonly enum: readonly ["table", "takeout"];
            }, {
                readonly fieldId: "tableNumber";
                readonly type: "string";
                readonly required: false;
                readonly description: "Número da mesa quando o pedido é do tipo mesa";
            }, {
                readonly fieldId: "priority";
                readonly type: "boolean";
                readonly required: false;
                readonly description: "Indica se o pedido recebeu priorização no preparo fora da ordem de chegada";
            }, {
                readonly fieldId: "priorityReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Justificativa para a priorização do pedido fora da ordem de chegada";
            }, {
                readonly fieldId: "receivedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o pedido foi recebido pela cozinha";
            }, {
                readonly fieldId: "inPreparationAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o cozinheiro iniciou o preparo do pedido";
            }, {
                readonly fieldId: "readyAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o pedido foi marcado como pronto pela cozinha";
            }, {
                readonly fieldId: "deliveredAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Momento em que o pedido foi entregue ao cliente";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Momento de criação do registro do pedido";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Momento da última atualização do registro do pedido";
            }];
            readonly statusEnum: readonly ["registered", "received", "inPreparation", "ready", "delivered"];
            readonly invariants: readonly ["tableNumber is required when orderType is 'table'", "tableNumber must be null when orderType is 'takeout'", "priorityReason is required when priority is true", "Status transitions must follow the sequence: registered → received → inPreparation → ready → delivered", "receivedAt must be set when status transitions to 'received'", "inPreparationAt must be set when status transitions to 'inPreparation'", "readyAt must be set when status transitions to 'ready'", "deliveredAt must be set when status transitions to 'delivered'", "Order must belong to a shift whose status is 'open'", "Order must contain at least one OrderItem", "Timestamps must be chronologically ordered: receivedAt ≤ inPreparationAt ≤ readyAt ≤ deliveredAt"];
            readonly valueObjects: readonly [{
                readonly name: "OrderItem";
                readonly fields: readonly [{
                    readonly fieldId: "orderItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador único da linha do pedido.";
                }, {
                    readonly fieldId: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao pedido ao qual esta linha pertence.";
                }, {
                    readonly fieldId: "menuItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Referência ao item do cardápio cadastrado que foi solicitado.";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantidade solicitada do item do cardápio nesta linha do pedido.";
                }, {
                    readonly fieldId: "unitPrice";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Preço unitário do item no momento do lançamento do pedido, snapshot para fins de fechamento.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora em que a linha do pedido foi criada.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Data e hora da última atualização da linha do pedido.";
                }];
                readonly collection: true;
            }];
        };
    };
    export default orderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "order__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/order.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/order.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.defs" {
    export const shiftDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Shift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Shift";
            readonly fields: readonly [{
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do turno";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do turno";
                readonly enum: readonly ["open", "closed"];
            }, {
                readonly fieldId: "openedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de abertura do turno pelo gerente";
            }, {
                readonly fieldId: "closedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora de fechamento do turno";
            }, {
                readonly fieldId: "openedBy";
                readonly type: "string";
                readonly required: true;
                readonly description: "Identificador do gerente que abriu o turno";
            }, {
                readonly fieldId: "closedBy";
                readonly type: "string";
                readonly required: false;
                readonly description: "Identificador do gerente que fechou o turno";
            }, {
                readonly fieldId: "totalApurado";
                readonly type: "money";
                readonly required: false;
                readonly description: "Valor total apurado no fechamento do turno para conferência, sem conciliação bancária";
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Observações gerais sobre o turno";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do registro";
            }];
            readonly statusEnum: readonly ["open", "closed"];
            readonly invariants: readonly ["closedAt is required when status is 'closed'", "closedBy is required when status is 'closed'", "closedAt must be after openedAt", "A closed shift cannot be reopened", "totalApurado is required when status is 'closed'", "Only one shift may be open at a time"];
            readonly valueObjects: readonly [];
        };
    };
    export default shiftDomainEntity;
    export const pipeline: readonly [{
        readonly id: "shift__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/shift.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.defs" {
    export const shiftClosingReportDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "ShiftClosingReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ShiftClosingReport";
            readonly fields: readonly [{
                readonly fieldId: "shiftClosingReportId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do relatório de fechamento de turno.";
            }, {
                readonly fieldId: "shiftId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao turno fechado ao qual este relatório corresponde.";
            }, {
                readonly fieldId: "totalApurado";
                readonly type: "money";
                readonly required: true;
                readonly description: "Valor total apurado no fechamento do turno para conferência do gerente.";
            }, {
                readonly fieldId: "paidOrderCount";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade de pedidos pagos consolidados no período do turno.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora em que o relatório de fechamento foi gerado.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do relatório de fechamento.";
            }];
            readonly invariants: readonly ["Referenced shift must have status 'closed' before generating the report", "totalApurado must be >= 0", "paidOrderCount must be >= 0", "Only one ShiftClosingReport per shift"];
            readonly valueObjects: readonly [];
        };
    };
    export default shiftClosingReportDomainEntity;
    export const pipeline: readonly [{
        readonly id: "shiftClosingReport__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/shiftClosingReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.defs" {
    export const stockAdjustmentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockAdjustment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockAdjustment";
            readonly fields: readonly [{
                readonly fieldId: "stockAdjustmentId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do ajuste de estoque.";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Item de estoque ao qual o ajuste se aplica.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação do ajuste: lançado ou anulado.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade ajustada, positiva para reposição e negativa para correção ou baixa.";
            }, {
                readonly fieldId: "reason";
                readonly type: "text";
                readonly required: true;
                readonly description: "Motivo do ajuste informado pelo gerente ao registrar a reposição ou correção.";
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o ajuste foi anulado.";
            }, {
                readonly fieldId: "voidedReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo da anulação do ajuste de estoque.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro do ajuste.";
            }];
            readonly statusEnum: readonly ["posted", "voided"];
            readonly invariants: readonly [];
            readonly valueObjects: readonly [];
        };
    };
    export default stockAdjustmentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockAdjustment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.defs" {
    export const stockConsumptionDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockConsumption";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockConsumption";
            readonly fields: readonly [{
                readonly fieldId: "stockConsumptionId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do consumo de estoque.";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Item de estoque cuja quantidade foi decrementada por este consumo.";
            }, {
                readonly fieldId: "orderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Pedido que disparou este consumo de estoque no momento do lançamento.";
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade do item de estoque consumida e decrementada neste lançamento.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação do consumo: lançado ou estornado.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora do registro do consumo de estoque.";
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora em que o consumo foi estornado, quando aplicável.";
            }, {
                readonly fieldId: "voidReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Motivo do estorno do consumo de estoque.";
            }];
            readonly statusEnum: readonly ["posted", "voided"];
            readonly invariants: readonly [];
            readonly valueObjects: readonly [];
        };
    };
    export default stockConsumptionDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockConsumption__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockConsumption.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.defs" {
    export const stockLevelDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StockLevel";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StockLevel";
            readonly fields: readonly [{
                readonly fieldId: "stockLevelId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador único do nível de estoque";
            }, {
                readonly fieldId: "stockItemId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Referência ao item de estoque master ao qual este nível pertence";
            }, {
                readonly fieldId: "currentQuantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade atual disponível em estoque, decrementada por consumos e ajustada por reposições";
            }, {
                readonly fieldId: "minimumLevel";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantidade mínima configurada para disparar o alerta de estoque baixo";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unidade de medida do estoque do ingrediente";
                readonly enum: readonly ["kg", "liter", "portion", "unit"];
            }, {
                readonly fieldId: "lastDecrementAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do último decremento de estoque por lançamento de pedido";
            }, {
                readonly fieldId: "lastAdjustmentAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Data e hora do último ajuste manual de reposição de estoque";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora de criação do registro de nível de estoque";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Data e hora da última atualização do nível de estoque";
            }];
            readonly invariants: readonly ["currentQuantity must be >= 0", "minimumLevel must be >= 0", "Low-stock alert is triggered when currentQuantity <= minimumLevel", "unit cannot be changed after creation"];
            readonly valueObjects: readonly [];
        };
    };
    export default stockLevelDomainEntity;
    export const pipeline: readonly [{
        readonly id: "stockLevel__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.ts";
        readonly defPath: "_102051_/l1/cafeFlow/layer_3_domain/entities/stockLevel.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102051_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    /**
     * Design system do projeto — vocabulário de tokens POR PAPEL (role-based).
     * Este vocabulário é o padrão para novos projetos; só os VALORES mudam por marca.
     *
     * Regras de nomenclatura (color):
     *  - O nome diz onde o token é usado; nunca deduza pelo valor.
     *  - Pares bg/text andam juntos: quem usa button-primary-bg escreve o rótulo
     *    com button-primary-text; quem usa status-error-bg usa status-error-text;
     *    nav-bg com nav-text; tooltip-bg com tooltip-text. Vale para todo par
     *    <papel>-bg / <papel>-text.
     *  - Superfícies: page-bg (fundo da página) > surface-bg (cards, painéis,
     *    modais) > surface-alt-bg (linhas zebradas, hover de linha, skeleton,
     *    cabeçalhos de seção). Texto sobre superfícies: text-strong (títulos),
     *    text-default (corpo), text-muted (secundário/placeholder).
     *  - Navegação (sidebar/topbar): nav-bg + nav-text; item ativo usa
     *    nav-active-bg + nav-active-text.
     *  - Overlay de modal: overlay-backdrop-bg atrás, surface-bg no modal.
     *  - Gráficos: séries usam chart-series-1..6 SEMPRE nesta ordem fixa (a ordem
     *    é o mecanismo de segurança para daltonismo — nunca embaralhar nem gerar
     *    cores novas); textos e eixos usam os tokens text-*, nunca a cor da série;
     *    status-* são reservados a estado e nunca viram série de gráfico.
     *  - Todo token base de cor tem as variantes -hover, -focus e -disabled
     *    (em chart-series, -disabled é a série apagada pela legenda).
     *  - Modo noite: cada chave tem par com prefixo _dark- (mesmo nome). O
     *    compilador gera o bloco dark automaticamente; paginas usam so o nome base.
     */
    export const tokens: IDesignSystemTokens[];
}
declare module "_102051_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.defs" {
    export const definition: ({
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: any[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    } | {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: any[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    })[];
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/kitchenQueue" {
    export interface CafeFlowViewKitchenBoardInput {
    }
    export interface CafeFlowViewKitchenBoardOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        priority: boolean;
        priorityReason: string;
        receivedAt: string;
        inPreparationAt: string;
        createdAt: string;
    }
    export interface CafeFlowViewKitchenBoardOutput {
        items: CafeFlowViewKitchenBoardOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowUpdateOrderStatusInput {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
    }
    export interface CafeFlowUpdateOrderStatusOutput {
    }
}
declare module "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/managerDashboard.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: any[];
        output: ({
            name: string;
            type: string;
            enum: string[];
            description: string;
        } | {
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "managerDashboard__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/managerDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/managerDashboard.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/managerDashboard" {
    export interface CafeFlowViewDashboardInput {
    }
    export interface CafeFlowViewDashboardOutputItem {
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        createdAt: string;
        shiftId: string;
        deliveredAt: string;
    }
    export type CafeFlowViewDashboardOutput = CafeFlowViewDashboardOutputItem[];
    export interface CafeFlowRequestAiSalesSummaryInput {
    }
    export interface CafeFlowRequestAiSalesSummaryOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        createdAt: string;
        deliveredAt: string;
    }
    export type CafeFlowRequestAiSalesSummaryOutput = CafeFlowRequestAiSalesSummaryOutputItem[];
    export interface CafeFlowRequestAiPromoSuggestionsInput {
    }
    export interface CafeFlowRequestAiPromoSuggestionsOutputItem {
        orderId: string;
        orderType: "table" | "takeout";
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        createdAt: string;
    }
    export type CafeFlowRequestAiPromoSuggestionsOutput = CafeFlowRequestAiPromoSuggestionsOutputItem[];
}
declare module "_102051_/l2/cafeFlow/web/contracts/managerDashboard.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/menuManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "menuManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/menuManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/menuManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/menuManagement" {
    export interface CafeFlowBrowseMenuItemsInput {
        statusFilter?: "draft" | "active" | "inactive";
        menuCategoryIdFilter?: string;
    }
    export interface CafeFlowBrowseMenuItemsOutputItem {
        menuItemId: string;
        name: string;
        description: string;
        menuCategoryId: string;
        price: number;
        itemType: "simple" | "variant";
        status: "draft" | "active" | "inactive";
        activatedAt: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface CafeFlowBrowseMenuItemsOutput {
        items: CafeFlowBrowseMenuItemsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowManageMenuItemInput {
        menuItemId: string;
        name: string;
        description?: string;
        menuCategoryId: string;
        price: number;
        itemType: "simple" | "variant";
        status: "draft" | "active" | "inactive";
    }
    export interface CafeFlowManageMenuItemOutput {
        menuItemId: string;
        name: string;
        description: string;
        menuCategoryId: string;
        price: number;
        itemType: "simple" | "variant";
        status: "draft" | "active" | "inactive";
        activatedAt: string;
        inactivatedAt: string;
        updatedAt: string;
    }
}
declare module "_102051_/l2/cafeFlow/web/contracts/menuManagement.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/posWorkspace.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        } | {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "posWorkspace__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/posWorkspace.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/posWorkspace.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/posWorkspace" {
    export interface CafeFlowCreateOrderInput {
        orderType: "table" | "takeout";
        tableNumber?: string;
        orderItems: string;
        priority?: boolean;
        priorityReason?: string;
    }
    export interface CafeFlowCreateOrderOutput {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        createdAt: string;
    }
    export interface CafeFlowViewOrderBoardInput {
    }
    export interface CafeFlowViewOrderBoardOutputItem {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        orderType: "table" | "takeout";
        tableNumber: string;
        priority: boolean;
        priorityReason: string;
        receivedAt: string;
        inPreparationAt: string;
        readyAt: string;
        createdAt: string;
    }
    export interface CafeFlowViewOrderBoardOutput {
        items: CafeFlowViewOrderBoardOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowDeliverOrderInput {
        orderId: string;
    }
    export interface CafeFlowDeliverOrderOutput {
        orderId: string;
        status: "registered" | "received" | "inPreparation" | "ready" | "delivered";
        deliveredAt: string;
        updatedAt: string;
    }
}
declare module "_102051_/l2/cafeFlow/web/contracts/posWorkspace.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/shiftManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: {
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
        }[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/shiftManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/shiftManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/shiftManagement" {
    export interface CafeFlowOpenShiftInput {
        notes?: string;
    }
    export interface CafeFlowOpenShiftOutput {
        shiftId: string;
        status: "open" | "closed";
        openedAt: string;
        openedBy: string;
    }
    export interface CafeFlowCloseShiftInput {
        totalApurado: number;
        notes?: string;
    }
    export interface CafeFlowCloseShiftOutput {
        status: "open" | "closed";
        closedAt: string;
        closedBy: string;
        totalApurado: number;
        notes: string;
    }
    export interface CafeFlowViewShiftClosingReportInput {
        shiftId: string;
    }
    export interface CafeFlowViewShiftClosingReportOutputItem {
        shiftClosingReportId: string;
        shiftId: string;
        totalApurado: number;
        paidOrderCount: number;
        createdAt: string;
        updatedAt: string;
    }
    export type CafeFlowViewShiftClosingReportOutput = CafeFlowViewShiftClosingReportOutputItem;
}
declare module "_102051_/l2/cafeFlow/web/contracts/shiftManagement.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/contracts/stockManagement.defs" {
    export const definition: {
        commandName: string;
        bffName: string;
        routeKey: string;
        purpose: string;
        kind: string;
        outputShape: string;
        input: ({
            name: string;
            type: string;
            required: boolean;
            description: string;
            source: string;
            presentation: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            required: boolean;
            enum: string[];
            description: string;
            source: string;
            presentation: string;
        })[];
        output: ({
            name: string;
            type: string;
            description: string;
            enum?: undefined;
        } | {
            name: string;
            type: string;
            enum: string[];
            description: string;
        })[];
        origin: {
            source: string;
            ownerId: string;
            operationId: string;
            defPath: string;
            bffName: string;
        };
    }[];
    export const pipeline: readonly [{
        readonly id: "stockManagement__l2_contract";
        readonly type: "l2_contract";
        readonly outputPath: "_102051_/l2/cafeFlow/web/contracts/stockManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/contracts/stockManagement.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/contracts/stockManagement" {
    export interface CafeFlowBrowseStockItemsInput {
        searchTerm?: string;
    }
    export interface CafeFlowBrowseStockItemsOutputItem {
        stockItemId: string;
        name: string;
        unit: "kg" | "liter" | "portion" | "unit";
        minimumLevel: number;
        createdAt: string;
        updatedAt: string;
    }
    export interface CafeFlowBrowseStockItemsOutput {
        items: CafeFlowBrowseStockItemsOutputItem[];
        total: number;
        page?: number;
        pageSize?: number;
    }
    export interface CafeFlowManageStockItemInput {
        stockItemId: string;
        name: string;
        unit: "kg" | "liter" | "portion" | "unit";
        minimumLevel: number;
    }
    export interface CafeFlowManageStockItemOutput {
        stockItemId: string;
        name: string;
        unit: "kg" | "liter" | "portion" | "unit";
        minimumLevel: number;
        updatedAt: string;
    }
}
declare module "_102051_/l2/cafeFlow/web/contracts/stockManagement.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: any[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: any[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/kitchenQueue.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/kitchenQueue.ts", "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/kitchenQueue" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewKitchenBoardOutput, CafeFlowUpdateOrderStatusOutput } from "_102051_/l2/cafeFlow/web/contracts/kitchenQueue";
    const message_pt: {
        "page.title": string;
        "section.kitchenBoard.title": string;
        "section.orderTransition.title": string;
        "intention.boardList.title": string;
        "intention.transitionForm.title": string;
        "empty.kitchenBoard": string;
        "empty.transitionPanel": string;
        "field.orderId": string;
        "field.status": string;
        "field.orderType": string;
        "field.tableNumber": string;
        "field.priority": string;
        "field.priorityReason": string;
        "field.receivedAt": string;
        "field.inPreparationAt": string;
        "field.createdAt": string;
        "action.selectOrder": string;
        "action.updateOrderStatus.submit": string;
        "action.updateOrderStatus.success": string;
        "action.updateOrderStatus.error": string;
        "sec.kitchen.board.title": string;
        "org.kitchen.board.title": string;
        "sec.transition.title": string;
        "org.transition.panel.title": string;
        "section.discover.title": string;
        "section.discover.empty": string;
        "section.execute.title": string;
        "section.review.title": string;
        "field.orderId.label": string;
        "field.status.label": string;
        "field.orderType.label": string;
        "field.tableNumber.label": string;
        "field.priority.label": string;
        "field.priorityReason.label": string;
        "field.receivedAt.label": string;
        "field.inPreparationAt.label": string;
        "field.createdAt.label": string;
        "filter.status.label": string;
        "action.viewKitchenBoard.label": string;
        "action.updateOrderStatus.label": string;
        "action.selectOrder.label": string;
        "status.received.label": string;
        "status.inPreparation.label": string;
        "status.ready.label": string;
        "status.delivered.label": string;
        "status.registered.label": string;
        "sec.discover.title": string;
        "sec.execute.title": string;
        "org.update.status.title": string;
        "sec.review.title": string;
        "org.review.title": string;
        "section.queue.title": string;
        "section.queue.empty": string;
        "section.transition.title": string;
        "section.transition.empty": string;
        "column.orderId": string;
        "column.status": string;
        "column.orderType": string;
        "column.tableNumber": string;
        "column.priority": string;
        "column.priorityReason": string;
        "column.receivedAt": string;
        "column.inPreparationAt": string;
        "column.createdAt": string;
        "action.select": string;
        "action.refresh": string;
        "action.updateOrderStatus": string;
        "sec.kitchen.queue.title": string;
        "sec.order.transition.title": string;
        "org.status.transition.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowKitchenQueueBase extends CollabLitElement {
        status: string;
        viewKitchenBoardState: 'idle' | 'loading' | 'success' | 'error';
        viewKitchenBoardData: CafeFlowViewKitchenBoardOutput;
        updateOrderStatusState: 'idle' | 'loading' | 'success' | 'error';
        updateOrderStatusOrderId: string;
        updateOrderStatusStatus: string;
        updateOrderStatusOutput: CafeFlowUpdateOrderStatusOutput | null;
        updateOrderStatusError: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadViewKitchenBoard(): Promise<void>;
        handleViewKitchenBoardClick(_e: Event): void;
        updateOrderStatus(): Promise<void>;
        handleUpdateOrderStatusClick(_e: Event): void;
        setUpdateOrderStatusOrderId(value: string): void;
        handleUpdateOrderStatusOrderIdChange(e: Event): void;
        setUpdateOrderStatusStatus(value: string): void;
        handleUpdateOrderStatusStatusChange(e: Event): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/kitchenQueue" {
    import { CafeFlowKitchenQueueBase } from "_102051_/l2/cafeFlow/web/shared/kitchenQueue";
    export class CafeFlowDesktopPage11KitchenQueuePage extends CafeFlowKitchenQueueBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: any[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/managerDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/managerDashboard.ts", "_102051_/l2/cafeFlow/web/contracts/managerDashboard.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/managerDashboard" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowViewDashboardOutput, CafeFlowRequestAiSalesSummaryOutput, CafeFlowRequestAiPromoSuggestionsOutput } from "_102051_/l2/cafeFlow/web/contracts/managerDashboard";
    const message_pt: {
        "page.title": string;
        "section.dashboard.title": string;
        "section.aiAssistant.title": string;
        "organism.dashboardMetrics.title": string;
        "organism.aiSalesSummary.title": string;
        "organism.aiPromoSuggestions.title": string;
        "column.status": string;
        "column.orderType": string;
        "column.createdAt": string;
        "column.shiftId": string;
        "column.deliveredAt": string;
        "column.orderId": string;
        "action.viewDashboard.label": string;
        "action.requestAiSalesSummary.label": string;
        "action.requestAiPromoSuggestions.label": string;
        "empty.viewDashboard": string;
        "empty.requestAiSalesSummary": string;
        "empty.requestAiPromoSuggestions": string;
        "sec.dashboard.title": string;
        "org.dashboard.metrics.title": string;
        "sec.ai.assistant.title": string;
        "org.ai.sales.summary.title": string;
        "org.ai.promo.suggestions.title": string;
        "section.dashboardList.title": string;
        "section.aiAssistant.empty": string;
        "organism.dashboardOrdersList.title": string;
        "organism.dashboardOrdersList.empty": string;
        "organism.aiSalesSummary.empty": string;
        "organism.aiPromoSuggestions.empty": string;
        "sec.dashboard.list.title": string;
        "org.dashboard.orders.title": string;
        "section.discover.title": string;
        "section.review.title": string;
        "organism.dashboard.title": string;
        "organism.dashboard.empty": string;
        "organism.aiSales.title": string;
        "organism.aiSales.empty": string;
        "organism.aiPromo.title": string;
        "organism.aiPromo.empty": string;
        "organism.review.title": string;
        "organism.review.empty": string;
        "field.status.label": string;
        "field.orderType.label": string;
        "field.createdAt.label": string;
        "field.shiftId.label": string;
        "field.deliveredAt.label": string;
        "field.orderId.label": string;
        "action.viewDashboard.success": string;
        "action.viewDashboard.error": string;
        "action.requestAiSalesSummary.success": string;
        "action.requestAiSalesSummary.error": string;
        "action.requestAiPromoSuggestions.success": string;
        "action.requestAiPromoSuggestions.error": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowManagerDashboardBase extends CollabLitElement {
        status: string;
        viewDashboardState: 'idle' | 'loading' | 'success' | 'error';
        viewDashboardData: CafeFlowViewDashboardOutput;
        requestAiSalesSummaryState: 'idle' | 'loading' | 'success' | 'error';
        requestAiSalesSummaryData: CafeFlowRequestAiSalesSummaryOutput;
        requestAiPromoSuggestionsState: 'idle' | 'loading' | 'success' | 'error';
        requestAiPromoSuggestionsData: CafeFlowRequestAiPromoSuggestionsOutput;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadViewDashboard(): Promise<void>;
        handleViewDashboardClick(_event: Event): void;
        loadRequestAiSalesSummary(): Promise<void>;
        handleRequestAiSalesSummaryClick(_event: Event): void;
        loadRequestAiPromoSuggestions(): Promise<void>;
        handleRequestAiPromoSuggestionsClick(_event: Event): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/managerDashboard" {
    import { CafeFlowManagerDashboardBase } from "_102051_/l2/cafeFlow/web/shared/managerDashboard";
    export class CafeFlowDesktopPage11ManagerDashboardPage extends CafeFlowManagerDashboardBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: any[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: any[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/menuManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/menuManagement.ts", "_102051_/l2/cafeFlow/web/contracts/menuManagement.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/menuManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowBrowseMenuItemsOutputItem, CafeFlowManageMenuItemOutput } from "_102051_/l2/cafeFlow/web/contracts/menuManagement";
    const message_pt: {
        "page.title": string;
        "section.queue.title": string;
        "section.queue.empty": string;
        "section.manage.title": string;
        "section.review.title": string;
        "section.review.empty": string;
        "filter.statusFilter.label": string;
        "filter.menuCategoryIdFilter.label": string;
        "column.menuItemId.label": string;
        "column.name.label": string;
        "column.description.label": string;
        "column.menuCategoryId.label": string;
        "column.price.label": string;
        "column.itemType.label": string;
        "column.status.label": string;
        "column.activatedAt.label": string;
        "column.inactivatedAt.label": string;
        "column.createdAt.label": string;
        "column.updatedAt.label": string;
        "field.menuItemId.label": string;
        "field.name.label": string;
        "field.description.label": string;
        "field.menuCategoryId.label": string;
        "field.price.label": string;
        "field.itemType.label": string;
        "field.status.label": string;
        "action.refresh.label": string;
        "action.selectItem.label": string;
        "action.manageMenuItem.label": string;
        "action.manageMenuItem.submit": string;
        "action.manageMenuItem.success": string;
        "action.manageMenuItem.error": string;
        "org.menu.item.queue.title": string;
        "org.manage.item.form.title": string;
        "org.review.summary.title": string;
        "page.menuManagement.title": string;
        "section.board.title": string;
        "section.detail.title": string;
        "organism.kanbanBoard.title": string;
        "organism.manageForm.title": string;
        "intention.browse.title": string;
        "intention.manage.title": string;
        "action.browseMenuItems.label": string;
        "action.selectCard.label": string;
        "empty.board": string;
        "empty.detail": string;
        "lane.draft.title": string;
        "lane.active.title": string;
        "lane.inactive.title": string;
        "sec.board.title": string;
        "org.kanban.board.title": string;
        "sec.detail.title": string;
        "org.manage.form.title": string;
        "section.discover.title": string;
        "section.execute.title": string;
        "organism.menuItemsList.title": string;
        "organism.manageItemForm.title": string;
        "organism.actionFeedback.title": string;
        "field.menuItemId": string;
        "field.name": string;
        "field.description": string;
        "field.menuCategoryId": string;
        "field.price": string;
        "field.itemType": string;
        "field.status": string;
        "field.activatedAt": string;
        "field.inactivatedAt": string;
        "field.updatedAt": string;
        "filter.statusFilter": string;
        "filter.menuCategoryIdFilter": string;
        "action.refresh": string;
        "action.newItem": string;
        "action.selectItem": string;
        "empty.menuItems": string;
        "status.draft": string;
        "status.active": string;
        "status.inactive": string;
        "sec.discover.title": string;
        "org.menuItemsCardList.title": string;
        "sec.execute.title": string;
        "org.manageItemForm.title": string;
        "sec.review.title": string;
        "org.actionFeedback.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowMenuManagementBase extends CollabLitElement {
        status: string;
        browseMenuItemsState: "idle" | "loading" | "success" | "error";
        browseMenuItemsStatusFilter: string;
        browseMenuItemsMenuCategoryIdFilter: string;
        browseMenuItemsData: {
            items: CafeFlowBrowseMenuItemsOutputItem[];
            total: number;
        };
        manageMenuItemState: "idle" | "loading" | "success" | "error";
        manageMenuItemMenuItemId: string;
        manageMenuItemName: string;
        manageMenuItemDescription: string;
        manageMenuItemMenuCategoryId: string;
        manageMenuItemPrice: string;
        manageMenuItemItemType: string;
        manageMenuItemStatus: string;
        manageMenuItemOutput: CafeFlowManageMenuItemOutput | null;
        manageMenuItemError: string;
        activeCompanyId: string;
        private subscribedKeys;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        loadBrowseMenuItems(): Promise<void>;
        handleBrowseMenuItemsClick(_e: Event): void;
        manageMenuItem(): Promise<void>;
        handleManageMenuItemClick(_e: Event): void;
        setBrowseMenuItemsStatusFilter(value: string): void;
        handleBrowseMenuItemsStatusFilterChange(e: Event): void;
        setBrowseMenuItemsMenuCategoryIdFilter(value: string): void;
        handleBrowseMenuItemsMenuCategoryIdFilterChange(e: Event): void;
        setManageMenuItemMenuItemId(value: string): void;
        handleManageMenuItemMenuItemIdChange(e: Event): void;
        setManageMenuItemName(value: string): void;
        handleManageMenuItemNameChange(e: Event): void;
        setManageMenuItemDescription(value: string): void;
        handleManageMenuItemDescriptionChange(e: Event): void;
        setManageMenuItemMenuCategoryId(value: string): void;
        handleManageMenuItemMenuCategoryIdChange(e: Event): void;
        setManageMenuItemPrice(value: string): void;
        handleManageMenuItemPriceChange(e: Event): void;
        setManageMenuItemItemType(value: string): void;
        handleManageMenuItemItemTypeChange(e: Event): void;
        setManageMenuItemStatus(value: string): void;
        handleManageMenuItemStatusChange(e: Event): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/menuManagement" {
    import { CafeFlowMenuManagementBase } from "_102051_/l2/cafeFlow/web/shared/menuManagement";
    export class CafeFlowDesktopPage11MenuManagementPage extends CafeFlowMenuManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: any[];
                readsFields: any[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: any[];
                    readsFields: any[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/posWorkspace.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/posWorkspace.ts", "_102051_/l2/cafeFlow/web/contracts/posWorkspace.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/posWorkspace" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowCreateOrderOutput, CafeFlowViewOrderBoardOutput, CafeFlowDeliverOrderOutput } from "_102051_/l2/cafeFlow/web/contracts/posWorkspace";
    const message_pt: {
        "section.orderBoard.title": string;
        "section.createOrder.title": string;
        "section.deliverOrder.title": string;
        "organism.orderBoardCards.title": string;
        "organism.createOrderForm.title": string;
        "organism.deliverOrderSheet.title": string;
        "intention.orderBoard.list.title": string;
        "intention.createOrder.form.title": string;
        "intention.deliverOrder.form.title": string;
        "column.orderId": string;
        "column.status": string;
        "column.orderType": string;
        "column.tableNumber": string;
        "column.priority": string;
        "column.createdAt": string;
        "filter.status": string;
        "filter.orderType": string;
        "field.orderType": string;
        "field.tableNumber": string;
        "field.orderItems": string;
        "field.priority": string;
        "field.priorityReason": string;
        "field.orderId": string;
        "action.viewOrderBoard.label": string;
        "action.selectForDelivery": string;
        "action.createOrder.submit": string;
        "action.deliverOrder.submit": string;
        "action.createOrder.success": string;
        "action.createOrder.error": string;
        "action.deliverOrder.success": string;
        "action.deliverOrder.error": string;
        "empty.orderBoard": string;
        "empty.deliverOrder": string;
        "page.posWorkspace.title": string;
        "section.board.title": string;
        "section.review.title": string;
        "intention.board.title": string;
        "intention.createOrder.title": string;
        "intention.deliverOrder.title": string;
        "intention.review.title": string;
        "field.orderType.label": string;
        "field.tableNumber.label": string;
        "field.orderItems.label": string;
        "field.priority.label": string;
        "field.priorityReason.label": string;
        "field.orderId.label": string;
        "field.status.label": string;
        "field.receivedAt.label": string;
        "field.inPreparationAt.label": string;
        "field.readyAt.label": string;
        "field.createdAt.label": string;
        "action.createOrder.label": string;
        "action.deliverOrder.label": string;
        "action.selectOrder.label": string;
        "empty.board": string;
        "empty.createOrder": string;
        "empty.review": string;
        "lane.registered": string;
        "lane.received": string;
        "lane.inPreparation": string;
        "lane.ready": string;
        "lane.delivered": string;
        "sec.board.title": string;
        "org.orderKanbanBoard.title": string;
        "sec.createOrder.title": string;
        "org.createOrderForm.title": string;
        "sec.deliverOrder.title": string;
        "org.deliverOrderPanel.title": string;
        "sec.review.title": string;
        "org.reviewSummary.title": string;
        "section.queue.title": string;
        "section.queue.deliverTitle": string;
        "column.priorityReason": string;
        "column.receivedAt": string;
        "column.inPreparationAt": string;
        "column.readyAt": string;
        "column.deliveredAt": string;
        "column.updatedAt": string;
        "action.refresh.label": string;
        "action.confirmDeliver.label": string;
        "empty.queue": string;
        "queueSection.title": string;
        "orderBoard.title": string;
        "createOrderSection.title": string;
        "createOrderForm.title": string;
        "reviewSection.title": string;
        "actionSummary.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowPosWorkspaceBase extends CollabLitElement {
        status: string;
        createOrderState: 'idle' | 'loading' | 'success' | 'error';
        createOrderOrderType: string;
        createOrderTableNumber: string;
        createOrderOrderItems: string;
        createOrderPriority: string;
        createOrderPriorityReason: string;
        createOrderOutput: CafeFlowCreateOrderOutput | null;
        createOrderError: string;
        viewOrderBoardState: 'idle' | 'loading' | 'success' | 'error';
        viewOrderBoardData: CafeFlowViewOrderBoardOutput;
        deliverOrderState: 'idle' | 'loading' | 'success' | 'error';
        deliverOrderOrderId: string;
        deliverOrderOutput: CafeFlowDeliverOrderOutput | null;
        deliverOrderError: string;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        loadViewOrderBoard(): Promise<void>;
        handleViewOrderBoardClick(): void;
        createOrder(signal?: AbortSignal): Promise<void>;
        handleCreateOrderClick(): void;
        deliverOrder(signal?: AbortSignal): Promise<void>;
        handleDeliverOrderClick(): void;
        setCreateOrderOrderType(value: string): void;
        handleCreateOrderOrderTypeChange(e: Event): void;
        setCreateOrderTableNumber(value: string): void;
        handleCreateOrderTableNumberChange(e: Event): void;
        setCreateOrderOrderItems(value: string): void;
        handleCreateOrderOrderItemsChange(e: Event): void;
        setCreateOrderPriority(value: string): void;
        handleCreateOrderPriorityChange(e: Event): void;
        setCreateOrderPriorityReason(value: string): void;
        handleCreateOrderPriorityReasonChange(e: Event): void;
        setDeliverOrderOrderId(value: string): void;
        handleDeliverOrderOrderIdChange(e: Event): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/posWorkspace" {
    import { CafeFlowPosWorkspaceBase } from "_102051_/l2/cafeFlow/web/shared/posWorkspace";
    export class CafeFlowDesktopPage11PosWorkspacePage extends CafeFlowPosWorkspaceBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: any[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: any[];
                    writesFields: string[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/shiftManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/shiftManagement.ts", "_102051_/l2/cafeFlow/web/contracts/shiftManagement.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/shiftManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowOpenShiftOutput, CafeFlowCloseShiftOutput, CafeFlowViewShiftClosingReportOutput } from "_102051_/l2/cafeFlow/web/contracts/shiftManagement";
    const message_pt: {
        "page.title": string;
        "section.discover.title": string;
        "section.openShift.title": string;
        "section.closeShift.title": string;
        "section.review.title": string;
        "field.notes.label": string;
        "field.totalApurado.label": string;
        "field.shiftId.label": string;
        "field.shiftClosingReportId.label": string;
        "field.paidOrderCount.label": string;
        "field.createdAt.label": string;
        "field.updatedAt.label": string;
        "field.status.label": string;
        "field.openedAt.label": string;
        "field.openedBy.label": string;
        "field.closedAt.label": string;
        "field.closedBy.label": string;
        "action.openShift.label": string;
        "action.closeShift.label": string;
        "action.openShift.success": string;
        "action.openShift.error": string;
        "action.closeShift.success": string;
        "action.closeShift.error": string;
        "empty.reports": string;
        "sec.discover.title": string;
        "org.report.cards.title": string;
        "sec.open.shift.title": string;
        "org.open.shift.title": string;
        "sec.close.shift.title": string;
        "org.close.shift.title": string;
        "sec.review.title": string;
        "org.shift.summary.title": string;
        "section.board.title": string;
        "lane.open.title": string;
        "lane.open.empty": string;
        "lane.closed.title": string;
        "lane.closed.empty": string;
        "intent.query.report.title": string;
        "intent.openShift.title": string;
        "intent.closeShift.title": string;
        "intent.report.summary.title": string;
        "empty.report": string;
        "action.viewShiftClosingReport.label": string;
        "org.shift.board.title": string;
        "org.open.shift.form.title": string;
        "org.close.shift.form.title": string;
        "org.report.summary.title": string;
        "page.shiftManagement.title": string;
        "section.execute.title": string;
        "organism.report.title": string;
        "organism.shiftLifecycle.title": string;
        "organism.openShift.title": string;
        "organism.closeShift.title": string;
        "organism.summary.title": string;
        "empty.openShift": string;
        "empty.closeShift": string;
        "empty.summary": string;
        "org.shift.report.title": string;
        "sec.execute.title": string;
        "org.shift.lifecycle.title": string;
        "org.summary.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowShiftManagementBase extends CollabLitElement {
        status: string;
        openShiftState: 'idle' | 'loading' | 'success' | 'error';
        openShiftNotes: string;
        openShiftOutput: CafeFlowOpenShiftOutput | null;
        openShiftError: string;
        closeShiftState: 'idle' | 'loading' | 'success' | 'error';
        closeShiftTotalApurado: string;
        closeShiftNotes: string;
        closeShiftOutput: CafeFlowCloseShiftOutput | null;
        closeShiftError: string;
        viewShiftClosingReportState: 'idle' | 'loading' | 'success' | 'error';
        viewShiftClosingReportShiftId: string;
        viewShiftClosingReportData: CafeFlowViewShiftClosingReportOutput | null;
        protected get msg(): MessageType;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseRouteParams;
        setOpenShiftNotes(value: string): void;
        handleOpenShiftNotesChange(e: Event): void;
        setCloseShiftTotalApurado(value: string): void;
        handleCloseShiftTotalApuradoChange(e: Event): void;
        setCloseShiftNotes(value: string): void;
        handleCloseShiftNotesChange(e: Event): void;
        setViewShiftClosingReportShiftId(value: string): void;
        handleViewShiftClosingReportShiftIdChange(e: Event): void;
        loadViewShiftClosingReport(): Promise<void>;
        handleViewShiftClosingReportClick(e: Event): void;
        openShift(): Promise<void>;
        handleOpenShiftClick(e: Event): void;
        closeShift(): Promise<void>;
        handleCloseShiftClick(e: Event): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/shiftManagement" {
    import { CafeFlowShiftManagementBase } from "_102051_/l2/cafeFlow/web/shared/shiftManagement";
    export class CafeFlowDesktopPage11ShiftManagementPage extends CafeFlowShiftManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: any[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: any[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                        })[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page11/stockManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page11/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/stockManagement.ts", "_102051_/l2/cafeFlow/web/contracts/stockManagement.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/stockManagement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import type { CafeFlowBrowseStockItemsOutput, CafeFlowManageStockItemOutput } from "_102051_/l2/cafeFlow/web/contracts/stockManagement";
    const message_pt: {
        "page.stockManagement.title": string;
        "section.stockItems.title": string;
        "section.stockItems.description": string;
        "section.manageStockItem.title": string;
        "section.manageStockItem.description": string;
        "column.stockItemId.label": string;
        "column.name.label": string;
        "column.unit.label": string;
        "column.minimumLevel.label": string;
        "column.createdAt.label": string;
        "column.updatedAt.label": string;
        "field.stockItemId.label": string;
        "field.name.label": string;
        "field.unit.label": string;
        "field.minimumLevel.label": string;
        "filter.searchTerm.label": string;
        "action.browseStockItems.label": string;
        "action.select.label": string;
        "action.manageStockItem.label": string;
        "action.manageStockItem.success": string;
        "action.manageStockItem.error": string;
        "empty.browseStockItems": string;
        "empty.manageStockItem": string;
        "sec.stock.items.title": string;
        "org.stock.items.table.title": string;
        "sec.manage.stock.item.title": string;
        "org.stock.item.form.title": string;
        "section.stockQueue.title": string;
        "section.review.title": string;
        "field.createdAt.label": string;
        "field.updatedAt.label": string;
        "field.searchTerm.label": string;
        "action.selectItem.label": string;
        "action.refresh.label": string;
        "empty.stockQueue": string;
        "org.stockQueueTable.title": string;
        "org.manageStockItemForm.title": string;
        "org.reviewSummary.title": string;
        "page.title": string;
        "section.stockItemsList.title": string;
        "section.stockItemDetailPanel.title": string;
        "section.reviewSummary.title": string;
        "organism.stockItemsBrowser.title": string;
        "organism.stockItemManager.title": string;
        "organism.actionSummary.title": string;
        "intention.queryStockItems.title": string;
        "intention.manageStockItem.title": string;
        "intention.summary.title": string;
        "toolbar.refresh.label": string;
        "rowAction.selectItem.label": string;
        "empty.stockItems": string;
        "empty.noItemSelected": string;
        "empty.noActionsYet": string;
        "org.stockItemsBrowser.title": string;
        "org.stockItemManager.title": string;
        "org.actionSummary.title": string;
    };
    type MessageType = typeof message_pt;
    export class CafeFlowStockManagementBase extends CollabLitElement {
        status: string;
        browseStockItemsState: "idle" | "loading" | "success" | "error";
        browseStockItemsSearchTerm: string;
        browseStockItemsData: CafeFlowBrowseStockItemsOutput;
        manageStockItemState: "idle" | "loading" | "success" | "error";
        manageStockItemStockItemId: string;
        manageStockItemName: string;
        manageStockItemUnit: string;
        manageStockItemMinimumLevel: string;
        manageStockItemOutput: CafeFlowManageStockItemOutput | null;
        manageStockItemError: string;
        protected get msg(): MessageType;
        private parseRouteParams;
        loadBrowseStockItems(): Promise<void>;
        handleBrowseStockItemsClick(_event: Event): void;
        manageStockItem(): Promise<void>;
        handleManageStockItemClick(_event: Event): void;
        setBrowseStockItemsSearchTerm(value: string): void;
        handleBrowseStockItemsSearchTermChange(event: Event): void;
        setManageStockItemStockItemId(value: string): void;
        handleManageStockItemStockItemIdChange(event: Event): void;
        setManageStockItemName(value: string): void;
        handleManageStockItemNameChange(event: Event): void;
        setManageStockItemUnit(value: string): void;
        handleManageStockItemUnitChange(event: Event): void;
        setManageStockItemMinimumLevel(value: string): void;
        handleManageStockItemMinimumLevelChange(event: Event): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page11/stockManagement" {
    import { CafeFlowStockManagementBase } from "_102051_/l2/cafeFlow/web/shared/stockManagement";
    export class CafeFlowDesktopPage11StockManagementPage extends CafeFlowStockManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        emptyKey?: undefined;
                    })[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/kitchenQueue.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/kitchenQueue.ts", "_102051_/l2/cafeFlow/web/contracts/kitchenQueue.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/kitchenQueue" {
    import { CafeFlowKitchenQueueBase } from "_102051_/l2/cafeFlow/web/shared/kitchenQueue";
    export class CafeFlowDesktopPage21KitchenQueuePage extends CafeFlowKitchenQueueBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        }[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            }[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: any[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/managerDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/managerDashboard.ts", "_102051_/l2/cafeFlow/web/contracts/managerDashboard.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/managerDashboard" {
    import { CafeFlowManagerDashboardBase } from "_102051_/l2/cafeFlow/web/shared/managerDashboard";
    export class CafeFlowDesktopPage21ManagerDashboardPage extends CafeFlowManagerDashboardBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/menuManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/menuManagement.ts", "_102051_/l2/cafeFlow/web/contracts/menuManagement.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/menuManagement" {
    import { CafeFlowMenuManagementBase } from "_102051_/l2/cafeFlow/web/shared/menuManagement";
    export class CafeFlowDesktopPage21MenuManagementPage extends CafeFlowMenuManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        })[];
                        filters: any[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        actions: any[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/posWorkspace.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/posWorkspace.ts", "_102051_/l2/cafeFlow/web/contracts/posWorkspace.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/posWorkspace" {
    import { CafeFlowPosWorkspaceBase } from "_102051_/l2/cafeFlow/web/shared/posWorkspace";
    export class CafeFlowDesktopPage21PosWorkspacePage extends CafeFlowPosWorkspaceBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: string[];
            entityLifecycles: any[];
            taskWorkflows: string[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: any[];
                rulesApplied: any[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: any[];
                    rulesApplied: any[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/shiftManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/shiftManagement.ts", "_102051_/l2/cafeFlow/web/contracts/shiftManagement.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/shiftManagement" {
    import { CafeFlowShiftManagementBase } from "_102051_/l2/cafeFlow/web/shared/shiftManagement";
    export class CafeFlowDesktopPage21ShiftManagementPage extends CafeFlowShiftManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        baseClassName: string;
        actor: string;
        purpose: string;
        capabilities: string[];
        flowRefs: {
            experienceFlows: any[];
            entityLifecycles: any[];
            taskWorkflows: any[];
            automations: any[];
        };
        pluginRefs: any[];
        mdmRefs: any[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        pageInputs: any[];
        navigationRefs: any[];
        sections: ({
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    order: number;
                }[];
            }[];
        } | {
            id: string;
            type: string;
            sectionName: string;
            titleKey: string;
            mode: string;
            order: number;
            organisms: {
                id: string;
                type: string;
                organismName: string;
                titleKey: string;
                purpose: string;
                userActions: string[];
                requiredEntities: string[];
                readsFields: string[];
                writesFields: string[];
                rulesApplied: string[];
                order: number;
                intentionRefs: {
                    id: string;
                    intent: string;
                    stateKey: string;
                    action: string;
                    submitAction: string;
                    order: number;
                }[];
            }[];
        })[];
        templateId: string;
        visualStyle: string;
        pageObjective: {
            actor: string;
            jobToBeDone: string;
            primaryDecision: string;
            decisiveInfo: string[];
            usageFrequency: string;
            criticalActions: {
                action: string;
                presentation: string;
            }[];
            informationHierarchy: string[];
            successCriteria: string;
            antiPatterns: string[];
        };
        msgKeys: string[];
        layout: {
            id: string;
            type: string;
            sections: ({
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: ({
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: any[];
                        columns: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        filters: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        toolbar: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                        rowActions: any[];
                        actions: any[];
                    } | {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        displayHint: string;
                        stateKey: string;
                        fields: {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            stateKey: string;
                        }[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: any[];
                        emptyKey?: undefined;
                    })[];
                }[];
            } | {
                id: string;
                type: string;
                sectionName: string;
                titleKey: string;
                mode: string;
                order: number;
                organisms: {
                    id: string;
                    type: string;
                    organismName: string;
                    titleKey: string;
                    purpose: string;
                    userActions: string[];
                    requiredEntities: string[];
                    readsFields: string[];
                    writesFields: string[];
                    rulesApplied: string[];
                    order: number;
                    intentions: {
                        id: string;
                        intent: string;
                        order: number;
                        titleKey: string;
                        source: string;
                        binding: string;
                        action: string;
                        submitAction: string;
                        emptyKey: string;
                        displayHint: string;
                        stateKey: string;
                        fields: ({
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            format: string;
                            source: string;
                            stateKey: string;
                        } | {
                            id: string;
                            field: string;
                            labelKey: string;
                            order: number;
                            required: boolean;
                            inputType: string;
                            source: string;
                            stateKey: string;
                            format?: undefined;
                        })[];
                        columns: any[];
                        filters: any[];
                        toolbar: any[];
                        rowActions: any[];
                        actions: {
                            id: string;
                            action: string;
                            labelKey: string;
                            order: number;
                            displayHint: string;
                            actionKey: string;
                        }[];
                    }[];
                }[];
            })[];
        };
        dataBindings: {
            id: string;
            source: string;
            entity: string;
            command: string;
            description: string;
            stateKey: string;
            inputStateKeys: string[];
        }[];
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102051_/l2/cafeFlow/web/desktop/page21/stockManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/desktop/page21/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/shared/stockManagement.ts", "_102051_/l2/cafeFlow/web/contracts/stockManagement.ts", "_102051_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts"];
        readonly visualStyle: {
            readonly description: "POS-first, high-contrast, touch-friendly, status-driven UI with real-time kitchen board";
        };
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/desktop/page21/stockManagement" {
    import { CafeFlowStockManagementBase } from "_102051_/l2/cafeFlow/web/shared/stockManagement";
    export class CafeFlowDesktopPage21StockManagementPage extends CafeFlowStockManagementBase {
        render(): any;
    }
}
declare module "_102051_/l2/cafeFlow/web/shared/kitchenQueue.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.kitchenQueue.title": string;
            "page.kitchenQueue.subtitle": string;
            "section.kitchenBoard.title": string;
            "section.orderTransition.title": string;
            "section.review.title": string;
            "column.orderId.label": string;
            "column.status.label": string;
            "column.orderType.label": string;
            "column.tableNumber.label": string;
            "column.priority.label": string;
            "column.priorityReason.label": string;
            "column.receivedAt.label": string;
            "column.inPreparationAt.label": string;
            "column.createdAt.label": string;
            "field.orderId.label": string;
            "field.status.label": string;
            "action.select.label": string;
            "action.startPreparation.label": string;
            "action.markReady.label": string;
            "action.updateOrderStatus.label": string;
            "action.viewKitchenBoard.label": string;
            "empty.kitchenBoard": string;
            "empty.orderTransition": string;
            "empty.review": string;
            "action.updateOrderStatus.success": string;
            "action.updateOrderStatus.error": string;
            "lane.received.title": string;
            "lane.inPreparation.title": string;
            "lane.ready.title": string;
            "status.received": string;
            "status.inPreparation": string;
            "status.ready": string;
            "sec.kitchen.board.title": string;
            "org.kanban.board.title": string;
            "sec.order.transition.title": string;
            "org.transition.panel.title": string;
            "sec.review.title": string;
            "org.review.panel.title": string;
            "section.kitchenQueue.title": string;
            "section.transition.title": string;
            "field.orderId": string;
            "field.status": string;
            "field.orderType": string;
            "field.tableNumber": string;
            "field.priority": string;
            "field.priorityReason": string;
            "field.receivedAt": string;
            "field.inPreparationAt": string;
            "field.createdAt": string;
            "action.startPreparation": string;
            "action.markReady": string;
            "action.refreshBoard": string;
            "action.updateOrderStatus": string;
            "kitchen.queue.section.title": string;
            "kitchen.board.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "kitchenQueue__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/kitchenQueue.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/kitchenQueue.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/kitchenQueue.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["kitchenQueue__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/kitchenQueue.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/managerDashboard.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            actionRef?: undefined;
            valueSet?: undefined;
        })[];
        actions: {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
        }[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.dashboard.title": string;
            "section.aiSales.title": string;
            "section.aiPromo.title": string;
            "section.review.title": string;
            "intention.dashboard.title": string;
            "intention.aiSales.title": string;
            "intention.aiPromo.title": string;
            "intention.review.title": string;
            "column.status": string;
            "column.orderType": string;
            "column.createdAt": string;
            "column.shiftId": string;
            "column.deliveredAt": string;
            "column.orderId": string;
            "action.viewDashboard.label": string;
            "action.requestAiSalesSummary.label": string;
            "action.requestAiPromoSuggestions.label": string;
            "action.viewDashboard.success": string;
            "action.viewDashboard.error": string;
            "action.requestAiSalesSummary.success": string;
            "action.requestAiSalesSummary.error": string;
            "action.requestAiPromoSuggestions.success": string;
            "action.requestAiPromoSuggestions.error": string;
            "empty.dashboard": string;
            "empty.aiSales": string;
            "empty.aiPromo": string;
            "empty.review": string;
            "sec.dashboard.title": string;
            "org.dashboard.metrics.title": string;
            "sec.ai.sales.title": string;
            "org.ai.sales.summary.title": string;
            "sec.ai.promo.title": string;
            "org.ai.promo.suggestions.title": string;
            "sec.review.title": string;
            "org.review.summary.title": string;
            "section.dashboardOverview.title": string;
            "section.aiAssistant.title": string;
            "organism.dashboardSummary.title": string;
            "organism.aiSalesSummary.title": string;
            "organism.aiPromoSuggestions.title": string;
            "field.status.label": string;
            "field.orderType.label": string;
            "field.createdAt.label": string;
            "field.shiftId.label": string;
            "field.deliveredAt.label": string;
            "field.orderId.label": string;
            "action.viewDashboard.refresh": string;
            "action.requestAiSalesSummary.request": string;
            "action.requestAiPromoSuggestions.request": string;
            "empty.viewDashboard": string;
            "empty.requestAiSalesSummary": string;
            "empty.requestAiPromoSuggestions": string;
            "dashboardOverview.title": string;
            "dashboardSummary.title": string;
            "aiAssistant.title": string;
            "aiSalesSummary.title": string;
            "aiPromoSuggestions.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "managerDashboard__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/managerDashboard.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/managerDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/managerDashboard.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["managerDashboard__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/managerDashboard.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/menuManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            targetRef?: undefined;
            required?: undefined;
            selector?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            targetRef: string;
            required: boolean;
            selector: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: {
            operationId: string;
            contextKey: string;
            originRef: string;
            targetRef: string;
            required: boolean;
            description: string;
        }[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.queue.title": string;
            "section.execute.title": string;
            "section.review.title": string;
            "organism.queue.title": string;
            "organism.form.title": string;
            "organism.feedback.title": string;
            "intention.queryList.title": string;
            "intention.commandForm.title": string;
            "intention.summary.title": string;
            "field.menuItemId.label": string;
            "field.name.label": string;
            "field.description.label": string;
            "field.menuCategoryId.label": string;
            "field.price.label": string;
            "field.itemType.label": string;
            "field.status.label": string;
            "field.activatedAt.label": string;
            "field.createdAt.label": string;
            "field.updatedAt.label": string;
            "filter.statusFilter.label": string;
            "filter.menuCategoryIdFilter.label": string;
            "action.refresh.label": string;
            "action.select.label": string;
            "action.submit.label": string;
            "empty.queue": string;
            "empty.form.noSelection": string;
            "empty.summary": string;
            "action.manageMenuItem.success": string;
            "action.manageMenuItem.error": string;
            "organism.menuItemsQueue.title": string;
            "organism.manageItemForm.title": string;
            "organism.operationFeedback.title": string;
            "section.menuItems.title": string;
            "section.menuItems.empty": string;
            "section.manageMenuItem.title": string;
            "section.manageMenuItem.empty": string;
            "column.name.label": string;
            "column.menuCategoryId.label": string;
            "column.price.label": string;
            "column.itemType.label": string;
            "column.status.label": string;
            "action.selectItem.label": string;
            "action.save.label": string;
            "action.activate.label": string;
            "action.inactivate.label": string;
            "action.newItem.label": string;
            "sec.menu.items.title": string;
            "org.menu.items.list.title": string;
            "sec.manage.item.title": string;
            "org.menu.item.form.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "menuManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/menuManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/menuManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/menuManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["menuManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/menuManagement.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/posWorkspace.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.title": string;
            "section.discover.title": string;
            "section.createOrder.title": string;
            "section.deliverOrder.title": string;
            "section.review.title": string;
            "intent.viewOrderBoard.title": string;
            "intent.createOrder.title": string;
            "intent.deliverOrder.title": string;
            "intent.review.title": string;
            "field.orderType.label": string;
            "field.tableNumber.label": string;
            "field.orderItems.label": string;
            "field.priority.label": string;
            "field.priorityReason.label": string;
            "field.orderId.label": string;
            "column.orderId.label": string;
            "column.status.label": string;
            "column.orderType.label": string;
            "column.tableNumber.label": string;
            "column.priority.label": string;
            "column.priorityReason.label": string;
            "column.receivedAt.label": string;
            "column.inPreparationAt.label": string;
            "column.readyAt.label": string;
            "column.createdAt.label": string;
            "filter.status.label": string;
            "filter.orderType.label": string;
            "filter.priority.label": string;
            "toolbar.refresh.label": string;
            "rowAction.selectForDelivery.label": string;
            "action.createOrder.label": string;
            "action.deliverOrder.label": string;
            "action.createOrder.success": string;
            "action.createOrder.error": string;
            "action.deliverOrder.success": string;
            "action.deliverOrder.error": string;
            "empty.orderBoard": string;
            "sec.discover.title": string;
            "org.order.board.title": string;
            "sec.create.order.title": string;
            "org.create.order.title": string;
            "sec.deliver.order.title": string;
            "org.deliver.order.title": string;
            "sec.review.title": string;
            "org.review.title": string;
            "page.posWorkspace.title": string;
            "section.orderBoard.title": string;
            "section.orderBoard.empty": string;
            "organism.orderBoard.title": string;
            "organism.orderBoard.empty": string;
            "organism.createOrderForm.title": string;
            "intent.viewOrderBoard.empty": string;
            "action.viewOrderBoard.label": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "posWorkspace__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/posWorkspace.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/posWorkspace.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/posWorkspace.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["posWorkspace__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/posWorkspace.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/shiftManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            workflowId: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: string[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.shiftManagement.title": string;
            "section.discover.title": string;
            "section.execute.openShift.title": string;
            "section.execute.closeShift.title": string;
            "section.review.title": string;
            "field.notes.label": string;
            "field.totalApurado.label": string;
            "field.shiftClosingReportId.label": string;
            "field.shiftId.label": string;
            "field.paidOrderCount.label": string;
            "field.createdAt.label": string;
            "field.updatedAt.label": string;
            "field.status.label": string;
            "field.openedAt.label": string;
            "field.openedBy.label": string;
            "field.closedAt.label": string;
            "field.closedBy.label": string;
            "action.openShift.label": string;
            "action.closeShift.label": string;
            "action.openShift.success": string;
            "action.openShift.error": string;
            "action.closeShift.success": string;
            "action.closeShift.error": string;
            "empty.shiftClosingReport": string;
            "empty.review": string;
            "sec.discover.title": string;
            "org.shiftClosingReport.title": string;
            "sec.execute.openShift.title": string;
            "org.openShift.title": string;
            "sec.execute.closeShift.title": string;
            "org.closeShift.title": string;
            "sec.review.title": string;
            "org.review.title": string;
            "page.title": string;
            "section.shiftStatus.title": string;
            "section.shiftStatus.openShiftTitle": string;
            "section.shiftStatus.closeShiftTitle": string;
            "section.closingReport.title": string;
            "field.notes": string;
            "field.totalApurado": string;
            "field.shiftClosingReportId": string;
            "field.shiftId": string;
            "field.paidOrderCount": string;
            "field.createdAt": string;
            "field.updatedAt": string;
            "action.openShift": string;
            "action.closeShift": string;
            "empty.closingReport": string;
            "sec.shiftStatus.title": string;
            "org.shiftLifecycle.title": string;
            "sec.closingReport.title": string;
            "org.closingReport.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "shiftManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/shiftManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/shiftManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/shiftManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["shiftManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/shiftManagement.test" {
    export {};
}
declare module "_102051_/l2/cafeFlow/web/shared/stockManagement.defs" {
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            defPath: string;
            tsPath: string;
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            actionRef?: undefined;
            valueSet?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: {
                items: any[];
                total: number;
            };
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            actionRef?: undefined;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
        };
        i18n: {
            "page.stockManagement.title": string;
            "section.discover.title": string;
            "section.execute.title": string;
            "section.review.title": string;
            "organism.stockItemList.title": string;
            "organism.stockItemForm.title": string;
            "organism.stockItemSummary.title": string;
            "field.stockItemId.label": string;
            "field.name.label": string;
            "field.unit.label": string;
            "field.minimumLevel.label": string;
            "field.createdAt.label": string;
            "field.updatedAt.label": string;
            "field.searchTerm.label": string;
            "action.browseStockItems.label": string;
            "action.manageStockItem.label": string;
            "action.select.label": string;
            "action.refresh.label": string;
            "empty.browseStockItems": string;
            "empty.manageStockItem": string;
            "empty.summary": string;
            "action.manageStockItem.success": string;
            "action.manageStockItem.error": string;
            "sec.discover.title": string;
            "org.stock.item.list.title": string;
            "sec.execute.title": string;
            "org.stock.item.form.title": string;
            "sec.review.title": string;
            "org.stock.item.summary.title": string;
            "page.title": string;
            "section.stockItems.title": string;
            "section.stockItemEdit.title": string;
            "organism.stockItemsTable.title": string;
            "organism.stockItemsTable.searchTitle": string;
            "organism.stockItemEditor.title": string;
            "field.searchTerm.placeholder": string;
            "action.selectStockItem.label": string;
            "empty.stockItems": string;
            "empty.stockItemEditor": string;
            "stockItemsSection.title": string;
            "stockItemsTable.title": string;
            "stockItemEditSection.title": string;
            "stockItemEditor.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "stockManagement__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102051_/l2/cafeFlow/web/shared/stockManagement.ts";
        readonly defPath: "_102051_/l2/cafeFlow/web/shared/stockManagement.defs.ts";
        readonly dependsFiles: readonly ["_102051_/l2/cafeFlow/web/contracts/stockManagement.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly ["stockManagement__l2_contract"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102051_/l2/cafeFlow/web/shared/stockManagement.test" {
    export {};
}
