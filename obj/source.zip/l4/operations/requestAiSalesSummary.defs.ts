/// <mls fileReference="_102051_/l4/operations/requestAiSalesSummary.defs.ts" enhancement="_blank"/>

export const operationRequestAiSalesSummary = {
  "operationId": "requestAiSalesSummary",
  "title": "Solicitar resumo de vendas por IA",
  "actor": "gerente",
  "entity": "Order",
  "kind": "query",
  "reads": [
    "Order",
    "OrderItem",
    "Shift",
    "StockLevel"
  ],
  "writes": [],
  "rulesApplied": [
    "dashboardCurrentShiftOnly",
    "aiConsumesDomainData",
    "topSellersFromDayOrders"
  ],
  "story": {
    "actor": "Gerente",
    "goal": "Obter um resumo das vendas do dia gerado por IA para uma leitura rápida do desempenho sem precisar analisar os dados manualmente",
    "steps": [
      "O gerente solicita o resumo de vendas do dia ao assistente IA",
      "O sistema identifica o turno atualmente aberto e agrega os pedidos do dia corrente",
      "O assistente IA processa os dados agregados de pedidos e estoque disponibilizados pelo domínio e gera o resumo de vendas"
    ],
    "outcome": "O gerente recebe um resumo de vendas do turno/dia atual com indicadores de desempenho e itens mais vendidos"
  },
  "accessPattern": {
    "kind": "list",
    "entity": "Order",
    "keyField": "Order.orderId",
    "pagination": "none",
    "selection": "none",
    "output": [
      "Order.orderId",
      "Order.status",
      "Order.orderType",
      "Order.createdAt",
      "Order.deliveredAt"
    ]
  },
  "inputs": [
    {
      "inputId": "shiftId",
      "fieldRef": "Order.shiftId",
      "required": true,
      "source": "activeLifecycleInstance",
      "description": "Turno atualmente aberto para filtrar apenas os pedidos do dia corrente"
    },
    {
      "inputId": "actorId",
      "fieldRef": "Order.shiftId",
      "required": true,
      "source": "actorSession",
      "description": "Identificador do gerente autenticado que solicita o resumo"
    }
  ],
  "contextResolution": [
    {
      "targetRef": "Order.shiftId",
      "source": "activeLifecycleInstance",
      "originRef": "Shift.shiftId",
      "description": "Resolvido a partir do único Shift com status open, filtrando apenas pedidos do turno/dia corrente"
    },
    {
      "targetRef": "Order.shiftId",
      "source": "actorSession",
      "originRef": "actorSession.actorId",
      "description": "Resolvido a partir da sessão autenticada do gerente para autorizar o acesso ao resumo de vendas"
    }
  ],
  "acceptanceAssertions": [
    "O resumo de vendas inclui apenas pedidos do turno atualmente aberto, excluindo pedidos de turnos anteriores",
    "O resumo apresenta os itens mais vendidos calculados a partir dos pedidos do dia corrente",
    "O assistente IA consome apenas dados agregados de pedidos e estoque disponibilizados pelo domínio, sem acessar fontes externas",
    "O resultado não permite consulta de períodos históricos ou consolidados de múltiplos turnos"
  ],
  "pageId": "requestAiSalesSummary",
  "commandName": "requestAiSalesSummary",
  "bffName": "cafeFlow.requestAiSalesSummary.requestAiSalesSummary",
  "capability": {
    "capabilityId": "requestAiSalesSummary",
    "title": "Solicitar resumo de vendas por IA",
    "actor": "gerente",
    "priority": "soon"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationRequestAiSalesSummary;
