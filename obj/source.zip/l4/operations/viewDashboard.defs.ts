/// <mls fileReference="_102051_/l4/operations/viewDashboard.defs.ts" enhancement="_blank"/>

export const operationViewDashboard = {
  "operationId": "viewDashboard",
  "title": "Consultar dashboard do dia",
  "actor": "gerente",
  "entity": "Order",
  "kind": "view",
  "reads": [
    "Order",
    "OrderItem",
    "StockLevel",
    "Shift"
  ],
  "writes": [],
  "rulesApplied": [
    "dashboardCurrentShiftOnly",
    "topSellersFromDayOrders"
  ],
  "story": {
    "actor": "gerente",
    "goal": "Obter uma visão geral do dia operacional incluindo total de vendas, itens mais vendidos e alertas de estoque baixo do turno atual.",
    "steps": [
      "O gerente abre o dashboard do dia",
      "O sistema identifica o turno atualmente aberto para filtrar os dados",
      "O sistema agrega os pedidos do turno atual calculando o total de vendas",
      "O sistema calcula os itens mais vendidos com base nos pedidos do dia",
      "O sistema verifica os níveis de estoque abaixo do mínimo configurado",
      "O dashboard exibe vendas do dia, itens mais vendidos e alertas de estoque baixo"
    ],
    "outcome": "O gerente visualiza um painel consolidado com vendas do dia, itens mais vendidos e alertas de estoque baixo, restrito ao turno atual."
  },
  "accessPattern": {
    "kind": "list",
    "description": "Lista agregada de pedidos do turno atual para composição do dashboard com total de vendas, itens mais vendidos e alertas de estoque baixo",
    "entity": "Order",
    "keyField": "Order.orderId",
    "pagination": "none",
    "selection": "none",
    "output": [
      "Order.status",
      "Order.orderType",
      "Order.createdAt",
      "Order.shiftId",
      "Order.deliveredAt"
    ]
  },
  "inputs": [
    {
      "inputId": "shiftId",
      "fieldRef": "Order.shiftId",
      "required": true,
      "source": "activeLifecycleInstance",
      "description": "Turno atualmente aberto, usado para filtrar todos os dados do dashboard"
    },
    {
      "inputId": "actorId",
      "fieldRef": "Order.shiftId",
      "required": true,
      "source": "actorSession",
      "description": "Identificador do gerente autenticado que solicita o dashboard"
    }
  ],
  "contextResolution": [
    {
      "targetRef": "Order.shiftId",
      "source": "activeLifecycleInstance",
      "originRef": "Shift.shiftId",
      "description": "O backend localiza o único Shift com status aberto no momento e usa seu shiftId para filtrar todos os pedidos e dados agregados do dashboard"
    },
    {
      "targetRef": "Order.shiftId",
      "source": "actorSession",
      "originRef": "actorSession.actorId",
      "description": "O backend extrai o actorId da sessão autenticada do gerente para autorizar o acesso ao dashboard"
    }
  ],
  "acceptanceAssertions": [
    "O dashboard exibe apenas pedidos cujo shiftId corresponde ao turno atualmente aberto, sem incluir dados de turnos anteriores",
    "O total de vendas do dia é calculado somando os pedidos do turno atual",
    "Os itens mais vendidos são calculados com base nos OrderItem dos pedidos do dia corrente, não incluindo dados históricos",
    "O dashboard exibe alertas de estoque baixo para itens cujo StockLevel está abaixo do mínimo configurado",
    "O dashboard não permite consulta de períodos históricos ou consolidação de múltiplos turnos"
  ],
  "pageId": "viewDashboard",
  "commandName": "viewDashboard",
  "bffName": "cafeFlow.viewDashboard.viewDashboard",
  "capability": {
    "capabilityId": "viewDashboard",
    "title": "Consultar dashboard do dia",
    "actor": "gerente",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationViewDashboard;
