/// <mls fileReference="_102051_/l4/workflows/menuItemLifecycle.defs.ts" enhancement="_blank"/>

export const workflowMenuItemLifecycle = {
  "workflowId": "menuItemLifecycle",
  "title": "Ciclo de vida do item de cardápio",
  "executionMode": "sequential",
  "trigger": "Gerente inicia o cadastro de um novo item de cardápio no sistema",
  "actors": [
    "gerente"
  ],
  "states": [
    "draft",
    "active",
    "inactive"
  ],
  "transitions": [
    {
      "from": "draft",
      "to": "active",
      "on": "manageMenuItem",
      "by": "gerente",
      "guard": "Item deve ter pelo menos um ingrediente de estoque vinculado e ser do tipo simples"
    },
    {
      "from": "active",
      "to": "inactive",
      "on": "manageMenuItem",
      "by": "gerente"
    },
    {
      "from": "inactive",
      "to": "active",
      "on": "manageMenuItem",
      "by": "gerente",
      "guard": "Item deve ter pelo menos um ingrediente de estoque vinculado"
    }
  ],
  "operationIds": [
    "manageMenuItem",
    "browseMenuItems"
  ],
  "entities": [
    "MenuItem",
    "MenuCategory",
    "MenuItemIngredient",
    "StockItem"
  ],
  "rulesApplied": [
    "simpleItemsOnly",
    "menuItemRequiresIngredient"
  ],
  "story": {
    "actor": "gerente",
    "goal": "Cadastrar e manter os itens do cardápio com categoria, preço e vínculo aos ingredientes de estoque",
    "steps": [
      "O gerente cria um novo item de cardápio definindo nome, categoria e preço de venda.",
      "O gerente vincula os ingredientes de estoque que o item consome para garantir a rastreabilidade de consumo.",
      "O gerente ativa o item para que ele fique disponível para lançamento no POS.",
      "O gerente pode inativar o item quando ele não deve mais aparecer no POS."
    ],
    "outcome": "Item do cardápio disponível no POS com vínculo de ingredientes configurado"
  },
  "pageId": "menuItemLifecycle",
  "capabilities": [
    {
      "capabilityId": "menuItemLifecycle",
      "title": "Ciclo de vida do item de cardápio",
      "actor": "gerente",
      "priority": "now"
    }
  ],
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default workflowMenuItemLifecycle;
