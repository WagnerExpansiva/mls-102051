/// <mls fileReference="_102051_/l4/workflows/orderLifecycle.defs.ts" enhancement="_blank"/>

export const workflowOrderLifecycle = {
  "workflowId": "orderLifecycle",
  "title": "Ciclo de vida do pedido",
  "executionMode": "sequential",
  "trigger": "Atendente lança um novo pedido no POS selecionando tipo e itens do cardápio",
  "actors": [
    "atendente",
    "cozinheiro"
  ],
  "states": [
    "registered",
    "received",
    "inPreparation",
    "ready",
    "delivered"
  ],
  "transitions": [
    {
      "from": "registered",
      "to": "received",
      "on": "createOrder",
      "by": "atendente",
      "guard": "Estoque deve ser suficiente para todos os itens do pedido antes da confirmação"
    },
    {
      "from": "received",
      "to": "inPreparation",
      "on": "updateOrderStatus",
      "by": "cozinheiro",
      "guard": "Pedidos devem ser preparados na ordem de chegada, salvo priorização justificada"
    },
    {
      "from": "inPreparation",
      "to": "ready",
      "on": "updateOrderStatus",
      "by": "cozinheiro",
      "guard": "O pedido deve estar em preparo antes de ser marcado como pronto"
    },
    {
      "from": "ready",
      "to": "delivered",
      "on": "deliverOrder",
      "by": "atendente",
      "guard": "Apenas pedidos com status 'pronto' podem ser marcados como entregues"
    }
  ],
  "operationIds": [
    "createOrder",
    "updateOrderStatus",
    "deliverOrder",
    "viewOrderBoard",
    "viewKitchenBoard"
  ],
  "entities": [
    "Order",
    "OrderItem",
    "StockConsumption",
    "StockLevel",
    "Shift"
  ],
  "rulesApplied": [
    "stockDecrementOnOrderLaunch",
    "orderStatusFlow",
    "readyBeforeDelivered",
    "inProgressBeforeReady",
    "fifoKitchenQueue"
  ],
  "story": {
    "actor": "atendente",
    "goal": "Registrar e acompanhar um pedido desde o lançamento no POS até a entrega ao cliente",
    "steps": [
      "O atendente seleciona o tipo de pedido (mesa ou takeout) e adiciona os itens do cardápio solicitados pelo cliente.",
      "O atendente revisa o resumo do pedido, verifica alertas de estoque insuficiente e confirma, enviando à cozinha com o estoque decrementado conforme ingredientes vinculados.",
      "O cozinheiro visualiza a fila de pedidos recebidos na cozinha e inicia o preparo, marcando o pedido como 'em preparo'.",
      "Ao concluir o preparo, o cozinheiro marca o pedido como 'pronto', sinalizando o atendente pelo painel de status.",
      "O atendente consulta o painel de pedidos, confirma o status 'pronto' e entrega o pedido ao cliente, marcando-o como entregue."
    ],
    "outcome": "Pedido entregue ao cliente com status finalizado e estoque atualizado conforme os ingredientes consumidos no preparo"
  },
  "pageId": "orderLifecycle",
  "capabilities": [
    {
      "capabilityId": "orderLifecycle",
      "title": "Ciclo de vida do pedido",
      "actor": "atendente",
      "priority": "now"
    }
  ],
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default workflowOrderLifecycle;
